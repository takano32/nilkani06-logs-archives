#!/usr/bin/env python3
"""本体の claude に /quit を届けて、終わったら止まる（撃ち直しの入口はこれ1本。手で sleep ループを組まない）。

2026-11-22 11:48〜11:50 に、その場で組んだ「届くまで5秒おきに /quit」が、狙った claude が終わったあとも止まらず、
起き直した次の claude を4回続けて落とした（takano32 が手で止めた。「スクリプトにしたほうがよくね？これ致命的」）。
だからここでは、撃つ相手を最初に PID で1つに決め、次のどれかで必ず終わる。

  - 相手の PID が消えた（＝落ちた）          → 0 で終わる
  - ペインの前景の claude が相手と違う PID    → 撃たずに 0 で終わる（別の世代には撃たない）
  - 一度届いた（inject が 0 を返した）          → 以後は撃たず、相手が消えるのを待つだけ
  - 上限時間（--deadline 秒、既定 1800）を過ぎた → 撃たずに 3 で終わる
  - 同時に2本目を起動した                      → ロックが取れず 2 で終わる

見送り（working・blocked・起動直後など）のときだけ --interval 秒あけて撃ち直す。
走行中のターンへは inject が撃たない（_herdr.py の「注入」）ので、自分のターンの中から起動してよい。
起動は切り離して行う: `setsid -f python3 skills/ops/quit-send.py`（ログは configs/quit-send.log）。

使い方:
  python3 skills/ops/quit-send.py [--pid PID] [--interval 5] [--deadline 1800] [--session nilkani06] [--pane w1:p1]
  --pid を省くと、自分の祖先にいる claude を相手にする（本体の Bash から起動したとき＝本体自身）。
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "site-python"))
import _herdr  # noqa: E402

LOCK = os.path.join(ROOT, "configs", "quit-send.lock")
LOG = os.path.join(ROOT, "configs", "quit-send.log")


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%dT%H:%M:%S%z')} [{os.getpid()}] {msg}"
    print(line, file=sys.stderr, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def comm(pid: int) -> str:
    try:
        with open(f"/proc/{pid}/comm", encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def ppid(pid: int) -> int:
    try:
        with open(f"/proc/{pid}/stat", encoding="utf-8") as f:
            return int(f.read().rsplit(")", 1)[1].split()[1])
    except (OSError, ValueError, IndexError):
        return 0


def start_time(pid: int) -> str:
    """PID の使い回しを見分けるための起動時刻（/proc/<pid>/stat の22番目）。"""
    try:
        with open(f"/proc/{pid}/stat", encoding="utf-8") as f:
            return f.read().rsplit(")", 1)[1].split()[19]
    except (OSError, IndexError):
        return ""


def ancestor_claude() -> int:
    p = os.getppid()
    while p > 1:
        if comm(p) == "claude":
            return p
        p = ppid(p)
    return 0


def pane_claude(session: str, pane: str) -> list[int]:
    """ペインの前景にいる claude の PID（居なければ空）。"""
    cmd = [_herdr.herdr_bin_cli()] + ([] if session == "-" else ["--session", session]) + ["pane", "process-info", "--pane", pane]
    try:
        out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=20).stdout.decode("utf-8", "replace")
    except (OSError, subprocess.TimeoutExpired):
        return []
    pids: list[int] = []
    for v in _herdr._json_values(out):
        ok, arr = _herdr._path(v, ("result", "process_info", "foreground_processes"))
        if ok and isinstance(arr, list):
            pids += [int(e["pid"]) for e in arr if isinstance(e, dict) and e.get("name") == "claude" and str(e.get("pid", "")).isdigit()]
    return pids


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--pid", type=int, default=0)
    ap.add_argument("--interval", type=float, default=5.0)
    ap.add_argument("--deadline", type=float, default=1800.0)
    ap.add_argument("--session", default=os.environ.get("HERDR_SESSION") or "nilkani06")
    ap.add_argument("--pane", default=os.environ.get("HERDR_PANE_ID") or "w1:p1")
    a = ap.parse_args()

    lock = open(LOCK, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        log("もう1本走っている（configs/quit-send.lock）。何もしない")
        return 2

    target = a.pid or ancestor_claude()
    if not target or comm(target) != "claude":
        log(f"相手の claude が決まらない（pid={target} comm={comm(target) if target else ''}）。何もしない")
        return 2
    born = start_time(target)
    log(f"相手 pid={target}（起動 {born}）。session={a.session} pane={a.pane} interval={a.interval}s deadline={a.deadline}s")

    def alive() -> bool:
        return comm(target) == "claude" and start_time(target) == born

    t0 = time.monotonic()
    sent = False
    while True:
        if not alive():
            log(f"相手 pid={target} が終わった。おしまい（{'届けたあと' if sent else '撃つ前に'}）")
            return 0
        if time.monotonic() - t0 > a.deadline:
            log(f"上限 {a.deadline}s を過ぎた（届けた={sent}）。撃たずに終わる")
            return 3
        if not sent:
            fg = pane_claude(a.session, a.pane)
            if fg and target not in fg:
                log(f"ペインの前景の claude は {fg} で、相手 {target} ではない。別の世代には撃たない。おしまい")
                return 0
            if target in fg:
                rc = _herdr.inject(a.session, a.pane, "/quit")
                if rc == 0:
                    sent = True
                    log("/quit を届けた。以後は撃たず、終わるのを待つ")
                else:
                    log(f"見送り（inject rc={rc}）。{a.interval}s 後にもう一度")
        time.sleep(a.interval)


if __name__ == "__main__":
    sys.exit(main())
