#!/usr/bin/env bash
# 起動。サービス（nilkani06.service）の主プロセスで、端末の器を立てて、その中で loop.bash を流して見張る。
# どの器を使うかはこのファイルの中の都合で、サービスには出さない（2026-10-18 takano32 判断・管理チャンネル
# 「herdr って名前がサービスに出てるのはよくない、抽象度として」）。器は環境変数 MUX で選ぶ（既定 herdr）。
#
#   MUX=herdr（既定）… 生 herdr で組む：
#     1) 前回のレイアウト（session.json）を捨てる  … 復元で別 id のペインが戻ると pane_id が読めない（PLAN §8 判断1＝消す）
#     2) herdr server を子として起こす            … 前面プロセス。systemd から見た主プロセスはこのスクリプト（Type=exec）
#     3) ソケットを待つ                             … not_running でも exit 0 なので running:true を見る
#     4) ワークスペースを作り、ペインで loop.bash を起こす（exec＝bash を1段挟まない）
#     5) ペインを見張る                             … ペインが死んでもサーバは生きるので、見張らないと「サービスは健全・中身は空」になる
#     理由と実測は skills/ops/herdr/PLAN.md §3-4・SKILL.md。
#   MUX=screen … `screen -DmS <セッション名> -L -Logfile logs/screen.log ./loop.bash` を前面で起こす（-D -m＝切り離した
#     まま前面に居続ける。screen が終わればこのスクリプトも終わり、systemd が起こし直す）。
#
# 停止は SIGTERM（systemd の既定）で受ける。herdr なら、停止の印（configs/stop_requested）を置き、ペインの claude に /quit を
#   届けて（skills/ops/quit-send.py）、claude が消えるのを待ってから（上限 NILKANI_BOOT_STOP_WAIT 秒）サーバを API で畳む。
#   loop.bash は claude が終わった直後に印を見て、起こし直さずに exit 0 で抜ける。待つのは claude の SessionEnd フック
#   （transcript の退避など）を走らせるため＝先に畳むとペインごと約1秒で SIGKILL され、フックが走らない。
#   上限を過ぎたら従来どおり畳む（unit の TimeoutStopSec=90 より十分短くしてある）。形は坂本（~/zerozari00 の boot.bash stop と
#   loop.bash の on_term）に倣った（2026-11-22 takano32「坂本の参考になるところ、ぜんぶパクろう」・管理チャンネル）。
#   screen ならセッションを quit する（/quit を届ける口が herdr にしか無いので、従来どおり）。
# 2026-10-18 までは scripts/herdr-boot.bash だった（同日、旧 boot.bash は loop.bash に改名）。
#
# 使い方: ./boot.bash（引数なし。環境で変える）
#   MUX                       器（herdr か screen。既定 herdr）
#   NILKANI_HERDR_SESSION     herdr のセッション名／screen のセッション名（既定 nilkani06）
#   NILKANI_HERDR_CONFIG_PATH herdr の設定ファイル（既定 configs/herdr.toml。boot.bash が HERDR_CONFIG_PATH に入れて herdr に渡す）
#   NILKANI_HERDR_BIN         herdr の実体（既定 PATH の herdr → ~/.cargo/bin/herdr → ~/opt/herdr/target/release/herdr）
#   NILKANI_BOOT_COMMAND      ペインで流すコマンド（既定 `exec ./loop.bash`。使い捨ての試験では模擬ループに差し替える）
#   NILKANI_BOOT_CWD          ペインの cwd（既定 リポ直下）
#   NILKANI_BOOT_WATCH_SEC    見張りの間隔秒（既定 30）
#   NILKANI_BOOT_STOP_WAIT    停止のとき claude が消えるのを待つ上限秒（既定 60。unit の TimeoutStopSec=90 より短く）
# ⚠️ 引き継いだ HERDR_* は全部捨ててから始める（2026-11-22。坂本＝~/zerozari00/boot.bash の冒頭に倣った）。
#   別の herdr のペインの中から打つと、そのペインの HERDR_SESSION・HERDR_SOCKET_PATH・HERDR_CONFIG_PATH などが環境に入っていて、
#   そのまま使うと相手のサーバを見たり止めたり、相手の設定を読んだりする（坂本で 2026-10-18 に実測）。
#   だからこちらの設定は NILKANI_* の名前で受け、herdr 自身が読む HERDR_CONFIG_PATH だけをここで組んで export する。
#   ペインの中の HERDR_PANE_ID・HERDR_SESSION・HERDR_BIN_PATH・HERDR_SOCKET_PATH は herdr がペインに入れ直す（skills/ops/herdr/SKILL.md）。
#   2026-11-22 までの名前（HERDR_SESSION、HERDR_CONFIG_PATH、HERDR_BIN_PATH、HERDR_BOOT_*）は、もう効かない。
# 終了コード: 0=SIGTERM/SIGINT で畳んだ／1=起動に失敗した・ペインの中身が死んだ（systemd の Restart=always が起こし直す）／
#             それ以外=server（または screen）自身の終了コード
# 依存: herdr・jq・timeout（coreutils）、または screen。loop.bash の依存（claude・curl・jq・ss）は器の中で要る。
set -uo pipefail
cd "$(dirname "$0")" || exit 1
for v in $(compgen -e | grep '^HERDR_'); do unset "$v"; done

# herdr の実体：指定（NILKANI_HERDR_BIN）→ PATH → ~/.cargo/bin（cargo install の置き場。systemd は .bashrc を読まないので
# PATH に乗っていないことがある）→ ~/opt のチェックアウトで組んだもの、の順（2026-10-18 に cargo install へ移した）。
BIN="${NILKANI_HERDR_BIN:-$(command -v herdr || true)}"
[ -n "${BIN:-}" ] || { [ -x "$HOME/.cargo/bin/herdr" ] && BIN="$HOME/.cargo/bin/herdr"; }
[ -n "${BIN:-}" ] || BIN="$HOME/opt/herdr/target/release/herdr"
S="${NILKANI_HERDR_SESSION:-nilkani06}"
CMD="${NILKANI_BOOT_COMMAND:-exec ./loop.bash}"
CWD="${NILKANI_BOOT_CWD:-$PWD}"
EVERY="${NILKANI_BOOT_WATCH_SEC:-30}"
STOP_WAIT="${NILKANI_BOOT_STOP_WAIT:-60}"
# 停止の印。boot.bash が SIGTERM で置き、loop.bash が claude の終わった直後に見て、起こし直さずに抜ける。
# 古い印は起動のたびに消す（前回の停止が途中で切れて残っていても、今回の起動を止めない）。
STOP_MARK="$PWD/configs/stop_requested"
mkdir -p configs
rm -f "$STOP_MARK"

log() { printf '[%s] boot: %s\n' "$(date -Is)" "$*"; }
H() { timeout 20 "$BIN" --session "$S" "$@"; }

MUX="${MUX:-herdr}"
export HERDR_CONFIG_PATH="${NILKANI_HERDR_CONFIG_PATH:-$PWD/configs/herdr.toml}"

if [ "$MUX" = screen ]; then
  command -v screen >/dev/null || { log "screen が無い"; exit 1; }
  log "screen で起こす: session=$S"
  trap 'log "SIGTERM/SIGINT 受信"; screen -S "$S" -X quit >/dev/null 2>&1' TERM INT
  screen -DmS "$S" -L -Logfile logs/screen.log ./loop.bash &
  wait $!; rc=$?
  log "screen が終わった rc=$rc"
  exit "$rc"
fi
[ "$MUX" = herdr ] || { log "MUX は herdr か screen: $MUX"; exit 1; }

[ -x "$BIN" ] || { log "herdr の実体が無い: $BIN"; exit 1; }
command -v jq >/dev/null || { log "jq が無い"; exit 1; }

# 1) 前回のレイアウトを捨てる（置き場は herdr と同じ導出＝$XDG_CONFIG_HOME か ~/.config）
sess_dir="${XDG_CONFIG_HOME:-$HOME/.config}/herdr/sessions/$S"
rm -f "$sess_dir/session.json"

# 2) サーバ（子）。stdout/stderr はこのスクリプトのもの（systemd なら journal）に流す。
"$BIN" --session "$S" server &
SRV=$!

stop_all() {
  log "停止: server stop → 終了待ち"
  H server stop >/dev/null 2>&1
  local i
  for i in $(seq 1 50); do kill -0 "$SRV" 2>/dev/null || break; sleep 0.2; done
  if kill -0 "$SRV" 2>/dev/null; then log "server stop で止まらないので SIGTERM"; kill -TERM "$SRV" 2>/dev/null; fi
  wait "$SRV" 2>/dev/null
}
PANE=""

# 停止の前に claude を先に終わらせる（上の冒頭の注）。claude が居なければ何もせずに返る。
# /quit の「Background work is running」確認画面（1. Exit and stop tasks が選ばれている）には、ここで Enter を送る。
# watcher の blocked target にも同じ処理があるが、あちらは 60 秒おきで、待ちの上限（既定 60 秒）に間に合わないことがある。
# 止めるのに見張りを当てにしない（見張りは claude と一緒に消える）。
graceful_quit() {
  [ -n "$PANE" ] || return 0
  local pi cpid shell_pid qs i end entered=0 scr nb=$'\xc2\xa0'
  pi="$(H pane process-info --pane "$PANE" 2>/dev/null)"
  cpid="$(printf '%s' "$pi" | jq -r '[.result.process_info.foreground_processes[]? | select(.name == "claude") | .pid][0] // empty' 2>/dev/null)"
  shell_pid="$(printf '%s' "$pi" | jq -r '.result.process_info.shell_pid // empty' 2>/dev/null)"
  touch "$STOP_MARK"   # 先に置く＝loop.bash がバックオフの sleep 中でも、起きたら claude を起こさずに抜ける
  if [ -z "$cpid" ]; then log "停止: ペインの前景に claude が居ない → /quit は省いて畳む"; return 0; fi
  log "停止: 印を置いて claude pid=$cpid に /quit を届ける（消えるのを最大 ${STOP_WAIT}s 待つ）"
  # quit-send は boot.bash の子なので、相手は祖先からは決まらない＝--pid で渡す。HERDR_* は捨ててあるので実体も渡す。
  HERDR_BIN_PATH="$BIN" python3 skills/ops/quit-send.py --pid "$cpid" --session "$S" --pane "$PANE" \
    --interval 2 --deadline "$STOP_WAIT" </dev/null >/dev/null 2>&1 &
  qs=$!
  # 上限は経過時間で測る（herdr を呼ぶぶん、回数で数えると上限より延びる）
  end=$((SECONDS + STOP_WAIT))
  for ((i = 0; SECONDS < end; i++)); do
    kill -0 "$cpid" 2>/dev/null || break
    if [ "$entered" = 0 ] && (( i % 4 == 3 )); then
      scr="$(timeout 5 "$BIN" --session "$S" pane read "$PANE" --source recent-unwrapped --lines 30 --format text 2>/dev/null)"
      if grep -q 'Background work is running' <<<"$scr" \
         && grep -qE "❯([[:space:]]|$nb)*1\.([[:space:]]|$nb)*Exit and stop tasks" <<<"$scr"; then
        H pane send-keys "$PANE" enter >/dev/null 2>&1
        entered=1
        log "停止: /quit の確認画面（Background work is running）に Enter を送った（Exit and stop tasks）"
      fi
    fi
    sleep 0.5
  done
  kill "$qs" 2>/dev/null; wait "$qs" 2>/dev/null
  if kill -0 "$cpid" 2>/dev/null; then
    log "停止: claude pid=$cpid が ${STOP_WAIT}s で終わらない → 待つのをやめて畳む"
    return 0
  fi
  log "停止: claude pid=$cpid が終わった（$((SECONDS - end + STOP_WAIT))s）"
  # loop.bash が印を見て抜けるのを少しだけ待つ（終了の記録を boot.log に書かせる）
  if [ -n "$shell_pid" ]; then
    for ((i = 0; i < 20; i++)); do kill -0 "$shell_pid" 2>/dev/null || break; sleep 0.5; done
    kill -0 "$shell_pid" 2>/dev/null && log "停止: loop.bash pid=$shell_pid が 10s で抜けない → そのまま畳む"
  fi
  return 0
}
on_signal() { trap '' TERM INT; log "SIGTERM/SIGINT 受信"; graceful_quit; stop_all; exit 0; }
trap on_signal TERM INT

# 3) ソケット待ち（上限 10 秒）。サーバが先に死んだらそこで諦める。
ok=0
for _ in $(seq 1 100); do
  H status server --json 2>/dev/null | grep -q '"running":true' && { ok=1; break; }
  kill -0 "$SRV" 2>/dev/null || break
  sleep 0.1
done
if [ "$ok" != 1 ]; then log "サーバが 10 秒以内に起きなかった（pid=$SRV）"; stop_all; exit 1; fi

# 4) ワークスペースとペイン（ペインで loop.bash を流す）
created="$(H workspace create --cwd "$CWD" --label "$S" --no-focus 2>&1)"
PANE="$(printf '%s' "$created" | jq -r '.result.root_pane.pane_id // empty' 2>/dev/null)"
if [ -z "$PANE" ]; then
  log "workspace create に失敗: $(printf '%s' "$created" | tr -d '\n' | cut -c1-300)"; stop_all; exit 1
fi
log "server pid=$SRV session=$S pane=$PANE cwd=$CWD"
# bash がプロンプトに達するのを待つ（.bashrc の nvm 待ち）。切れても続行＝プロンプト前の入力は tty に積まれて壊れない。
H pane wait-output "$PANE" --regex '\$ ?$' --timeout 15000 >/dev/null 2>&1 \
  || log "プロンプト待ちが 15 秒で切れた（入力は tty に積まれるので続行）"
if ! H pane run "$PANE" "$CMD" >/dev/null 2>&1; then log "pane run に失敗"; stop_all; exit 1; fi
log "pane run: $CMD"

# 5) 見張り。健全＝ペインのシェルが生きていて、前景のプロセス群にシェル自身以外が居る
#    （claude でも sleep でも curl でもよい＝loop.bash の中で何が前景でも構わない）。
#    死んだ＝ペインが無い／シェルが居ない／前景がシェル自身だけ（exec なしで起こした loop.bash が終わってプロンプトに戻った形）。
#    2回続けて死んで見えたときだけ畳む（瞬間の空白を拾わない）。
bad=0
while kill -0 "$SRV" 2>/dev/null; do
  sleep "$EVERY" & wait $! 2>/dev/null   # 子の sleep にしておくと、SIGTERM が待ちの途中でも trap へ入る
  kill -0 "$SRV" 2>/dev/null || break
  pi="$(H pane process-info --pane "$PANE" 2>/dev/null)"
  shell_pid="$(printf '%s' "$pi" | jq -r '.result.process_info.shell_pid // empty' 2>/dev/null)"
  others="$(printf '%s' "$pi" | jq -r --argjson sp "${shell_pid:-0}" '[.result.process_info.foreground_processes[]? | select(.pid != $sp)] | length' 2>/dev/null)"
  why=""
  if [ -z "$shell_pid" ] || ! kill -0 "$shell_pid" 2>/dev/null; then
    why="ペインのシェルが居ない（shell_pid=${shell_pid:-?}）"
  elif [ "${others:-0}" = 0 ]; then
    why="前景がシェル自身だけ（shell_pid=$shell_pid）＝loop.bash のループが終わっている"
  fi
  if [ -z "$why" ]; then bad=0; continue; fi
  bad=$((bad + 1))
  log "見張り: ${why}（${bad}/2）"
  [ "$bad" -ge 2 ] || continue
  log "ペインの中身が死んだ→サーバを畳んで非0で終わる（systemd が起こし直す）"
  stop_all; exit 1
done

wait "$SRV"; rc=$?
log "server が終わった rc=$rc"
exit "$rc"
