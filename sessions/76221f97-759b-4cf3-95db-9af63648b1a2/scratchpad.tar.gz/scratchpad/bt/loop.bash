#!/usr/bin/env bash
# 常駐ループ。claude を起こし、落ちたら起こし直す（プロキシの検知、起動と終了の通知、バックオフもここ）。
# サービスからは直接起こさない＝boot.bash が端末の器（herdr か screen）を立て、その中でこれを流す。
# 2026-10-18 までは、このファイルの名前が boot.bash だった（takano32 判断・管理チャンネル）。
set -uo pipefail

# スクリプトのある場所（＝リポジトリ直下）へ移動し、以降は相対パスで扱う。
cd "$(dirname "$0")" || exit 1

# nvm を読み込んで default の node を PATH に乗せる（systemd 側で node の版を直書きしないで済むように）。
# ※ set -u 下で nvm.sh を読むと未定義変数で落ちるので、その間だけ +u にする。
export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
if [[ -s "${NVM_DIR}/nvm.sh" ]]; then
  set +u
  . "${NVM_DIR}/nvm.sh" >/dev/null 2>&1
  nvm use default >/dev/null 2>&1 || true
  set -u
fi

# claude・bun を自前のパスから解決する。下の順（＝記載順が優先順）で PATH 先頭に積む。
# どれも nvm が乗せる node より優先させたいので $PATH の前に置く。1 行 1 パス＋コメントで見やすく。
extra_bins=(
  "$HOME/.bun/bin"              # bun（standalone）を最優先
  "$HOME/.local/bin"           # claude（native）等の既存ユーザーローカル bin
  "$HOME/nilkani06/.local/bin" # このリポにローカル導入する CLI（pipx の PIPX_BIN_DIR）
)
# 配列を ':' 区切りで連結（IFS の変更は $(...) の中だけに閉じる）して $PATH の前に付ける。
export PATH="$(IFS=:; printf '%s' "${extra_bins[*]}"):$PATH"
unset extra_bins

# venv の外での `pip install` を、最初から失敗させる（takano32 指示 2026-08-14・管理チャンネル）。
# ⚠️ 設定値ではなく「規則」なので .env ではなくここに置く（.env は秘密と接続先のためのもの）。
# 正規の導入先 .local/python-packages は本物の venv（pyvenv.cfg あり）なので、
# `.local/python-packages/bin/python3 -m pip install …` は素通りする＝正しい道は塞がない。
# 止まるのは /usr/bin/pip を素で叩いたときだけで、ダウンロードが始まる前に落ちる。
# 経緯＝2026-08-14、委譲先がコマンドの引数を調べるために oci-cli を入れようとして
# 27.8MB の取得と依存のビルドを走らせ、箱を詰まらせた（/tmp は tmpfs＝メモリ）。
# ⚠️ 効くのは pip だけ。npm・cargo・apt は素通りする（この一手で塞げるのは今日の形だけ）。
export PIP_REQUIRE_VIRTUALENV=true

# ⚠️ 調整できる環境変数は boot.env へ移した（takano32 指示 2026-08-17・管理チャンネル）。
# 下のループの中で毎回 source するので、boot.env を書き換えたら /quit だけで反映される。
# ⚠️ 守りの既定（上の PIP_REQUIRE_VIRTUALENV）はここに残す＝boot.env が欠けても守りが消えないように。

DISCORD_BOT_TOKEN="${DISCORD_BOT_TOKEN:-00000000:xxxxxxxxxxxxxxxxxxxxxxxxxxxx}"
DISCORD_CHANNEL_ID="${DISCORD_CHANNEL_ID:-xxxxxxxxxxx}"
# claude の終了（exit code・メモリ状況）を残すログ。クラッシュ解析用（.gitignore 済み・1行/再起動なので肥大しない）。
# 相対パス（上で cd 済みなのでリポジトリ直下基準）。
BOOT_LOG="${BOOT_LOG:-logs/boot.log}"

# claude の共通起動コマンド（配列）。会話継続の -c は起動時に付け外しする（下の fresh-reboot 分岐参照）。
# --debug-file: 謎の自発終了（exit 0 など）の直前挙動を残すデバッグログ。出力先は logs/（別リポ symlink・
# .gitignore 済み）。--debug-file は暗黙で debug モードを有効化する。肥大しうるので必要なら適宜ローテート/削除。
CLAUDE_COMMAND=(claude --name nilkani06 --dangerously-skip-permissions --remote-control --channels plugin:discord@claude-plugins-official --debug-file logs/claude-debug.log)

notify_discord() {
  local -r text="$1"
  [[ -z "${DISCORD_BOT_TOKEN}" || -z "${DISCORD_CHANNEL_ID}" ]] && return 0
  # JSON は jq でエスケープして組み立てる（引用符・改行・制御文字を含む動的テキストでも壊れない）。
  local payload
  payload="$(jq -nc --arg c "${text}" '{content:$c}')" || return 0
  # トークンは curl の引数に載せず、--config - で stdin から渡す（引数だと走っている間 ps や /proc/<pid>/cmdline から読める。
  # 坂本＝~/zerozari00/watch.bash の形。takano32「坂本の参考になるところ、ぜんぶパクろう」2026-11-22・管理チャンネル）。
  printf 'header = "Authorization: Bot %s"\n' "${DISCORD_BOT_TOKEN}" | curl -s --config - -X POST \
    -H "Content-Type: application/json" \
    --data-binary "${payload}" \
    "https://discord.com/api/v10/channels/${DISCORD_CHANNEL_ID}/messages" \
    > /dev/null 2>&1 || true
}

# 現在のメモリ/スワップ/端末アタッチ状況を返す（クラッシュ時に逼迫やコンソールアクセスがあったか残すため。
# 「コンソールにアタッチすると claude がバグって exit=0 で落ちることがある」という体感を後から統計的に
# 検証できるように、takano32 指示で 2026-07-11 に screen 状況を追加）。
# 2026-10-15: ①screen の一覧を自分のセッション名（$STY の "pid." より後ろ）で絞る＝従来は一覧の1行目を拾っていたので、
#   セッションが複数あると別セッション（rust-http-proxy）の状態を書いていた。②herdr のペインの下（HERDR_SOCKET_PATH あり）では
#   クライアントソケットへの接続数で判定する（herdr の API に接続数は無い。skills/ops/herdr/SKILL.md §4）。
#   出力の形は従来どおり「, screen (Attached)」。herdr なら「, herdr (Attached)」。判定できなければ欄ごと出さない。
mem_snapshot() {
  local mem_swap term_status="" sock sess
  mem_swap="$(free -m 2>/dev/null | awk '/^Mem:/{m=$3"/"$2"MB"} /^Swap:/{s=$3"/"$2"MB"} END{printf "mem %s, swap %s", m, s}')"
  if [[ -n "${HERDR_SOCKET_PATH:-}" ]]; then
    sock="${HERDR_SOCKET_PATH%.sock}-client.sock"
    if [[ "$(ss -xH state connected 2>/dev/null | grep -c -F "${sock}")" -gt 0 ]]; then
      term_status="herdr (Attached)"
    else
      term_status="herdr (Detached)"
    fi
  else
    sess="${STY#*.}"; [[ -z "${STY:-}" ]] && sess="nilkani06"
    term_status="$(screen -ls 2>/dev/null | awk -v s="${sess}" '
      $1 ~ /^[0-9]+\./ { n = $1; sub(/^[0-9]+\./, "", n)
        if (n == s) { if ($0 ~ /\(Attached\)/) print "screen (Attached)"; else if ($0 ~ /\(Detached\)/) print "screen (Detached)"; exit } }')"
  fi
  if [[ -n "${term_status}" ]]; then
    printf '%s, %s' "${mem_swap}" "${term_status}"
  else
    printf '%s' "${mem_swap}"
  fi
}

# ── API プロキシ自動検知（LiteLLM / Claude Code Router 等）──────────────────
# ローカルで既知のプロキシが居たら、claude 起動前に ANTHROPIC_BASE_URL をそこへ向ける。
# 毎ループ（＝再起動のたび）に再判定し、どれも居なければ**未設定（unset）**にする
# （検知なし＝unset は takano32 指定。プロキシが死んだ後の再起動で古い向き先を引き継がない）。
# 誤検知対策の二段検査（takano32 指示）：
#   1) TCP Listen（ss）
#   2) POST /v1/messages が HTTP 応答し、404/405 以外かつ JSON を返すこと
#      （実プロキシは未認証でも 400/401 の JSON エラーを返す。開発サーバ/SPA は 404 や HTML で弾ける。
#       誤検知＝別物に向けると bot 全断なので、疑わしきは不採用に倒す）
# 並びは GitHub スター降順（takano32 指定。2026-07 実測: Open WebUI 144.1k > LiteLLM 52.5k >
# Claude Code Router 35.5k > Portkey 12.3k > claude-code-proxy 3.7k(1rgs)/2.7k(fuergaosi233) >
# pxpipe 556 > ccg-router 1）。
# 4000 は LiteLLM と ccproxy の既定が同じ＝ラベル併記。8082 は claude-code-proxy 系
# （1rgs=Python / fuergaosi233=Python、Go 等の書き直し版もドロップイン互換で 8082 踏襲が通例）を
# まとめてカバー（README 実測で両者とも ANTHROPIC_BASE_URL=http://localhost:8082）。
# 8080=Open WebUI は汎用ポートだが、二段検査（/v1/messages プローブ）が誤検知を弾けるため対象に
# 復帰（takano32 指示 2026-07-04。プローブに答えない別物が 8080 に居ても不採用になる）。
PROXY_CANDIDATES=(
  "8080:Open WebUI"
  "4000:LiteLLM/ccproxy"
  "3456:Claude Code Router"
  "8787:Portkey Gateway"
  "8082:claude-code-proxy"
  "47821:pxpipe"
  "17180:ccg-router"
)

# ポート上のサーバが Anthropic Messages API を喋るか軽くプローブする（ローカルのみ・2秒上限）。
probe_messages_api() {
  local port="$1" out code ctype
  out="$(curl -s -o /dev/null -w '%{http_code} %{content_type}' --max-time 2 \
    -X POST "http://127.0.0.1:${port}/v1/messages" \
    -H 'Content-Type: application/json' --data '{}' 2>/dev/null)" || return 1
  code="${out%% *}"
  ctype="${out#* }"
  [[ "${code}" =~ ^[0-9]+$ ]] || return 1
  (( code >= 200 && code != 404 && code != 405 )) || return 1
  [[ "${ctype}" == *json* ]] || return 1
}

# 検知したら "ポート:名前" を1行出力して 0 を返す。居なければ出力なしで 1。
detect_api_proxy() {
  local ent port
  for ent in "${PROXY_CANDIDATES[@]}"; do
    port="${ent%%:*}"
    ss -Hltn "sport = :${port}" 2>/dev/null | grep -q . || continue
    probe_messages_api "${port}" || continue
    printf '%s\n' "${ent}"
    return 0
  done
  return 1
}

# .env の読み込み（takano32 指示 2026-11-22・管理チャンネル。形は坂本＝~/zerozari00/loop.bash の load_env に倣った）。
# 下の while の中で claude を起こすたびに呼ぶので、.env を書き換えたら /quit だけで反映される（systemctl restart は不要）。
# systemd の EnvironmentFile はそのまま残す（loop.bash より前に動く boot.bash と、ここが読めなかったときのため）。
# 前回 .env から読んだ鍵を先に捨ててから読む＝.env から消した行も次の起動で消える
# （捨てないと、source と同じくファイルに無い鍵が前の値のまま残る。坂本の 2026-10-18 の実測と同じ形）。
# ⚠️ source しない＝.env は systemd の書式で、bash として実行すると値の中の $ や空白が化ける。KEY=VALUE の行だけを字のまま export する。
# ⚠️ 値は画面にもログにも出さない（読み損じた行は鍵の名前だけ数える）。
declare -a env_loaded_keys=()
load_env() {
  [[ -r .env ]] || { printf '[%s] .env が読めない。前回の値のまま起動します\n' "$(date -Iseconds)" | tee -a "${BOOT_LOG}"; return 1; }
  local line key val
  local -a keys=()
  ((${#env_loaded_keys[@]})) && unset "${env_loaded_keys[@]}"
  while IFS= read -r line || [[ -n "${line}" ]]; do
    line="${line%$'\r'}"
    [[ "${line}" =~ ^[[:space:]]*(export[[:space:]]+)?([A-Za-z_][A-Za-z0-9_]*)=(.*)$ ]] || continue
    key="${BASH_REMATCH[2]}"; val="${BASH_REMATCH[3]}"  # 次の =~ で BASH_REMATCH が消えるので先に取る
    if [[ "${val}" =~ ^\"(.*)\"$ || "${val}" =~ ^\'(.*)\'$ ]]; then val="${BASH_REMATCH[1]}"; fi
    export "${key}=${val}"
    keys+=("${key}")
  done < .env
  env_loaded_keys=("${keys[@]}")
}

# 停止の印（boot.bash が SIGTERM を受けて置く）。claude が終わった直後とループの頭で見て、あれば起こし直さずに exit 0 で抜ける。
# boot.bash はペインの claude に /quit を届け、claude が消える（SessionEnd フックが走りきる）のを待ってから器を畳む。
# 坂本＝~/zerozari00/loop.bash の on_term と STOP_MARK に倣った（2026-11-22 takano32「坂本の参考になるところ、ぜんぶパクろう」・管理チャンネル）。
STOP_MARK="configs/stop_requested"
stop_if_requested() {
  [[ -f "${STOP_MARK}" ]] || return 0
  rm -f "${STOP_MARK}"
  printf '[%s] %s。停止要求を見たので、起こし直さずに抜けます\n' "$(date -Iseconds)" "$1" | tee -a "${BOOT_LOG}"
  notify_discord "🦀 ニルカニちゃん六世を止めます（停止要求）🌙"
  exit 0
}

declare -i restart_count=0
declare -i fast_exits=0 # 連続即死（起動60秒未満で終了）の回数。クラッシュループ検知用
while true; do
  stop_if_requested "claude を起こす前"
  load_env

  # 環境変数を毎回読み直す。boot.env を書き換えたら /quit だけで反映される（systemctl restart は不要）。
  # ⚠️ source は中身を実行するので、書き損じ1つでこのループが死ぬ。先に構文を見る。
  # ⚠️ 通らなければ前回の値のまま起動する（起動を止めない）。
  if [[ -f boot.env ]]; then
    if bash -n boot.env 2>/dev/null; then
      set -o allexport; . ./boot.env; set +o allexport
    else
      printf '[%s] boot.env に構文エラー。前回の値のまま起動します\n' "$(date -Iseconds)" | tee -a "${BOOT_LOG}"
    fi
  fi

  # プロキシ検知 → ANTHROPIC_BASE_URL 切替（検知なしなら未設定）。claude 起動の前に毎回行う。
  proxy_note=""
  if proxy_ent="$(detect_api_proxy)"; then
    proxy_port="${proxy_ent%%:*}"
    proxy_name="${proxy_ent#*:}"
    # export ANTHROPIC_BASE_URL="http://127.0.0.1:${proxy_port}"
    proxy_note="（API経由: ${proxy_name} :${proxy_port}）"
    printf '[%s] %s (:%s) を検知 → ANTHROPIC_BASE_URL=%s\n' "$(date -Iseconds)" "${proxy_name}" "${proxy_port}" "${ANTHROPIC_BASE_URL:-（未設定。切り替えは止めてある）}" | tee -a "${BOOT_LOG}"
  else
    # unset ANTHROPIC_BASE_URL
    echo
  fi

  if (( restart_count == 0 )); then
    notify_discord "🦀 ニルカニちゃん六世を起動します🌅${proxy_note}"
  else
    notify_discord "🦀 ニルカニちゃん六世を再起動します🌅${proxy_note}"
  fi
  (( restart_count++ )) || true
  started_at=${EPOCHSECONDS}

  # claude を起動。終了コードを捕捉する（set -e は無効なので、非ゼロ終了でもループは止まらない）。
  # ※ stdout/stderr はそのまま（コンソール表示・TTY 挙動を壊さないため pipe しない）。
  # ワンショットのフレッシュ起動（-c なし）：configs/refresh が在れば、CLAUDE.md/AGENTS.md を
  # 確実に読み直すため -c を外して起動する（＝新しい会話）。起動直前に消すので一回限り＝次回からは
  # 通常どおり -c で会話を継続する（継続性は維持・新ルールだけ一度クリーンに反映）。Linux の /forcefsck 等に倣う。
  if [[ -f configs/refresh ]]; then
    rm -f configs/refresh
    notify_discord "🦀 フレッシュ起動（-c なし）で立ち上げます。CLAUDE.md/AGENTS.md を読み直します🆕"
    "${CLAUDE_COMMAND[@]}"
  else
    "${CLAUDE_COMMAND[@]}" -c
  fi
  exit_code=$?
  stop_if_requested "claude が exit=${exit_code} で終了（稼働$(( EPOCHSECONDS - started_at ))秒）"

  # クラッシュループ対策：すぐ死ぬ（60秒未満）が続くほど待ちを指数的に伸ばす（5→10→…→300秒上限）。
  # claude 更新の失敗などで即死ループに入ったとき、Discord 通知の洪水と無駄な連続再起動を防ぐ。
  # 60秒以上走った通常の終了・クラッシュは従来どおり5秒で復帰（fast_exits リセット）。
  runtime=$(( EPOCHSECONDS - started_at ))
  if (( runtime < 60 )); then
    (( fast_exits++ )) || true
  else
    fast_exits=0
  fi
  delay=$(( 5 * (1 << (fast_exits > 6 ? 6 : fast_exits)) ))
  (( delay > 300 )) && delay=300

  # 終了の記録（コンソールに出しつつ boot.log にも追記）＋ Discord 通知。次にこけたとき原因を追えるように。
  snap="$(mem_snapshot)"
  printf '[%s] claude が exit=%s で終了（%s・稼働%s秒）。%s秒後に再起動します\n' "$(date -Iseconds)" "${exit_code}" "${snap}" "${runtime}" "${delay}" | tee -a "${BOOT_LOG}"
  notify_discord "🦀 ニルカニちゃん六世が終了（exit ${exit_code}）→ ${delay}秒後に再起動します🔄  [${snap}]"
  sleep "${delay}"
done
