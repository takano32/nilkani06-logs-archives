#!/usr/bin/env python3
"""WebSocket のクライアント（RFC 6455。標準ライブラリの asyncio と ssl だけで書いた最小の実装）。

Python の標準ライブラリに WebSocket は無い。旧 watcher.js は Bun に組み込みの WebSocket を使っていたので、
2026-11-21 に Python へ書き直したとき、watcher が使うぶんだけをここに書いた。使うのは watcher.py の ws_loop だけ。

やること：
  - `ws://` と `wss://` へつなぎ、HTTP の Upgrade をやり取りする（`Sec-WebSocket-Accept` を確かめる）
  - テキストとバイナリのフレームを受ける（分割されたメッセージをつなぐ。長さは 7bit、16bit、64bit の3通り）
  - ping に同じ中身の pong を返す（返さないと、相手は接続を切る）
  - close を受けたら close を返して閉じる。close なしで切れたら 1006 として扱う（Bun の WebSocket と同じ数字）

やらないこと：拡張（permessage-deflate）、サブプロトコル、こちらからのメッセージ送信。
相手が黙って落ちたのに気づけるよう、ソケットに TCP の keepalive を付けてある（気づいたら 1006 で切れた扱いになる）。
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import os
import socket
import ssl
import struct
from urllib.parse import urlsplit

_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
_MAX_MESSAGE = 64 * 1024 * 1024  # これを超える1メッセージは受けない（壊れた相手でメモリを食い潰さない）
CONNECT_TIMEOUT_SEC = 30

OP_CONT, OP_TEXT, OP_BINARY, OP_CLOSE, OP_PING, OP_PONG = 0x0, 0x1, 0x2, 0x8, 0x9, 0xA


class WSError(Exception):
    """接続できない、Upgrade が通らない、フレームが規格から外れている。"""


class WSTarget:
    """つなぐ先（URL を読んだ結果）。"""

    def __init__(self, url: str, secure: bool, host: str, port: int, path: str) -> None:
        self.url = url
        self.secure = secure
        self.host = host
        self.port = port
        self.path = path


def parse_url(url: str) -> WSTarget:
    """URL を読む。読めなければ ValueError（旧版で `new WebSocket(url)` がその場で投げていた場合に当たる）。"""
    try:
        u = urlsplit(url)
        port = u.port
    except ValueError as e:
        raise ValueError(f"'{url}' is not a valid URL: {e}") from None
    scheme = (u.scheme or "").lower()
    if scheme not in ("ws", "wss", "http", "https") or not u.hostname:
        raise ValueError(f"'{url}' is not a valid WebSocket URL")
    secure = scheme in ("wss", "https")
    path = (u.path or "/") + ("?" + u.query if u.query else "")
    return WSTarget(url, secure, u.hostname, port or (443 if secure else 80), path)


def _mask(data: bytes, key: bytes) -> bytes:
    n = len(data)
    if n == 0:
        return data
    k = (key * (n // 4 + 1))[:n]
    return (int.from_bytes(data, "big") ^ int.from_bytes(k, "big")).to_bytes(n, "big")


class WebSocket:
    """つながった接続。recv() でメッセージを1つずつ受ける。"""

    def __init__(self, target: WSTarget, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        self.target = target
        self._r = reader
        self._w = writer
        self.close_code: int | None = None
        self._closed = False

    @classmethod
    async def connect(cls, target: WSTarget, *, user_agent: str = "watcher/1.0",
                      timeout: float = CONNECT_TIMEOUT_SEC) -> "WebSocket":
        """つないで Upgrade まで済ませる。だめなら WSError。"""
        fail = f"WebSocket connection to '{target.url}' failed: "
        try:
            return await asyncio.wait_for(cls._connect(target, user_agent, fail), timeout)
        except asyncio.TimeoutError:
            raise WSError(fail + "Timeout") from None
        except WSError:
            raise
        except (OSError, ssl.SSLError, asyncio.IncompleteReadError, asyncio.LimitOverrunError, ValueError) as e:
            raise WSError(fail + (str(e) or type(e).__name__)) from None

    @classmethod
    async def _connect(cls, target: WSTarget, user_agent: str, fail: str) -> "WebSocket":
        ctx = ssl.create_default_context() if target.secure else None
        reader, writer = await asyncio.open_connection(target.host, target.port, ssl=ctx,
                                                       server_hostname=target.host if target.secure else None)
        try:
            sock = writer.get_extra_info("socket")
            if sock is not None:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                for opt, val in (("TCP_KEEPIDLE", 60), ("TCP_KEEPINTVL", 15), ("TCP_KEEPCNT", 4)):
                    if hasattr(socket, opt):
                        sock.setsockopt(socket.IPPROTO_TCP, getattr(socket, opt), val)
            key = base64.b64encode(os.urandom(16)).decode()
            default_port = 443 if target.secure else 80
            host = target.host if ":" not in target.host else f"[{target.host}]"
            host_header = host if target.port == default_port else f"{host}:{target.port}"
            writer.write((f"GET {target.path} HTTP/1.1\r\nHost: {host_header}\r\nUpgrade: websocket\r\n"
                          f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n"
                          f"User-Agent: {user_agent}\r\n\r\n").encode("latin1"))
            await writer.drain()
            head = (await reader.readuntil(b"\r\n\r\n")).decode("latin1")
            lines = head.split("\r\n")
            parts = lines[0].split(" ", 2)
            status = parts[1] if len(parts) > 1 else ""
            if not lines[0].startswith("HTTP/1.1 ") or status != "101":
                raise WSError(fail + "Expected 101 status code" + (f": {status}" if status else ""))
            headers: dict[str, str] = {}
            for ln in lines[1:]:
                if ":" in ln:
                    k, v = ln.split(":", 1)
                    headers[k.strip().lower()] = v.strip()
            if headers.get("upgrade", "").lower() != "websocket":
                raise WSError(fail + "Missing upgrade header")
            want = base64.b64encode(hashlib.sha1((key + _GUID).encode()).digest()).decode()
            if headers.get("sec-websocket-accept") != want:
                raise WSError(fail + "Mismatch websocket accept header")
            if headers.get("sec-websocket-extensions"):
                raise WSError(fail + "Mismatch client extensions")
        except BaseException:
            writer.transport.abort()
            raise
        return cls(target, reader, writer)

    async def _send(self, opcode: int, payload: bytes = b"") -> None:
        # クライアントからのフレームは必ずマスクする（RFC 6455 5.3）。
        key = os.urandom(4)
        n = len(payload)
        if n < 126:
            head = struct.pack("!BB", 0x80 | opcode, 0x80 | n)
        elif n < 65536:
            head = struct.pack("!BBH", 0x80 | opcode, 0x80 | 126, n)
        else:
            head = struct.pack("!BBQ", 0x80 | opcode, 0x80 | 127, n)
        self._w.write(head + key + _mask(payload, key))
        await self._w.drain()

    async def _frame(self) -> tuple[int, bool, bytes]:
        b0, b1 = await self._r.readexactly(2)
        if b0 & 0x70:
            raise WSError("Invalid frame: reserved bits set")
        if b1 & 0x80:
            raise WSError("Invalid frame: masked frame from server")
        fin, opcode, n = bool(b0 & 0x80), b0 & 0x0F, b1 & 0x7F
        if n == 126:
            (n,) = struct.unpack("!H", await self._r.readexactly(2))
        elif n == 127:
            (n,) = struct.unpack("!Q", await self._r.readexactly(8))
        if opcode >= 0x8 and (n > 125 or not fin):
            raise WSError("Invalid frame: control frame too long or fragmented")
        if n > _MAX_MESSAGE:
            raise WSError("Invalid frame: message too big")
        return opcode, fin, await self._r.readexactly(n) if n else b""

    async def recv(self) -> str | None:
        """次のメッセージ（文字列）を返す。接続が閉じたら None（閉じた理由の番号は close_code）。

        バイナリのフレームも UTF-8 として文字列にする（旧版が `ev.data.toString()` で読んでいたのと同じ）。
        """
        if self._closed:
            return None
        parts: list[bytes] = []
        size = 0
        started = False
        while True:
            try:
                opcode, fin, data = await self._frame()
            except (asyncio.IncompleteReadError, ConnectionError, OSError, ssl.SSLError):
                # close のやり取りなしに切れた（強制切断・瞬断・keepalive の時間切れ）
                self._abort(1006)
                return None
            except WSError:
                self._abort(1002)
                raise
            if opcode == OP_PING:
                try:
                    await self._send(OP_PONG, data)
                except (ConnectionError, OSError):
                    self._abort(1006)
                    return None
                continue
            if opcode == OP_PONG:
                continue
            if opcode == OP_CLOSE:
                code = struct.unpack("!H", data[:2])[0] if len(data) >= 2 else 1005
                try:
                    await self._send(OP_CLOSE, data[:2])
                except (ConnectionError, OSError):
                    pass
                self._abort(code)
                return None
            if opcode in (OP_TEXT, OP_BINARY):
                if started:
                    self._abort(1002)
                    raise WSError("Invalid frame: new message before the previous one finished")
                started = True
            elif opcode == OP_CONT:
                if not started:
                    self._abort(1002)
                    raise WSError("Invalid frame: continuation without a start")
            else:
                self._abort(1002)
                raise WSError(f"Invalid frame: unknown opcode {opcode}")
            parts.append(data)
            size += len(data)
            if size > _MAX_MESSAGE:
                self._abort(1009)
                raise WSError("Invalid frame: message too big")
            if fin:
                return b"".join(parts).decode("utf-8", "replace")

    def _abort(self, code: int) -> None:
        if self._closed:
            return
        self._closed = True
        self.close_code = code
        try:
            self._w.transport.abort()
        except Exception:
            pass

    def abort(self) -> None:
        """こちらから切る（close のやり取りはしない）。"""
        self._abort(self.close_code if self.close_code is not None else 1006)
