#!/usr/bin/env python3
"""落とした動画のファイル名の決まりを、1箇所のコードに持つ。

**なぜコードなのか**（takano32 指示 2026-09-02・会話チャンネル＝「スキルの文章だと忘れるからコードにしてほしいな」）。
決まりを散文で持つと、次に書く人が読まずに `yt-dlp` の既定のまま落とす。
**散文は「守る」ことを人に要求するが、コードは呼ぶだけで守られる。**
（`skills/agents/SKILL.md`「うちの運用に取り込んだ金言」。2026-09-26 に `AGENTS.md`「先人の金言」から移った＝「習慣でなくシステムを直せ。『気をつける』は実装できない」）

**決まりは1つだけ**＝`<ID>_<タイトル>.<拡張子>`。

- **ID が先頭**＝シェルのファイル名補完は前方一致なので、ID が末尾（`yt-dlp` の既定
  `%(title)s [%(id)s].%(ext)s`）だとタイトルを打たないと候補が減らない。
- **区切りはアンダースコア1つ**＝`sm46` まで打てば決まる。
  **⚠️ タイトルの中の空白は潰さない**（takano32 判断 2026-09-02＝「ID の直後だけでいいかな、
  補完にはそれで充分」）。潰しても補完は良くならず、元のタイトルから離れるぶんだけ読みにくくなる。
- **角かっこを付けない**＝`[` はシェルのグロブ文字で、補完のたびに退避が要る。

**⚠️ 保存先はここでは決めない**＝`$HOME/Videos`（`skills/videos/download.md`）。
置き場と名前は別の関心事なので、混ぜない。

使い方:

    import sys, pathlib
    # 置き場は段数で数えず、site-python/ を持ついちばん近い上のディレクトリから探す（skills/<名前>/ のどの深さからでも同じ）
    sys.path.insert(0, str(next(p for p in pathlib.Path(__file__).resolve().parents if (p / "site-python").is_dir()) / "site-python"))
    import _video_naming as vn

    cmd = ["yt-dlp", *vn.ytdlp_output_args(), url]

手で叩くときは、リポジトリの設定ファイルを渡す（同じ値が入っている）:

    yt-dlp --config-locations skills/videos/yt-dlp.conf "<URL>"
"""

# yt-dlp の出力テンプレート。**ここが唯一の定義。**
OUTTMPL = "%(id)s_%(title)s.%(ext)s"


def ytdlp_output_args() -> list[str]:
    """`yt-dlp` に渡す、ファイル名まわりの引数。

    保存先（`-P`）は含めない＝呼ぶ側が決める。
    """
    return ["-o", OUTTMPL]


def expected_basename(video_id: str, title: str, ext: str) -> str:
    """同じ決まりで組んだファイル名（テストと突き合わせ用）。

    ⚠️ `yt-dlp` はファイル名に使えない文字を自分で置き換えるので、
    **実際に落ちた名前と一致するとは限らない。**照合ではなく、決まりの説明に使う。
    """
    return f"{video_id}_{title}.{ext}"
