#!/usr/bin/env python3
"""watcher.py と targets/*.py が使う実行まわりの部品（タイマー、外部コマンド、HTTP）。

watcher は 1 プロセスの asyncio のループ1本で全部の対象を回す（旧 watcher.js のイベントループと同じ形）。
ここの部品は、旧版が使っていた JavaScript の道具と同じ振る舞いになるよう作ってある：

  set_interval / set_timeout … setInterval / setTimeout
  spawn ……………………………… 待たずに走らせる async 関数（`f().catch(...)` の形）
  exec_file_sync ……………… child_process.execFileSync（終わるまでループを止める。失敗は ExecError）
  exec_file …………………… child_process.execFile（ループを止めない）
  fetch_text …………………… fetch（ループを止めない。4xx/5xx でも例外にせず、状態と本文を返す）

依存は標準ライブラリだけ。
"""
from __future__ import annotations

import asyncio
import os
import signal
import subprocess
import urllib.error
import urllib.request
from collections.abc import Awaitable, Callable

from _jscompat import encode_utf8

# リポジトリルート（末尾に / を付けてある。このファイルはリポジトリ直下の site-python/ にある → 1 つ上）。
# 旧版は本体と対象のそれぞれが自分の位置から数えていたのを、ここ1か所にした。
# ⚠️ このファイルを別の深さへ移すときは、ここを数え直す（対象はこの値から logs/ や skills/、configs/ の場所を作る）。
APP_ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__))) + "/"

# 外へ出す HTTP の名乗り。Python の既定（Python-urllib/3.x）は相手によって断られるので、固定の名前を付ける。
USER_AGENT = "watcher/1.0"


def write_fd(fd: int, data: bytes) -> None:
    """fd へ書く（1行を1回の write で出す＝途中で切れた行を作らない。出力先が閉じていても落ちない）。"""
    try:
        while data:
            n = os.write(fd, data)
            data = data[n:]
    except OSError:
        pass


def err_msg(e: BaseException) -> str:
    """ログに書く例外の文（旧版の `e?.message || e` に当たる）。"""
    if isinstance(e, ExecError):
        return e.message
    s = str(e)
    return s if s else type(e).__name__


# --- タイマーと並行 -----------------------------------------------------------------------------------------

# 走っている途中のタスクを、終わるまで強く参照しておく置き場。
# asyncio のループは、タスクを弱い参照でしか持たない。タスクが待っている相手も外から強く参照されていないと、
# GC（ガベージコレクション）のときに「Task was destroyed but it is pending!」と出て、タスクが途中で消える
# （公式の注意書き: https://docs.python.org/3/library/asyncio-task.html#asyncio.create_task ）。
# クライアント側のソケットを読むタスクがこれに当たる（asyncio のプロトコルは、読み手の StreamReader を弱い参照でしか持たない）。
# ⚠️ 2026-11-21 の最初の入れ替えで、これが無くて地震の WebSocket を読むタスクが起動の 60 秒後に消えた
# （接続が消え、切断のログも再接続も出ない。旧版へ戻した）。待たずに走らせるタスクは、必ず spawn で作る。
_TASKS: set[asyncio.Task] = set()


def spawn(coro: Awaitable, on_error: Callable[[BaseException], None] | None = None) -> asyncio.Task:
    """async 関数を待たずに走らせる。例外は on_error へ渡す（無ければループの例外ハンドラへ行く）。

    ループのタスク工場を eager にしてあるので（watcher.py）、JavaScript の async 関数と同じく、
    最初の待ちに当たるまでは、呼んだその場で実行される。
    タスクは終わるまで _TASKS が持つ（返り値を捨てても、途中で GC に捨てられない）。
    """
    task = asyncio.ensure_future(coro)
    _TASKS.add(task)
    task.add_done_callback(_TASKS.discard)

    def done(t: asyncio.Task) -> None:
        if t.cancelled():
            return
        e = t.exception()
        if e is None:
            return
        if on_error is not None:
            try:
                on_error(e)
            except Exception as e2:  # 例外の後始末で落ちない
                asyncio.get_running_loop().call_exception_handler({"message": "on_error で例外", "exception": e2})
        else:
            asyncio.get_running_loop().call_exception_handler({"message": "待っていない処理で例外", "exception": e})

    task.add_done_callback(done)
    return task


def _call(fn: Callable[[], object]) -> None:
    r = fn()
    if asyncio.iscoroutine(r):
        spawn(r)


def set_timeout(fn: Callable[[], object], ms: float) -> asyncio.TimerHandle:
    """ms ミリ秒後に fn を1回呼ぶ。返り値の cancel() で取り消せる。"""
    return asyncio.get_running_loop().call_later(max(0.0, ms) / 1000, _call, fn)


class Interval:
    """set_interval の返り値（cancel() で止める）。"""

    def __init__(self, fn: Callable[[], object], ms: float) -> None:
        self._fn = fn
        self._period = max(0.001, ms / 1000)
        self._loop = asyncio.get_running_loop()
        self._handle: asyncio.TimerHandle | None = self._loop.call_later(self._period, self._fire)

    def _fire(self) -> None:
        # 次は「いま撃った時刻＋周期」（Bun の setInterval と同じ。2026-11-21 に bun と並べて測った）。
        # ループが止まっていて発火が遅れたら、その遅れのぶん以後の刻みも後ろへずれる。遅れを取り戻すための
        # 詰めた発火はしない（予定の刻みに戻す形にすると、遅れた直後の1回だけ間隔が短くなり、旧版と tick の間隔が変わる）。
        # 次の予約は fn を呼ぶ前に入れる＝fn が長く止めても、次の発火は「fn を呼び始めた時刻＋周期」になる。
        self._handle = self._loop.call_later(self._period, self._fire)
        _call(self._fn)

    def cancel(self) -> None:
        if self._handle is not None:
            self._handle.cancel()
            self._handle = None


def set_interval(fn: Callable[[], object], ms: float) -> Interval:
    """ms ミリ秒ごとに fn を呼ぶ（最初の1回は ms 後）。fn が async なら待たずに走らせる。"""
    return Interval(fn, ms)


async def sleep(ms: float) -> None:
    await asyncio.sleep(max(0.0, ms) / 1000)


async def aw(x: object) -> object:
    """JavaScript の `await x` と同じ順序で待つ。

    JavaScript の await は、待つ相手がその場で終わっていても、いったん呼び手へ戻ってから続きを走らせる。
    Python の await は、相手がその場で終われば戻らずに続きを走らせる。この差で、動作ログの行の順が旧版と入れ替わる
    （例＝最初の tick の「見送り」が「run 開始」より先に出る）。その場で終わりうる相手を待つ所は、これを通す。
    """
    r = await x if asyncio.iscoroutine(x) or asyncio.isfuture(x) else x
    await asyncio.sleep(0)
    return r


# --- 外部コマンド -------------------------------------------------------------------------------------------

class ExecError(Exception):
    """外部コマンドの失敗（終了コードが非0、シグナルで落ちた、時間切れ、起こせなかった）。

    message の形は旧版（Bun の child_process）と同じにしてある。`logs/watcher.log` の
    `[warn] herdr への注入に失敗: Command failed: …` の行は、この文がそのまま出たもの。
    """

    def __init__(self, message: str, *, status: int | None = None, sig: str | None = None, code: str | int | None = None,
                 stdout: str = "", stderr: str = "", killed: bool = False) -> None:
        super().__init__(message)
        self.message = message
        self.status = status
        self.signal = sig
        self.code = code
        self.stdout = stdout
        self.stderr = stderr
        self.killed = killed


def _sig_name(n: int) -> str:
    try:
        return signal.Signals(n).name
    except ValueError:
        return f"SIG{n}"


def _spawn_error(file: str, e: OSError) -> ExecError:
    if isinstance(e, FileNotFoundError):
        return ExecError(f"ENOENT: no such file or directory, posix_spawn '{file}'", code="ENOENT")
    if isinstance(e, PermissionError):
        return ExecError(f"EACCES: permission denied, posix_spawn '{file}'", code="EACCES")
    return ExecError(f"{type(e).__name__}: {e}", code=type(e).__name__)


def exec_file_sync(file: str, args: list[str], *, timeout_ms: float | None = None, input: str | None = None,
                   env: dict[str, str] | None = None, cwd: str | None = None, echo_stderr: bool = False) -> str:
    """コマンドを最後まで走らせて stdout を返す。**終わるまでループごと止まる**（旧版の execFileSync と同じ）。

    echo_stderr=True は、子の stderr を終わったあとで自分の stderr にも流す指定（旧版で stdio を指定せずに
    execFileSync を呼んだときの振る舞い）。`logs/watcher.log` に `herdr-inject: 送出した（…）` のような
    JSON でない行が混じるのは、これがあるため。
    """
    try:
        proc = subprocess.Popen([file, *args], stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, cwd=cwd)
    except OSError as e:
        raise _spawn_error(file, e) from None
    timed_out = False
    data = encode_utf8(input) if input is not None else None
    try:
        out, err = proc.communicate(data, timeout=None if timeout_ms is None else timeout_ms / 1000)
    except subprocess.TimeoutExpired:
        timed_out = True
        proc.send_signal(signal.SIGTERM)
        try:
            out, err = proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            try:
                out, err = proc.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                out, err = b"", b""
    stdout = (out or b"").decode("utf-8", "replace")
    stderr = (err or b"").decode("utf-8", "replace")
    if echo_stderr and err:
        try:
            os.write(2, err)
        except OSError:
            pass
    if timed_out:
        raise ExecError(f"spawnSync {file} ETIMEDOUT", code="ETIMEDOUT", sig="SIGTERM", stdout=stdout, stderr=stderr)
    rc = proc.returncode
    if rc != 0:
        msg = "Command failed: " + " ".join([file, *args])
        if stderr:
            msg += "\n" + stderr
        if rc is not None and rc < 0:
            raise ExecError(msg, sig=_sig_name(-rc), stdout=stdout, stderr=stderr)
        raise ExecError(msg, status=rc, stdout=stdout, stderr=stderr)
    return stdout


class ExecResult:
    """exec_file の結果。err は成功なら None。"""

    def __init__(self, err: ExecError | None, stdout: str, stderr: str) -> None:
        self.err = err
        self.stdout = stdout
        self.stderr = stderr


async def exec_file(file: str, args: list[str], *, timeout_ms: float | None = None, env: dict[str, str] | None = None,
                    cwd: str | None = None) -> ExecResult:
    """コマンドを走らせて結果を返す。**ループを止めない**（旧版の execFile と同じ）。失敗も例外にせず err に入れる。"""
    try:
        proc = await asyncio.create_subprocess_exec(file, *args, stdin=asyncio.subprocess.DEVNULL,
                                                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                                                    env=env, cwd=cwd)
    except OSError as e:
        return ExecResult(_spawn_error(file, e), "", "")
    killed = False
    try:
        out, err = await asyncio.wait_for(proc.communicate(), None if timeout_ms is None else timeout_ms / 1000)
    except asyncio.TimeoutError:
        killed = True
        try:
            proc.send_signal(signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            out, err = await asyncio.wait_for(proc.communicate(), 5)
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            out, err = b"", b""
    stdout = (out or b"").decode("utf-8", "replace")
    stderr = (err or b"").decode("utf-8", "replace")
    cmd = " ".join([file, *args])
    if killed:
        return ExecResult(ExecError("Command failed: " + cmd, sig="SIGTERM", killed=True, stdout=stdout, stderr=stderr),
                          stdout, stderr)
    rc = proc.returncode
    if rc != 0:
        msg = "Command failed: " + cmd + ("\n" + stderr if stderr else "")
        if rc is not None and rc < 0:
            return ExecResult(ExecError(msg, sig=_sig_name(-rc), stdout=stdout, stderr=stderr), stdout, stderr)
        return ExecResult(ExecError(msg, status=rc, code=rc, stdout=stdout, stderr=stderr), stdout, stderr)
    return ExecResult(None, stdout, stderr)


def tmpdir() -> str:
    """一時ファイルの置き場（旧版の os.tmpdir() と同じ順で決める）。"""
    d = os.environ.get("TMPDIR") or os.environ.get("TMP") or os.environ.get("TEMP") or "/tmp"
    return d.rstrip("/") if len(d) > 1 else d


# --- HTTP ---------------------------------------------------------------------------------------------------

class FetchTimeout(Exception):
    def __str__(self) -> str:
        return "The operation timed out."


async def fetch_text(url: str, *, method: str = "GET", headers: dict[str, str] | None = None, body: bytes | None = None,
                     timeout_ms: float = 15000) -> tuple[int, str]:
    """URL を取って（状態コード, 本文）を返す。**ループを止めない。**

    4xx と 5xx も例外にしない（旧版の fetch と同じ。本文つきのエラー応答をそのまま読ませるため）。
    つながらない、時間切れ、は例外になる。timeout_ms は応答を読み終えるまでの全体の上限。
    """
    hdrs = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    hdrs.update(headers or {})
    timeout = timeout_ms / 1000

    def work() -> tuple[int, bytes]:
        req = urllib.request.Request(url, data=body, method=method, headers=hdrs)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            with e:
                return e.code, e.read()
        except urllib.error.URLError as e:
            if isinstance(e.reason, TimeoutError):
                raise TimeoutError() from None
            raise

    try:
        status, data = await asyncio.wait_for(asyncio.get_running_loop().run_in_executor(None, work), timeout)
    except (asyncio.TimeoutError, TimeoutError):
        raise FetchTimeout() from None
    text = data.decode("utf-8", "replace")
    if text.startswith("﻿"):
        text = text[1:]
    return status, text
