"""添付に渡す画像を「ディスクへ並べて落とす」ための共通部品（読み取り専用）。

`reply` の `files` は**パスしか受け取らない**ので、画像は一度どこかに置くしかない。
そこで**置き場をディスクに固定し、取得のたびに掃く**——この取り決めを、
pixiv / dlsite / fanza の3スキルで**1つに保つ**ためのモジュール。

⚠️ **同じ手順を3箇所に持たない**（このリポの規約）。取得・置き場・掃除・上限・
   manifest といった「どのサイトでも同じ部分」だけをここに置く。
   **どの URL を取るか**（API の形・セレクタ・Referer の要否）は各スキル側に残す。

  置き場 /var/tmp/<名前空間>-<キー>（**tmpfs には置かない**）
  掃除   取得のたびに自動。**STALE_MINUTES より古い置き場だけ**落とす
  上限   1ファイル 10MiB（超えたら代替 URL へ落とし、無ければ外して notes に理由）
  候補   `urls` は `[第1候補, 代替…]`。**「これは駄目」のときは、候補が尽きるまで次へ進む**
         ＝上限超え・プレースホルダ・**取得そのものの失敗**の3つとも同じ作法
         （2026-09-08 takano32 判断＝か。それまで取得の失敗だけ止まっていた）
  検出   URL が空（None・空文字）／既知のプレースホルダ（PLACEHOLDERS＝FANZA の now_printing.jpg）／
         Content-Length より短く切れた応答、の3つは**files に入れず notes に1行残す**（2026-09-04 の夢想で足した。
         それまでは3つとも「成功」で通るか、黙って消えていた）
  合図   最後に manifest.json を**不可分に**置く（先読みはこれが在ることだけを見る）

⚠️ この箱では `/tmp` も tmpfs なので、scratchpad に置いても結局 RAM を食う。
   RAM が詰まると箱ぜんたいが遅くなるので、置き場は必ず `/var/tmp`（ディスク）。

依存は標準ライブラリのみ。**ただし `trim_to_fit()` だけ外部の `ffmpeg`/`ffprobe` を使う**
（動画を「バイト数」ではなく「秒数」で切り直すため。下のコメント参照）。
"""
import argparse
import concurrent.futures as futures
import glob
import hashlib
import html as _html
import json
import os
import re
import shutil
import time
import urllib.request

# Discord の1通あたりの上限（ファイル数・1ファイルのバイト数）
MAX_FILES = 10
# ⚠️ 25MB ではない。11.2MB の PNG が Request entity too large で弾かれた（2026-08-18 実測）。
# このサーバーの実効上限は 10MiB とみて、超える1枚だけ表示用サイズへ落とす。
MAX_BYTES = 10 * 1024 * 1024
# 置き場は**必ずディスク**（RAM は本体に譲る。詰まると全体が遅くなる）
# ⚠️ この決めを書いたときの実測「RAM 952MB」は**旧箱（GCP e2-micro・〜2026-08-31）**のもの。
#    理屈（RAM を食い潰せば全体が遅くなる）は箱に依らないので、置き場の決めはそのまま。
#    いまの箱の素性は `.claude/skills/nilkani06-config-and-flags`、その場の空き RAM は `free -m`。
DISK_DIR = "/var/tmp"
# 置き忘れの後始末＝この時間より古い置き場は落とす（送信が落ちた回の残骸を残さない）
STALE_MINUTES = 10
# 置き場を作れる場所（--clean の行き先を検査するときにも使う）
ALLOWED_ROOTS = ("/var/tmp", "/tmp", "/dev/shm")


# --- 置き場 -----------------------------------------------------------------
def store_dir(namespace: str, key: str) -> str:
    """置き場のパス（既定 /var/tmp/<名前空間>-<キー>）。"""
    return os.path.join(DISK_DIR, f"{namespace}-{key}")


def sweep(namespace: str, keep: str | None = None) -> list[str]:
    """**古くなった置き場だけ**を落とす。取得のたびに走る。

    ⚠️⚠️ 「いま作る置き場以外を全部消す」ではない（2026-08-18 に一度そう書いて壊した）。
       **先読みは「次の作品の置き場を先に作って持っておく」仕組みなので、全消しと両立しない。**
       実際、先読みしておいた束が送信の直前に消えて `ENOENT` で送信が落ちた。
       **だから時間で切る**＝**STALE_MINUTES より古いものだけ**を落とす。
       先読み中の束は新しいので残り、送信が落ちた回の残骸は次の取得で必ず落ちる。

    ⚠️ 判定は**経過時間だけ**で、誰が・どの用途で置いたかは見ない。
       **取得したのに10分以上送らずに置いておくと、まだ使うつもりの束でも次の掃除で消える**
       （2026-09-02・pixiv のうごイラ #178・#179・#183。間に挟んだ別の作品の処理が長引いて
       10分を超え、送る前に置き場が消えていた。送信前に気づいたので実害は無し）。

    ⚠️ glob は `{namespace}-*` の**前方一致**なので、`namespace` が別の名前空間の接頭辞に
       なっていると巻き込む。**`pixiv` と `pixiv-ugoira` がこれに当たる**
       （`/var/tmp/pixiv-*` は `/var/tmp/pixiv-ugoira-<id>` にもマッチする＝実測で確認済み）。
       ＝**通常画像（`pages.py`、名前空間 `pixiv`）の取得が回す自動掃除が、待機中のうごイラ
       （名前空間 `pixiv-ugoira`）の置き場も一緒に古さ判定にかける。**上のうごイラの事例はこれが
       実際の引き金。名前空間を増やすときは、既存の名前空間の接頭辞にならない名前を選ぶこと。
    """
    removed = []
    now = time.time()
    targets: list[str] = []
    for root in ALLOWED_ROOTS:
        targets.extend(glob.glob(f"{root}/{namespace}-*"))
    for d in targets:
        if keep and os.path.abspath(d) == os.path.abspath(keep):
            continue
        try:
            if now - os.path.getmtime(d) < STALE_MINUTES * 60:
                continue  # 新しいものは触らない（先読みぶんかもしれない）
        except OSError:
            continue
        try:
            if os.path.isdir(d):
                shutil.rmtree(d, ignore_errors=True)
            else:
                os.remove(d)
            removed.append(d)
        except OSError:
            pass
    return removed


def clean(path: str, namespace: str, key_pattern: str = r"[\w.-]+") -> None:
    """置き場を消す。**自分が作った形のディレクトリだけ**に絞る（誤爆防止）。

    形に合わなければ ValueError（呼ぶ側が sys.exit に変える）。
    """
    roots = "|".join(re.escape(r) for r in ALLOWED_ROOTS)
    if not re.fullmatch(rf"({roots})/[\w.-]*{namespace}-{key_pattern}", path.rstrip("/")):
        raise ValueError(f"消せるのは {namespace}-<id> の置き場だけです: {path}")
    shutil.rmtree(path, ignore_errors=True)


# --- Discord の本文 ---------------------------------------------------------
# Discord のリンクの表示名は、角かっこで終わりを決める。中に生の `]` が入るとそこで切れる。
# ⚠️ バックスラッシュの打ち消しは通らない（2026-08-18 実測＝表示名の中では `\[` `\]` がそのまま見える）。
#    だから打ち消すのではなく、全角の別字に置き換える。見た目は変わるが、リンクは壊れない。
MD_BRACKETS = str.maketrans({"[": "［", "]": "］"})


def md_safe(s: str) -> str:
    """リンクの表示名や地の文に入れる前に、角かっこを全角へ寄せる。

    ⚠️ `]` が1つ入るだけで表示名がそこで終わり、リンクが壊れる。
    ⚠️ `*` `_` `~` は置き換えない＝リンク自体は壊れず、置き換えると名前のほうが読めなくなる。
    """
    return (s or "").translate(MD_BRACKETS)


# ⚠️ 表示名（Markdown リンクの角かっこの中）に絵文字が入ると、Discord はリンクにせず記法のまま
#    文字で出す（`pixiv/SKILL.md`「きまり」参照。出典 discord-api-docs #6116 / #6810）。
#    直し方は「絵文字を表示名の外（リンクの後ろ）へ出す」で、2026-09-02 のうごイラ firehose
#    （2000件超）まではこれを毎回サブエージェントが手で（正規表現を書き直して）やっていた。
#    ここに寄せて、次から書き直さなくていいようにする。
# 対象は Unicode の絵文字ピクトグラフ範囲のみ（`☆` U+2606・`♡` U+2661 のような記号は対象外＝
# pixiv/SKILL.md の判定基準どおり「見た目が絵文字っぽいか」ではなく「Unicode の絵文字か」で判定する）。
#
# ⚠️ U+2600-27BF（Miscellaneous Symbols + Dingbats）はブロックまるごとを絵文字扱いにしない。
#    このブロックには `☆`(U+2606)・`♡`(U+2661) のような Emoji=No の記号が混ざっている
#    （2026-09-03 pixivうごイラfirehose #1742-1841 で `♣`(U+2663) と `♥`(U+2665) の扱いが割れた実例。
#    `data/DREAM_TASKS.md` 参照）。下の `_EMOJI_2600_27BF_RANGES` は、Unicode 公式の
#    emoji-data.txt（Emoji Version 16.0, 2024-05-01 制定。2026-09-04 に
#    https://unicode.org/Public/16.0.0/ucd/emoji/emoji-data.txt を実際に取得して確認）で
#    「; Emoji」プロパティが付いている行を、このブロックの範囲だけ抜き出したもの（コメントは
#    emoji-data.txt 原文の英語名）。`☆`(2606)・`♡`(2661) はこの一覧に無い＝Emoji=No なので、
#    このリストに入れていない（表示名にそのまま残る＝pixiv/SKILL.md の既存記述と一致）。
_EMOJI_2600_27BF_RANGES = (
    (0x2600, 0x2601),  # sun..cloud
    (0x2602, 0x2603),  # umbrella..snowman
    (0x2604, 0x2604),  # comet
    (0x260E, 0x260E),  # telephone
    (0x2611, 0x2611),  # check box with check
    (0x2614, 0x2615),  # umbrella with rain drops..hot beverage（☔=2026-09-03 #1667 で手動移動した実例）
    (0x2618, 0x2618),  # shamrock
    (0x261D, 0x261D),  # index pointing up
    (0x2620, 0x2620),  # skull and crossbones
    (0x2622, 0x2623),  # radioactive..biohazard
    (0x2626, 0x2626),  # orthodox cross
    (0x262A, 0x262A),  # star and crescent
    (0x262E, 0x262E),  # peace symbol
    (0x262F, 0x262F),  # yin yang
    (0x2638, 0x2639),  # wheel of dharma..frowning face
    (0x263A, 0x263A),  # smiling face
    (0x2640, 0x2640),  # female sign
    (0x2642, 0x2642),  # male sign
    (0x2648, 0x2653),  # Aries..Pisces
    (0x265F, 0x265F),  # chess pawn
    (0x2660, 0x2660),  # spade suit
    (0x2663, 0x2663),  # club suit（♣=2026-09-03 #1752 で手動移動した実例）
    (0x2665, 0x2666),  # heart suit..diamond suit（♥=2026-09-03 #1811 は誤って残した実例。Emoji=Yes）
    (0x2668, 0x2668),  # hot springs
    (0x267B, 0x267B),  # recycling symbol
    (0x267E, 0x267E),  # infinity
    (0x267F, 0x267F),  # wheelchair symbol
    (0x2692, 0x2692),  # hammer and pick
    (0x2693, 0x2693),  # anchor
    (0x2694, 0x2694),  # crossed swords
    (0x2695, 0x2695),  # medical symbol
    (0x2696, 0x2697),  # balance scale..alembic
    (0x2699, 0x2699),  # gear
    (0x269B, 0x269C),  # atom symbol..fleur-de-lis
    (0x26A0, 0x26A1),  # warning..high voltage
    (0x26A7, 0x26A7),  # transgender symbol
    (0x26AA, 0x26AB),  # white circle..black circle
    (0x26B0, 0x26B1),  # coffin..funeral urn
    (0x26BD, 0x26BE),  # soccer ball..baseball
    (0x26C4, 0x26C5),  # snowman without snow..sun behind cloud
    (0x26C8, 0x26C8),  # cloud with lightning and rain
    (0x26CE, 0x26CE),  # Ophiuchus
    (0x26CF, 0x26CF),  # pick
    (0x26D1, 0x26D1),  # rescue worker's helmet
    (0x26D3, 0x26D3),  # chains
    (0x26D4, 0x26D4),  # no entry
    (0x26E9, 0x26E9),  # shinto shrine
    (0x26EA, 0x26EA),  # church
    (0x26F0, 0x26F1),  # mountain..umbrella on ground
    (0x26F2, 0x26F3),  # fountain..flag in hole
    (0x26F4, 0x26F4),  # ferry
    (0x26F5, 0x26F5),  # sailboat
    (0x26F7, 0x26F9),  # skier..person bouncing ball
    (0x26FA, 0x26FA),  # tent
    (0x26FD, 0x26FD),  # fuel pump
    (0x2702, 0x2702),  # scissors
    (0x2705, 0x2705),  # check mark button
    (0x2708, 0x270C),  # airplane..victory hand
    (0x270D, 0x270D),  # writing hand
    (0x270F, 0x270F),  # pencil
    (0x2712, 0x2712),  # black nib
    (0x2714, 0x2714),  # check mark
    (0x2716, 0x2716),  # multiply
    (0x271D, 0x271D),  # latin cross
    (0x2721, 0x2721),  # star of David
    (0x2728, 0x2728),  # sparkles（✨=2026-09-03 #1709 で手動移動した実例）
    (0x2733, 0x2734),  # eight-spoked asterisk..eight-pointed star
    (0x2744, 0x2744),  # snowflake
    (0x2747, 0x2747),  # sparkle
    (0x274C, 0x274C),  # cross mark
    (0x274E, 0x274E),  # cross mark button
    (0x2753, 0x2755),  # red question mark..white exclamation mark
    (0x2757, 0x2757),  # red exclamation mark
    (0x2763, 0x2763),  # heart exclamation
    (0x2764, 0x2764),  # red heart（❤️=2026-09-03 #1732 で VS16 だけ剥がれた不完全処理の実例）
    (0x2795, 0x2797),  # plus..divide
    (0x27A1, 0x27A1),  # right arrow
    (0x27B0, 0x27B0),  # curly loop
    (0x27BF, 0x27BF),  # double curly loop
)

# ⚠️ U+1F200-1F2FF（Enclosed Ideographic Supplement）もブロック全体ではない（同じ emoji-data.txt
#    で確認済み＝1F200 自身・1F203-1F219・1F21B-1F22E・1F230-1F231・1F23B-1F24F・1F252-1F2FF は
#    Emoji=No。予約領域や絵文字化されていない文字が混ざっている）。Emoji=Yes と確認できたのは
#    下の5レンジのみ（🈷 U+1F237 は 1F232..1F23A に含まれる。2026-09-02 #744・#811 で踏んだ実例）。
_EMOJI_1F200_1F2FF_RANGES = (
    (0x1F201, 0x1F202),  # Japanese "here" button..Japanese "service charge" button
    (0x1F21A, 0x1F21A),  # Japanese "free of charge" button
    (0x1F22F, 0x1F22F),  # Japanese "reserved" button
    (0x1F232, 0x1F23A),  # Japanese "prohibited" button..Japanese "open for business" button（🈷含む）
    (0x1F250, 0x1F251),  # Japanese "bargain" button..Japanese "acceptable" button
)


def _char_class(*range_groups: tuple[tuple[int, int], ...]) -> str:
    """`(start, end)` のタプル列から、正規表現の文字クラスの中身を組み立てる。"""
    parts = []
    for ranges in range_groups:
        for start, end in ranges:
            parts.append(f"\\U{start:08X}" if start == end else f"\\U{start:08X}-\\U{end:08X}")
    return "".join(parts)


_EMOJI_BASE_CLASS = (
    "\\U0001F1E6-\\U0001F1FF"  # 地域指示記号（国旗は2文字ペアで出る。レンジのまま）
    "\\U0001F300-\\U0001FAFF"  # 絵文字ピクトグラフの主要帯
    + _char_class(_EMOJI_1F200_1F2FF_RANGES, _EMOJI_2600_27BF_RANGES)
)

# ⚠️⚠️ VS16（U+FE0F、異体字セレクタ）は独立した1文字として文字クラスに入れない。
#    以前の実装は `\U0000FE0F` を文字クラスの中に直接含めていたため、直前の基底文字が
#    このクラスに入っていない場合（未対応レンジの絵文字＋VS16）に**VS16だけが剥がされ、
#    裸の基底文字が表示名に残る**という不完全な結果になっていた
#    （2026-09-03 pixivうごイラfirehose #1732、❤️=U+2764+VS16 の実例。U+2764 を
#    `_EMOJI_2600_27BF_RANGES` に足した今回の変更でこの実例自体は起きなくなるが、
#    構造自体を直しておかないと未対応の別の絵文字+VS16 で同じ壊れ方が再発する）。
#    ここでは「判定レンジに入っている基底文字の直後にある場合だけ、VS16 を基底文字と
#    セットで動かす」という構造にする＝VS16 は各絵文字の直後にオプショナルな接尾辞として
#    付け、VS16 単体では絶対にマッチしない。
_EMOJI_RE = re.compile(f"(?:[{_EMOJI_BASE_CLASS}]\\U0000FE0F?)+")


def relocate_emoji(text: str) -> str:
    """1行目の `[表示名](<URL>)` の中の絵文字だけを、リンクの外（行末）へ動かす。

    ⚠️⚠️ 1行目しか見ない＝2行目以降（概要・キャプション）には触らない。
    2026-09-02 のうごイラ firehose #60 で、概要の中の絵文字まで動かしてしまい、送信直後に
    edit_message で元に戻した実例がある。1行目限定にすることで、同じ間違いが構造的に
    起きないようにしてある（概要の絵文字は動かす対象ではない＝表示名だけの不具合なので）。
    """
    lines = text.split("\n", 1)
    first = lines[0]
    m = re.match(r"^(\[)(.*?)(\]\(<[^>]+>\))(.*)$", first)
    if not m:
        return text
    pre, name, post, rest = m.groups()
    found = _EMOJI_RE.findall(name)
    if not found:
        return text
    cleaned = _EMOJI_RE.sub("", name)
    cleaned = re.sub(r"\s{2,}", " ", cleaned).strip()
    lines[0] = f"{pre}{cleaned}{post}{rest} {''.join(found)}"
    return "\n".join(lines)


# ⚠️ **枚数はリンクの外・後ろに置く**（2026-09-01 takano32 判断＝「1. リンクの後ろにしよう」）。
# それまでは表示名の中（`… ／ 全27枚](<URL>)`）に入れていて、**`pixiv/SKILL.md` の
# 「番号、タイトルのリンク、枚数」（2026-08-24 takano32 指示）と食い違っていた**。
# 実物の並びは `[表示名](<URL>) 全27枚`。**規則の本体はここ1箇所**（3サイトが呼ぶ）。
# ⚠️ **1枚ものは何も足さない**＝空文字を返す。区切りだけが残った `… 全` を作らない。
#
# ⚠️ **音声・動画は本数を併記する**（2026-09-02 JST 02:37＝UTC 2026-09-01 17:37 に takano32 が
#    選択肢 A を選んだ。積んであったのは `REVIEW_TASKS.md`）。
#    **きっかけ**＝dlsite の `page_count` は**画像とサンプルの合計**なのに、ここへ渡るのは
#    **画像の数だけ**だったので、`RJ01644208` は本文が「全5枚」なのに**添付が16ファイル**届いた
#    （2026-09-01 の dlsite 50件配信で実測）。**壊れ方が静か**＝エラーは出ず、数だけ合わない。
#    **この数字は「あと何通続くか」を読む側が測る手がかり**なので、実際に届く数と合っていないと
#    **続きの通を欠けと読み違える。**
# ⚠️ **語は「音声◯本」「動画◯本」**＝**本文の次の行に出る `サンプル音声を添付` /
#    `サンプル動画を添付` と同じ語**にそろえた（**同じものに2つの名前を作らない**）。
#    **数え方は「chobit の1件＝1本」**＝動画は画質違い3本を1件にまとめてあるので 1本と数える
#    （届く添付の数と一致する。**一致しないなら併記する意味が無い**）。
# ⚠️ **区切りは全角の `＋` 1種類**＝`／` は表示名の中の「タイトル ／ 作者 ／ 値段」で使っているので、
#    そこと混ざらないほうを選ぶ。**並びは 枚 → 音声 → 動画 で固定**（送る順と同じ）。
# ⚠️ **画像が1枚以下でも、音声や動画があれば本数だけ出す**（`… 音声11本`）。
#    1枚ものに `全1枚` を足さない規則はそのまま＝**足さないのは「枚」の項だけ**で、
#    項が1つも無いときだけ空文字に戻る。
# ⚠️⚠️ **音声も動画も無いときは、以前と1文字も変わらない**（pixiv と fanza は既定の 0 のまま呼ぶ）。
#    ここが変わったら退行。`--self-test` に陰性対照として留めてある。
def pages_suffix(total: int | None, audio: int = 0, video: int = 0) -> str:
    """リンクの後ろに足す枚数と本数（先頭の半角空白ごと返す。出すものが無ければ空）。"""
    terms = []
    if (total or 0) > 1:
        terms.append(f"全{total}枚")
    if (audio or 0) > 0:
        terms.append(f"音声{audio}本")
    if (video or 0) > 0:
        terms.append(f"動画{video}本")
    return (" " + " ＋ ".join(terms)) if terms else ""


def summary(illust: dict, limit: int = 200) -> str:
    """作品のキャプションを1行の地の文に均す（HTML タグと実体参照を落とし、長ければ切る）。

    埋め込みを消すと、そこに出ていた説明文も一緒に消える。その穴を埋めるための行。
    切り方と URL の包み方（切ってから包む）は clip_and_wrap。

    ⚠️ 2026-09-01 に pages.py からここへ移した＝**ugoira.py が同じ行を出していなかった**ため
    （`pages.py` 側だけが持っていて、うごイラの通は概要が消えていた）。
    **同じ処理を2箇所に持たない**（`coding-conventions.md` §6.8）。
    """
    raw = illust.get("caption") or ""
    text = re.sub(r"<br\s*/?>|</p>", " ", raw, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    text = _html.unescape(text)
    return clip_and_wrap(text, limit)


# 地の文に埋まった URL を切り出す。**日本語の文字で止める**（2026-09-01）＝
# `\S+` だと空白まで貪るので、`（url）を見て。` のような書き方で
# 「）を見て」まで URL に入ってしまい、飛べないリンクになる。
# **URL の中に仮名・漢字・全角記号が入ることは実質ない**ので、そこで切ってよい。
# 交換条件＝生の日本語を含む URL（IDN の非 ASCII パス等）は途中で切れる。
# そちらは実物を見たことが無く、こちらは実測で出た（pixiv 駆逐艦 894・930番）。
URL_RE = re.compile(r"(https?://[^\s\u3000-\u303F\uFF00-\uFFEF\u4E00-\u9FFF\u3040-\u30FF]+)")


# 送信前フック（`scripts/discord-markdown-hook.py`）が止める形。同じ綴りで持つ。
_QUAD_STAR = re.compile(r"\*{4,}")
_QUAD_UNDER = re.compile(r"_{4,}")


def clip_and_wrap(text: str, limit: int = 200) -> str:
    """地の文を limit 字で切り、角かっこを寄せ、裸 URL をアンカーに包む。

    ⚠️ **切ってから包む。**順序が逆だと、切り口がリンクの途中に落ちて
       `[host](<https://…` の壊れた形が残り、裸 URL として送信フックに弾かれる（2026-08-18 実測）。
    ⚠️ URL の中の `_` を打ち消すと URL が壊れるので、URL 以外の部分だけ包む。
    ⚠️ **強調記号が壊れている本文は、送信前フックに止められる**（2026-09-01 実測）。
       止められると送る側が手で削ることになり、「生成した本文をそのまま渡す」が崩れるので、
       **アスタリスク4連・アンダースコア4連・`**` や `__` の個数が奇数のときだけ**全角へ寄せる。
       **釣り合っている `**強調**` はそのまま**＝読みやすさを落とさない。
    """
    text = re.sub(r"\s+", " ", text or "").strip()
    if len(text) > limit:
        text = text[: limit - 1].rstrip()
        text = re.sub(r"\s*https?://\S*$", "", text)  # 途中で切れた URL は丸ごと落とす
        text = text.rstrip() + "…"
    parts = re.split(URL_RE, text)
    # ⚠️ 強調記号の後始末は、URL を外してから全体で見る（2026-09-01）。
    # `scripts/discord-markdown-hook.py` が**送信前に止める**形が3つあり、
    # キャプションはそのどれも作りうる（実測＝アスタリスク4連で送信が拒否された。
    # pixiv ごちうさ 82番）。**止められると、送る側が本文を手で削ることになる**＝
    # 「生成した本文をそのまま渡す」が崩れるので、**生成の側で作らせない。**
    # ⚠️ URL の中の記号は記法として読まれないので、数え上げからも置換からも外す
    # （フック側も同じ理由で URL を外している）。
    body = "".join(parts[0::2])
    star_bad = _QUAD_STAR.search(body) or body.count("**") % 2
    under_bad = _QUAD_UNDER.search(body) or body.count("__") % 2

    out = []
    for k, part in enumerate(parts):
        if k % 2 == 0:
            part = md_safe(part)
            if star_bad:
                part = part.replace("*", "＊")
            if under_bad:
                part = part.replace("_", "＿")
            out.append(part)
            continue
        # ⚠️ 閉じ括弧は取りこぼすと URL に入る（2026-09-01 実測）＝
        # `【…url】` の形のキャプションで `】` が URL の末尾に残り、
        # `[fantia.jp](<https://fantia.jp/posts/1089304】>)` という飛べないリンクになった
        # （pixiv 駆逐艦 894・930番。全角の閉じ括弧が1つも入っていなかった）。
        # 全角の閉じ括弧が URL の最後の文字になることは実質ないので、まとめて落としてよい。
        url = part.rstrip("。、）)]」』】》〉〕｝］＞…")
        host = re.sub(r"^www\.", "", (re.match(r"https?://([^/]+)", url) or [None, url]).group(1))
        out.append(f"[{md_safe(host)}](<{url}>)" + md_safe(part[len(url):]))
    return "".join(out)


# --- 取得 -------------------------------------------------------------------
# オープンプロキシの一覧と設定の置き場（調査の道具は skills/proxy/survey.py）。
# ⚠️ configs/ は gitignore なので、この箱に無いこともある。無ければ黙って直行に落ちる。
PROXY_CONFIG = os.path.normpath(
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "configs", "proxy.json"))


def _proxies_from_config(path: str = PROXY_CONFIG) -> list[str]:
    """`proxy.json` から一覧を読む。**`use_by_default` が true のときだけ**返す。

    無い・壊れている・空・`use_by_default` が false のいずれでも空を返す
    ＝**既定の挙動（直行）を壊さない**。
    """
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        return []
    if not cfg.get("use_by_default"):
        return []
    return [p["url"] for p in (cfg.get("proxies") or []) if p.get("url")]


def load_proxies(path: str | None, env_name: str) -> list[str]:
    """取得に使うプロキシの一覧（無ければ空＝直行のまま）。

    **優先順位**（上が強い。上で1つでも見つかったら下は見ない）:

      1. `--proxies FILE`  呼ぶ側が名指しした一覧。その場の指定がいちばん強い
      2. 環境変数 `env_name`（カンマ区切り）  この箱に固定で置いた指定
      3. `configs/proxy.json` の `proxies[]`  **`use_by_default` が true のときだけ**
      4. どれも無ければ空＝**直行**（`proxy.json` が無い／空／false なら今までどおり）

    1 と 2 を 3 より上に置いたのは、**一覧を自動更新する仕掛け（survey.py）が、
    人が名指しした指定を上書きしてはいけない**から。
    """
    if path:
        with open(path, encoding="utf-8") as f:
            raw = f.read()
    else:
        raw = os.environ.get(env_name, "")
    out = []
    for tok in re.split(r"[\s,]+", raw):
        tok = tok.strip()
        if tok and not tok.startswith("#"):
            out.append(tok if "://" in tok else f"http://{tok}")
    return out or _proxies_from_config()


class TruncatedResponse(OSError):
    """`Content-Length` の宣言より短いところで応答が切れた（2026-09-04 の夢想で足した）。

    ⚠️ `http.client` は **`read(amt)` で読むかぎり、途中で切れても例外を出さない**
       （CPython 3.14.4 の `HTTPResponse.read` 原文＝「Ideally, we would raise IncompleteRead if the
       content-length wasn't satisfied, but it might break compatibility.」）。`fetch_url` は 64KiB ずつ
       `read(amt)` で読むので、**切れた JPEG が「成功」で `files` に入っていた**。
       `read()`（引数なし）なら `IncompleteRead` が出るが、10MiB 級を丸ごと RAM に載せることになるので
       採らない＝自分で数えて宣言と突き合わせる。
    """


# 既知のプレースホルダ＝**「取れた」のに中身が絵ではないもの**（2026-09-04 の夢想で足した）。
# 形は md5 → (バイト数, notes に出す説明)。**まず大きさで絞り、一致したときだけ md5 を取る**
# （1枚 1MB 級を毎回ハッシュしない。`placeholder_of`）。
# ⚠️ 1件目は FANZA の画像 CDN（`doujin-assets.dmm.co.jp`）。存在しないパスは 404 でなく
#    **302 で `/doujin/now_printing/now_printing.jpg` へ飛ぶ**（2026-09-04 に本流が4パスで実測。
#    この実装のときに `d_738994jp-099.jpg` で再確認＝302 → 200・2,732B・md5 一致）。
#    urllib は 302 を追って 200 を受けるので、**成功扱いで `files` に入っていた**。
# ⚠️ dlsite の `img.dlsite.jp` は同じ日に確かめて **404**（`RJ01392979_img_smp99.jpg`・353B）＝
#    こちらは urllib が HTTPError を投げるので、以前から「取得できず」に落ちる。
#    ⚠️ 帰属は FANZA であって dlsite ではない（`fanza/SKILL.md`「存在しないパスは 404 を返さない」と一致。
#       夢想の本文は CDN 名を挙げていない＝2026-09-04 の検証で確認）。
PLACEHOLDERS: dict[str, tuple[int, str]] = {
    "f591f3826a1085af5cdeeca250b2c97a": (2732, "存在しないパス（now_printing.jpg に飛ばされた）"),
}


def placeholder_of(path: str, size: int,
                   table: dict[str, tuple[int, str]] | None = None) -> str | None:
    """`path` が既知のプレースホルダなら説明を返す（違えば None）。**大きさが表に無ければ md5 は取らない。**"""
    table = PLACEHOLDERS if table is None else table
    if size not in {n for n, _ in table.values()}:
        return None
    with open(path, "rb") as f:
        hit = table.get(hashlib.md5(f.read()).hexdigest())
    return hit[1] if hit and hit[0] == size else None


def _declared_length(headers) -> int | None:
    """応答が宣言した本体のバイト数（無ければ None＝突き合わせない）。

    ⚠️ `Transfer-Encoding` が付いていれば `Content-Length` は見ない（RFC 9112 §6.3＝両方あるときは
       Transfer-Encoding が勝つ。`http.client` も同じ扱いで `length=None` にする）。
    ⚠️ `Content-Encoding`（gzip 等）が付いていても比べてよい＝urllib は `Accept-Encoding` を送らず、
       受けた本体を**展開もしない**ので、dest に書くのは線を流れた素のバイトそのもの。`Content-Length` も
       線を流れるバイト数（RFC 9110 §8.6）なので、圧縮の前後で食い違うことはない。
    """
    if headers.get("Transfer-Encoding"):
        return None
    v = (headers.get("Content-Length") or "").strip()
    return int(v) if v.isdigit() else None


def _remove_quietly(path: str) -> None:
    try:
        os.remove(path)
    except OSError:
        pass


def fetch_url(url: str, dest: str, headers: dict | None = None,
              proxy: str | None = None, timeout: float = 30,
              info: dict | None = None) -> int:
    """URL を dest へ落として、書いたバイト数を返す。

    `info` に dict を渡すと、**飛ばされた先の URL**（`url`）・HTTP ステータス（`status`）・
    宣言された `Content-Length`（`content_length`。無ければ None）を詰めて返す
    （2026-09-04 の夢想で足した。戻り値は `int` のまま＝既存の呼び出し元を壊さない）。

    ⚠️ `Content-Length` が宣言されていて実バイト数と食い違えば、**書きかけを消してから** TruncatedResponse。
       宣言が無い（chunked 等）ときは何もしない（`_declared_length`）。
    ⚠️ 途中で例外が出たときも書きかけは消す＝0 バイトや半端なファイルは、次に見た者に
       「途中まで落ちている」と誤読させる（`coding-conventions.md` §6.13 ②）。
    """
    req = urllib.request.Request(url, headers=headers or {})
    if proxy:
        # ⚠️ https は CONNECT トンネルになる。証明書の検証は既定のまま（切らない）。
        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({"https": proxy, "http": proxy}))
        ctx = opener.open(req, timeout=timeout)
    else:
        ctx = urllib.request.urlopen(req, timeout=timeout)
    n = 0
    declared = None
    try:
        with ctx as res:
            declared = _declared_length(res.headers)
            if info is not None:
                info.update(url=getattr(res, "url", None), status=getattr(res, "status", None),
                            content_length=declared)
            with open(dest, "wb") as f:
                while chunk := res.read(65536):
                    f.write(chunk)
                    n += len(chunk)
    except BaseException:
        _remove_quietly(dest)
        raise
    if declared is not None and n != declared:
        _remove_quietly(dest)
        raise TruncatedResponse(f"応答が途中で切れた（宣言 {declared} バイト、実 {n} バイト）")
    return n


def count_arg(text: str) -> int:
    """`--count` の `type=`。0 と負値を**ネットワークに触る前に**弾く（2026-09-04 の夢想で足した）。

    ⚠️ `--count 0` は窓が空で `next_offset` が `offset` のまま＝呼ぶ側が `next_offset` に従うと
       **同じ位置を撃ち続ける**。負値はスライスが後ろから数えて、意図しない窓になる。
       argparse の `type=` で弾くと、ID の検査や API より前に exit code 2 で止まる。
       dlsite / fanza / pixiv / danbooru の4つの CLI が同じ関数を import する（同じ検査を4箇所に書かない＝§6.8）。
    """
    try:
        n = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"--count は整数で（受け取った値: {text!r}）")
    if n < 1:
        raise argparse.ArgumentTypeError(f"--count は 1 以上（受け取った値: {n}）")
    return n


def fetch_all(items: list[dict], out: str, *, jobs: int = 6, headers: dict | None = None,
              proxies: list[str] | None = None, max_bytes: int = MAX_BYTES,
              big_label: str = "原寸", alt_label: str = "表示用",
              timeout: float = 30,
              placeholders: dict[str, tuple[int, str]] | None = None) -> tuple[list[str], list[str], int]:
    """items を並列に落として `(files, notes, total_bytes)` を返す。

    items の1件は `{"name": <拡張子なしのファイル名>, "label": <人が読む名>, "urls": [第1候補, 代替…]}`。
    **並べ替えない**＝並び順は見る順番そのもの。並列に取っても、返すのは元の順。
    1件が上限を超えたら**その1件だけ**代替 URL へ落とす（全件を落とさない）。
    `placeholders` は既知のプレースホルダの表（既定 PLACEHOLDERS。自己テストが差し替えるためにある）。
    """
    proxies = proxies or []

    def take_one(j: int, item: dict) -> tuple[int, str | None, int, list[str]]:
        label = item.get("label") or item.get("name") or str(j + 1)
        raw = list(item.get("urls") or [])
        urls = [u for u in raw if u]
        local: list[str] = []
        # ① URL が falsy（None・空文字）＝以前はここの内包表記で黙って消え、for が回らず GET も notes も
        #    無かった（2026-09-04 の夢想で足した。実データ 3,828 件では 0 件だが、経路は実在する）。
        #    **候補が全部空なら1行残して終わる。先頭が空で後ろに候補があるときも1行残す。**
        #    ⚠️ 後ろのほうの空は黙って飛ばす＝そこまで落ちたときにしか関係しないうえ、pixiv は
        #       `[original, large]` で large が None のことがあり、成功した束に雑音を足さないため。
        #    取る順番と、下の「上限超え」「取得できず」の文言は変えていない。
        if not urls:
            local.append(f"{label} 取得できず: URL が無い"
                         + (f"（候補{len(raw)}件すべて空）" if raw else "（候補が1件も無い）"))
            return (j, None, 0, local)
        for k, u in enumerate(raw):
            if u:
                break
            local.append(f"{label} 第{k + 1}候補の URL が空。次の候補へ")
        for k, url in enumerate(urls):
            ext = os.path.splitext(url.split("?")[0])[1] or ".jpg"
            dest = os.path.join(out, f"{item['name']}{ext}")
            proxy = proxies[j % len(proxies)] if proxies else None
            # ⚠️ 取得に失敗しても**次の候補へ進む**（2026-09-08 JST takano32 判断＝か）。
            #    以前はここだけ `break` していた＝「大きすぎた」「絵じゃない」の2つは進むのに、
            #    **取得そのものがこけたときだけ止まる**という揃っていない形だった。
            #    第1候補が一瞬こけただけで1件が丸ごと欠け、代替（同じ絵の小さい版）は叩かれなかった。
            #    **規則は「候補が尽きるまで進む」の一本。**
            #    ⚠️ 引き換え＝相手が黙り込むと1件あたりの待ちが候補の数だけ伸びる
            #    （`timeout` は候補ごとに掛かる。404 の往復は 0.53 秒なので、応答がある限りは安い）。
            #    ⚠️ 書きかけは `fetch_url` が消してから投げるので、次の候補に残骸は残らない。
            try:
                n = fetch_url(url, dest, headers, proxy, timeout)
            except Exception as e:
                if proxy:  # プロキシがこけたら直行で取り直す（仕掛けが取れない理由にならないように）
                    local.append(f"{label} プロキシ経由に失敗（直行で取り直した）: {e}")
                    try:
                        n = fetch_url(url, dest, headers, None, timeout)
                    except Exception as e2:
                        local.append(f"{label} 取得できず: {e2}"
                                     + ("。次の候補へ" if k + 1 < len(urls) else ""))
                        continue
                else:  # 1件こけても残りは取る（何がこけたかは最後に並べる）
                    local.append(f"{label} 取得できず: {e}"
                                 + ("。次の候補へ" if k + 1 < len(urls) else ""))
                    continue
            # ② 既知のプレースホルダ（PLACEHOLDERS）＝「取れた」のに絵ではない。消して次の候補へ
            #    （上限超えと同じ `continue` の作法。どれも取れなければ files に入らない）。
            why = placeholder_of(dest, n, placeholders)
            if why:
                os.remove(dest)
                local.append(f"{label} 取得できず: {why}" + ("。次の候補へ" if k + 1 < len(urls) else ""))
                continue
            if n > max_bytes:
                os.remove(dest)
                local.append(f"{label} {big_label}が {n/1048576:.1f}MB で上限超え"
                             + (f"。{alt_label}に落とした" if k == 0 and len(urls) > 1 else "。外した"))
                continue
            if k > 0 and local:  # 直前の note が「落とした」なら、落ちた先の大きさも同じ行に足す
                local[-1] += f"（{n/1048576:.1f}MB）"
            return (j, dest, n, local)
        return (j, None, 0, local)

    if jobs > 1 and len(items) > 1:
        with futures.ThreadPoolExecutor(max_workers=jobs) as pool:
            results = list(pool.map(lambda t: take_one(*t), list(enumerate(items))))
    else:
        results = [take_one(j, item) for j, item in enumerate(items)]

    files, notes, total = [], [], 0
    for j, dest, n, local in sorted(results, key=lambda r: r[0]):
        notes.extend(local)
        if dest:
            files.append(dest)
            total += n
    return files, notes, total


# --- 動画・音声を上限に収める ------------------------------------------------
# ⚠️ **バイト数で切ってはいけない**（2026-08-18 takano32 指示）。
#    MP4 は索引（moov atom）を末尾に置く作りが多く、頭から N バイトだけ取ると索引ごと落ちて
#    **再生できないファイル**になる。**動画として切り直す**＝`ffmpeg -t <秒> -c copy` で
#    先頭 N 秒を切り出し、`-movflags +faststart` で索引を先頭へ置き直す。
#    `-c copy` なので再エンコードしない（速い・画質を落とさない）。
# ⚠️ ここだけ外部コマンド（`ffmpeg` / `ffprobe`）に依存する。無ければ TrimUnavailable。
TRIM_TARGET = int(9.0 * 1024 * 1024)  # 狙う大きさ。10MiB ちょうどだと端で外れるので安全側に
TRIM_TRIES = 5


class TrimUnavailable(RuntimeError):
    """ffmpeg / ffprobe が無い、または切り出しに失敗した。"""


def probe_media(path: str) -> tuple[float, int]:
    """`(尺の秒数, バイト数)`。ffprobe が無ければ TrimUnavailable。"""
    import subprocess
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration,size",
                            "-of", "json", path], capture_output=True, text=True, timeout=60)
    except FileNotFoundError:
        raise TrimUnavailable("ffprobe が見つかりません")
    if r.returncode != 0:
        raise TrimUnavailable(f"ffprobe が失敗しました: {r.stderr.strip()[:200]}")
    fmt = (json.loads(r.stdout or "{}").get("format") or {})
    try:
        return float(fmt["duration"]), int(fmt["size"])
    except (KeyError, TypeError, ValueError):
        raise TrimUnavailable("ffprobe が尺を返しませんでした")


def trim_to_fit(src: str, dest: str, max_bytes: int = MAX_BYTES,
                target: int = TRIM_TARGET) -> float:
    """`src` の**先頭だけ**を切り出して `dest` に置き、切った秒数を返す。

    ⚠️ **1回で決め打たない**＝ビットレートは一定ではないので、
       「全体の平均から出した秒数」で切ると頭が濃いぶん超えることがある
       （実測＝598秒 63.2MB を平均から 89.2秒で切ったら 12.69MiB になった）。
       **切ったあと実際に測り、超えていたら比率で縮めて取り直す**（実測では2回目で 8.93MiB）。
    """
    import subprocess
    dur, size = probe_media(src)
    if size <= max_bytes:
        return dur  # 切る必要がない
    sec = dur * target / size
    for _ in range(TRIM_TRIES):
        sec = round(min(sec, dur), 1)
        if sec <= 0:
            raise TrimUnavailable("切り出せる長さになりませんでした")
        try:
            r = subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error",
                                "-i", src, "-t", str(sec), "-c", "copy",
                                "-movflags", "+faststart", dest],
                               capture_output=True, text=True, timeout=300)
        except FileNotFoundError:
            raise TrimUnavailable("ffmpeg が見つかりません")
        if r.returncode != 0:
            raise TrimUnavailable(f"ffmpeg が失敗しました: {r.stderr.strip()[:200]}")
        n = os.path.getsize(dest)
        if n <= max_bytes:
            return sec
        sec = sec * target / n
    raise TrimUnavailable(f"{TRIM_TRIES}回切っても上限に収まりませんでした")


def write_manifest(out: str, payload: dict) -> None:
    """出来上がりの合図＝最後に manifest を置く。

    先に書いて途中でこけると、半端な束を送ってしまう。**置き換えは不可分**にする。
    別のエージェントが先に取りに行く形（先読み）では、これが在ることだけを見て「揃った」と判断する。
    """
    tmp = os.path.join(out, ".manifest.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp, os.path.join(out, "manifest.json"))


# --- 自己テスト -------------------------------------------------------------
# `python3 site-python/_media_fetch.py --self-test` で回す。
# ⚠️ ここに並ぶのは**実物で出た形**と、その周りで壊しやすい形。
# 2026-09-01 に URL の切り出しを直したとき、直した先が別の形を壊していないかを
# 確かめる場所が無かったので置いた（直す前は `（url）を見て。` も壊れていた）。
CLIP_CASES = [
    ("全角括弧で囲む（実測・pixiv 駆逐艦 894/930番）",
     "Fantia→【https://fantia.jp/posts/1089304】",
     "Fantia→【[fantia.jp](<https://fantia.jp/posts/1089304>)】"),
    ("全角丸括弧のあとに地の文が続く",
     "案内（https://example.com/a）を見て。",
     "案内（[example.com](<https://example.com/a>)）を見て。"),
    ("URL のあとに直に日本語",
     "https://example.com/cを見る",
     "[example.com](<https://example.com/c>)を見る"),
    ("ふつうの URL（`_` を打ち消さない）",
     "ふつう https://example.com/x_y?a=1 のまま",
     "ふつう [example.com](<https://example.com/x_y?a=1>) のまま"),
    ("半角括弧は中身だけ包む",
     "see (https://example.com/b) ok",
     "see ([example.com](<https://example.com/b>)) ok"),
    ("クエリ付き（www. は表示からだけ落とす。リンク先は保つ）",
     "https://www.melonbooks.co.jp/detail/detail.php?product_id=323510 です",
     "[melonbooks.co.jp](<https://www.melonbooks.co.jp/detail/detail.php?product_id=323510>) です"),
    ("角かっこは全角へ寄せる（`]` 1つでリンクが終わるため）",
     "[お知らせ] 更新しました",
     "［お知らせ］ 更新しました"),
    # 以下は送信前フック（scripts/discord-markdown-hook.py）が止める形。
    # 生成の側で作らせないための札（2026-09-01・実測＝pixiv ごちうさ 82番で送信が拒否された）。
    ("アスタリスク4連は全角へ（実測・送信が拒否された形）",
     "差分32枚 ****注意**** よろしく",
     "差分32枚 ＊＊＊＊注意＊＊＊＊ よろしく"),
    ("釣り合った強調はそのまま（読みやすさを落とさない）",
     "釣り合った **強調** はそのまま",
     "釣り合った **強調** はそのまま"),
    ("閉じていない強調は全角へ（残り全部が太字になる）",
     "閉じていない **強調 が1つ",
     "閉じていない ＊＊強調 が1つ"),
    ("アンダースコア4連も同じ（`__` は下線の開始）",
     "下線 ____ の4連",
     "下線 ＿＿＿＿ の4連"),
    ("⚠️ URL の中の `_` は触らない（数え上げからも外す）",
     "URL に _ が入る https://example.com/a_b_c は壊さない",
     "URL に _ が入る [example.com](<https://example.com/a_b_c>) は壊さない"),
]


def _self_test_fetch() -> int:
    """取得の3つの検出（①URL が空 ②プレースホルダ ③Content-Length の食い違い）の陽性と陰性対照。

    file:// では 302 も Content-Length の食い違いも作れないので、標準ライブラリの `http.server` を
    スレッドで立てる（ポートは 0 で空きを取る）。置き場は tempfile に作って最後に消す（2026-09-04 の夢想で足した）。
    """
    import http.server
    import tempfile
    import threading

    OK_BODY = bytes(range(256)) * 800                       # 204,800B（notes には「0.2MB」と出る）
    FAKE_PLACEHOLDER = bytes(range(256)) * 10 + b"x" * 172  # 2,732B＝実物と同じ大きさで、md5 は別
    fake_md5 = hashlib.md5(FAKE_PLACEHOLDER).hexdigest()
    table = {fake_md5: (len(FAKE_PLACEHOLDER), "存在しないパス（now_printing.jpg に飛ばされた）")}

    class Handler(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *args) -> None:  # 自己テストの出力にアクセスログを混ぜない
            pass

        def _send(self, code: int, body: bytes) -> None:
            self.send_response(code)
            self.send_header("Content-Type", "image/jpeg")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            if self.path == "/ok.jpg":
                self._send(200, OK_BODY)
            elif self.path == "/cut.jpg":  # ③ 宣言 10,000B・実体 3,000B で閉じる（途中で切れた応答）
                self.send_response(200)
                self.send_header("Content-Type", "image/jpeg")
                self.send_header("Content-Length", "10000")
                self.end_headers()
                self.wfile.write(b"J" * 3000)
                self.close_connection = True
            elif self.path == "/chunked.jpg":  # 宣言なし（chunked）＝突き合わせない陰性対照
                self.send_response(200)
                self.send_header("Content-Type", "image/jpeg")
                self.send_header("Transfer-Encoding", "chunked")
                self.end_headers()
                for piece in (OK_BODY[:1000], OK_BODY[1000:]):
                    self.wfile.write(f"{len(piece):x}\r\n".encode() + piece + b"\r\n")
                self.wfile.write(b"0\r\n\r\n")
            elif self.path == "/missing.jpg":  # ② 存在しないパス＝302 でプレースホルダへ（FANZA の形）
                self.send_response(302)
                self.send_header("Location", "/now_printing.jpg")
                self.send_header("Content-Length", "0")
                self.end_headers()
            elif self.path == "/now_printing.jpg":
                self._send(200, FAKE_PLACEHOLDER)
            else:
                self.send_error(404)

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    base = f"http://127.0.0.1:{srv.server_address[1]}"
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    # ⚠️ urllib は環境変数のプロキシに乗る。127.0.0.1 は素通しにする
    #    （この箱の no_proxy には入っているが、別の箱でも同じとは限らない）。
    os.environ["no_proxy"] = ",".join(filter(None, [os.environ.get("no_proxy"), "127.0.0.1"]))
    tmp = tempfile.mkdtemp(prefix="media_fetch-selftest-",
                           dir=DISK_DIR if os.path.isdir(DISK_DIR) else None)
    ng = 0

    def check(why: str, ok: bool, detail: str = "") -> None:
        nonlocal ng
        ng += 0 if ok else 1
        print(f"{'OK ' if ok else 'NG '}{why}")
        if not ok and detail:
            print(f"    {detail}")

    try:
        # (why, urls, placeholders, 期待する files のファイル名, 期待する notes)
        cases = [
            ("取得：正常応答は notes が空で files に入る（陰性対照）",
             [f"{base}/ok.jpg"], None, ["a.jpg"], []),
            ("取得③：宣言なし（chunked）は突き合わせない（陰性対照）",
             [f"{base}/chunked.jpg"], None, ["a.jpg"], []),
            ("取得③：Content-Length より短く切れた応答は取得できずに落ち、書きかけを残さない",
             [f"{base}/cut.jpg"], None, [],
             ["1枚目 取得できず: 応答が途中で切れた（宣言 10000 バイト、実 3000 バイト）"]),
            ("取得②：302 でプレースホルダへ飛ばされたら消して取得できず（次の候補なし）",
             [f"{base}/missing.jpg"], table, [],
             ["1枚目 取得できず: 存在しないパス（now_printing.jpg に飛ばされた）"]),
            ("取得②：プレースホルダのあと次の候補があれば試す（上限超えと同じ作法）",
             [f"{base}/missing.jpg", f"{base}/ok.jpg"], table, ["a.jpg"],
             ["1枚目 取得できず: 存在しないパス（now_printing.jpg に飛ばされた）。次の候補へ（0.2MB）"]),
            ("取得②：大きさが同じでも md5 が表に無ければ弾かない（陰性対照＝大きさだけで決めない）",
             [f"{base}/missing.jpg"], PLACEHOLDERS, ["a.jpg"], []),
            ("取得①：候補が全部空なら1行残す",
             [None, ""], None, [], ["1枚目 取得できず: URL が無い（候補2件すべて空）"]),
            ("取得①：第1候補だけ空なら1行残して次の候補へ",
             [None, f"{base}/ok.jpg"], None, ["a.jpg"], ["1枚目 第1候補の URL が空。次の候補へ"]),
            ("取得①：候補が1件も無い（空リスト）",
             [], None, [], ["1枚目 取得できず: URL が無い（候補が1件も無い）"]),
            ("取得①：後ろの候補が空でも、第1候補が取れれば雑音を足さない（pixiv の large=None の形）",
             [f"{base}/ok.jpg", None], None, ["a.jpg"], []),
            # ⚠️ 2026-09-08 の案 か＝取得そのものの失敗も、次の候補へ進む。
            ("取得：取得に失敗しても次の候補があれば試す（案 か）",
             [f"{base}/nope.jpg", f"{base}/ok.jpg"], None, ["a.jpg"],
             ["1枚目 取得できず: HTTP Error 404: Not Found。次の候補へ（0.2MB）"]),
            ("取得：候補が全部こけたら files は空で、理由が候補の数だけ並ぶ（陰性対照）",
             [f"{base}/nope.jpg", f"{base}/nope2.jpg"], None, [],
             ["1枚目 取得できず: HTTP Error 404: Not Found。次の候補へ",
              "1枚目 取得できず: HTTP Error 404: Not Found"]),
        ]
        for why, urls, tbl, want_files, want_notes in cases:
            out = os.path.join(tmp, "case")
            os.makedirs(out, exist_ok=True)
            files, notes, total = fetch_all([{"name": "a", "label": "1枚目", "urls": urls}],
                                            out, jobs=1, placeholders=tbl)
            got_files = [os.path.basename(p) for p in files]
            leftovers = sorted(os.listdir(out))
            ok = got_files == want_files and notes == want_notes and leftovers == want_files
            if ok and want_files:
                ok = total == os.path.getsize(files[0])
            check(why, ok, f"files={got_files!r} notes={notes!r} 置き場={leftovers!r} total={total}")
            shutil.rmtree(out, ignore_errors=True)

        # 並列の経路（ThreadPoolExecutor）でも同じ＝1件こけても残りは取り、返す順は元の順
        out = os.path.join(tmp, "par")
        os.makedirs(out, exist_ok=True)
        files, notes, total = fetch_all([
            {"name": "a", "label": "1枚目", "urls": [f"{base}/ok.jpg"]},
            {"name": "b", "label": "2枚目", "urls": [f"{base}/cut.jpg"]},
            {"name": "c", "label": "3枚目", "urls": [f"{base}/ok.jpg"]},
        ], out, jobs=3)
        check("取得：並列でも切れた1件だけ落ち、残りは元の順で返る",
              [os.path.basename(p) for p in files] == ["a.jpg", "c.jpg"]
              and notes == ["2枚目 取得できず: 応答が途中で切れた（宣言 10000 バイト、実 3000 バイト）"]
              and sorted(os.listdir(out)) == ["a.jpg", "c.jpg"],
              f"files={files!r} notes={notes!r} 置き場={sorted(os.listdir(out))!r}")
        shutil.rmtree(out, ignore_errors=True)

        # fetch_url 単体＝info に飛ばされた先・ステータス・宣言長が入る／食い違いは専用の例外で書きかけが消える
        info: dict = {}
        n = fetch_url(f"{base}/missing.jpg", os.path.join(tmp, "i.jpg"), info=info)
        want = {"url": f"{base}/now_printing.jpg", "status": 200, "content_length": 2732}
        check("fetch_url：info に飛ばされた先の URL・ステータス・Content-Length が入る（戻り値は int のまま）",
              n == 2732 and info == want, f"n={n} info={info!r}")
        dest = os.path.join(tmp, "t.jpg")
        try:
            fetch_url(f"{base}/cut.jpg", dest)
            got = None
        except TruncatedResponse as e:
            got = str(e)
        check("fetch_url：食い違いは TruncatedResponse（宣言 X バイト、実 Y バイト）で、書きかけは消えている",
              got == "応答が途中で切れた（宣言 10000 バイト、実 3000 バイト）" and not os.path.exists(dest),
              f"{got!r} exists={os.path.exists(dest)}")

        # --count の検査＝0 と負値は「--count は 1 以上」で止まる（argparse が exit 2 にする）
        for text, want in [("1", 1), ("10", 10),
                           ("0", "--count は 1 以上（受け取った値: 0）"),
                           ("-1", "--count は 1 以上（受け取った値: -1）"),
                           ("x", "--count は整数で（受け取った値: 'x'）")]:
            try:
                got = count_arg(text)
            except argparse.ArgumentTypeError as e:
                got = str(e)
            check(f"--count の検査：{text!r} → {want!r}", got == want, f"{got!r}")
    finally:
        srv.shutdown()
        srv.server_close()
        shutil.rmtree(tmp, ignore_errors=True)
    return ng


def _self_test() -> int:
    ng = 0
    for why, src, want in CLIP_CASES:
        got = clip_and_wrap(src)
        ok = got == want
        ng += 0 if ok else 1
        print(f"{'OK ' if ok else 'NG '}{why}")
        if not ok:
            print(f"    入力: {src!r}\n    期待: {want!r}\n    実際: {got!r}")
    # 枚数はリンクの後ろ（2026-09-01 takano32 判断）。**1枚ものに区切りだけが残らないこと**を機械で留める。
    # 本数の併記（2026-09-02 JST takano32 判断＝A）も同じ表で留める。
    # ⚠️ **陰性対照を先頭に置く**＝音声も動画も無い作品（pixiv と fanza の全件）で
    #    **1文字も変わらない**ことが、この変更のいちばん大事な条件。
    for why, args, want in [
        ("枚数：1枚ものは何も足さない（`… 全` の残骸を作らない）", (1, 0, 0), ""),
        ("枚数：数が無い（None）ときも何も足さない", (None, 0, 0), ""),
        ("枚数：0（1枚も取れなかった）ときも何も足さない", (0, 0, 0), ""),
        ("枚数：複数枚はリンクの後ろへ半角空白1つで足す", (27, 0, 0), " 全27枚"),
        ("本数：音声だけ（dlsite RJ01644208＝画像5枚＋サンプル音声11本）", (5, 11, 0), " 全5枚 ＋ 音声11本"),
        ("本数：動画だけ（画質違いは1件にまとめてあるので1本）", (7, 0, 1), " 全7枚 ＋ 動画1本"),
        ("本数：音声も動画もある（並びは 枚 → 音声 → 動画 で固定）", (5, 11, 1),
         " 全5枚 ＋ 音声11本 ＋ 動画1本"),
        ("本数：画像が1枚でも、音声があれば本数だけ出す（`全1枚` は足さない）", (1, 3, 0), " 音声3本"),
        ("本数：画像0枚で動画だけでも出す", (0, 0, 1), " 動画1本"),
    ]:
        got = pages_suffix(*args)
        ok = got == want
        ng += 0 if ok else 1
        print(f"{'OK ' if ok else 'NG '}{why}")
        if not ok:
            print(f"    入力: {args!r}\n    期待: {want!r}\n    実際: {got!r}")
    # ⚠️ 呼び方の退行止め＝pixiv と fanza は**位置引数1つ**で呼ぶ。既定のままで以前と同じ文字列になること。
    for total in (None, 0, 1, 2, 27, 100):
        ok = pages_suffix(total) == pages_suffix(total, 0, 0) == (f" 全{total}枚" if (total or 0) > 1 else "")
        ng += 0 if ok else 1
        print(f"{'OK ' if ok else 'NG '}本数：引数1つの呼び方（pixiv・fanza）は以前と同じ total={total!r}")

    # 絵文字の退避＝1行目の表示名だけを触り、概要（2行目以降）は絶対に触らない
    for why, src, want in [
        ("絵文字なしは何も変えない", "[タイトル ／ 作者](<https://example.com/1>)\n概要です",
         "[タイトル ／ 作者](<https://example.com/1>)\n概要です"),
        ("表示名の絵文字はリンクの後ろへ出す", "[タイトル👑 ／ 作者](<https://example.com/1>)",
         "[タイトル ／ 作者](<https://example.com/1>) 👑"),
        ("枚数などの既存の suffix があれば、絵文字はそのさらに後ろ",
         "[タイトル🐾 ／ 作者](<https://example.com/1>) 全27枚",
         "[タイトル ／ 作者](<https://example.com/1>) 全27枚 🐾"),
        ("記号（☆♡）は絵文字ではないので動かさない", "[☆タイトル♡ ／ 作者](<https://example.com/1>)",
         "[☆タイトル♡ ／ 作者](<https://example.com/1>)"),
        ("概要（2行目）の絵文字は触らない（2026-09-02 #60 の実例の陰性対照）",
         "[タイトル ／ 作者](<https://example.com/1>)\n絵文字入り概要💦です",
         "[タイトル ／ 作者](<https://example.com/1>)\n絵文字入り概要💦です"),
        ("Enclosed Ideographic Supplement（2026-09-02 #744・#811 の実例＝🈷 U+1F237）",
         "[タイトル🈷 ／ 作者](<https://example.com/1>)",
         "[タイトル ／ 作者](<https://example.com/1>) 🈷"),
        ("Misc Symbols + Dingbats（2026-09-03 #1667＝☔ U+2614）",
         "[タイトル☔ ／ 作者](<https://example.com/1>)",
         "[タイトル ／ 作者](<https://example.com/1>) ☔"),
        ("Misc Symbols + Dingbats（2026-09-03 #1709＝✨ U+2728）",
         "[タイトル✨ ／ 作者](<https://example.com/1>)",
         "[タイトル ／ 作者](<https://example.com/1>) ✨"),
        ("Misc Symbols + Dingbats（2026-09-03 #1752＝♣ U+2663、手動移動していたもの）",
         "[タイトル♣ ／ 作者](<https://example.com/1>)",
         "[タイトル ／ 作者](<https://example.com/1>) ♣"),
        ("Misc Symbols + Dingbats（2026-09-03 #1811＝♥ U+2665。以前は☆♡を類推してそのまま残していたが"
         "Emoji=Yesなので今回から動かす対象）",
         "[タイトル♥ ／ 作者](<https://example.com/1>)",
         "[タイトル ／ 作者](<https://example.com/1>) ♥"),
        ("VS16付き（2026-09-03 #1732＝❤️ U+2764+VS16。VS16だけ剥がれて裸のU+2764が残る不具合の実例）",
         "[タイトル❤️ ／ 作者](<https://example.com/1>)",
         "[タイトル ／ 作者](<https://example.com/1>) ❤️"),
        ("VS16の構造テスト：判定レンジ外の基底文字+VS16はVS16単独でも剥がさない（セットのまま残す）",
         "[タイトル鍵️ ／ 作者](<https://example.com/1>)",
         "[タイトル鍵️ ／ 作者](<https://example.com/1>)"),
    ]:
        got = relocate_emoji(src)
        ok = got == want
        ng += 0 if ok else 1
        print(f"{'OK ' if ok else 'NG '}{why}")
        if not ok:
            print(f"    入力: {src!r}\n    期待: {want!r}\n    実際: {got!r}")

    # 長さで切る側＝切ってから包む（切り口がリンクの途中に落ちない）
    long_src = "あ" * 190 + " https://example.com/very/long/path/that/gets/cut"
    got = clip_and_wrap(long_src, limit=200)
    ok = "](" not in got or got.count("<") == got.count(">")
    ng += 0 if ok else 1
    print(f"{'OK ' if ok else 'NG '}長い地の文の末尾で URL が途中で切れても壊れたリンクを残さない")

    # 取得の3つの検出（2026-09-04）。ローカルの http.server を立てるが、全体で 1 秒足らず（実測 0.7 秒）
    ng += _self_test_fetch()
    print(f"\n{'すべて通過' if ng == 0 else f'{ng} 件 失敗'}")
    return 0 if ng == 0 else 1


if __name__ == "__main__":
    import sys as _sys
    if "--self-test" in _sys.argv:
        raise SystemExit(_self_test())
    print(__doc__ or "media_fetch: ライブラリです（--self-test で自己テスト）")
