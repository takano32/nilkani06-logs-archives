#!/usr/bin/env python3
"""herdr（端末の器）まわりの部品。名指しと注入先の選び方、そして入力欄への注入。

  名指しと選び方 … herdr_bin / herdr_session / herdr_pane / inject_backend_for
                   （targets の dream・blocked・trend-digest が共通で使う。旧版は3つの対象がそれぞれ同じ決め方を
                   書いていたので、順序を1か所で決めるためにここへまとめた）
  注入 ………………… inject()。herdr のペインで走る claude の入力欄へ本文を置いて送信する、herdr 側の唯一の実装。
                   2026-11-21 に skills/ops/herdr/herdr-inject.sh（bash 156 行）から移した
                   （takano32 承認・管理チャンネル「やってください」）。手で撃つときは:

      python3 site-python/_herdr.py inject <session> <pane> <本文>      （リポジトリ直下で）

注入の理由（なぜ前景を見るか・なぜ dirty を自分で消すか・なぜ working にも撃たないか）は
skills/ops/herdr/SKILL.md「注入」の節に置く。ここには手順だけを書き、理由は写さない。
依存は標準ライブラリだけ。外部コマンドは herdr と ss と、入力欄を読む pane-box.py（python3）だけを呼ぶ
（旧版が使っていた jq、awk、sed、cut、timeout、ps は使わない）。
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from collections.abc import Mapping

from _jscompat import truthy


def herdr_bin(value: object) -> object:
    """herdr の実体。conf → 環境（ペインの中で herdr が置く HERDR_BIN_PATH）→ ~/.cargo/bin（2026-10-18 に cargo install へ移した）→ ~/opt の実体、の順。"""
    if truthy(value):
        return value
    env = os.environ.get("HERDR_BIN_PATH")
    if env:
        return env
    home = os.path.expanduser("~")
    return f"{home}/.cargo/bin/herdr" if os.path.exists(f"{home}/.cargo/bin/herdr") else f"{home}/opt/herdr/target/release/herdr"


def herdr_session(value: object) -> object:
    """herdr の名前付きセッション。conf → 環境 HERDR_SESSION → "nilkani06"。"""
    return value if truthy(value) else (os.environ.get("HERDR_SESSION") or "nilkani06")


def herdr_pane(value: object) -> object:
    """herdr のペイン id。conf → 環境 HERDR_PANE_ID → "w1:p1"。"""
    return value if truthy(value) else (os.environ.get("HERDR_PANE_ID") or "w1:p1")


def inject_backend_for(value: object, env: Mapping[str, str] | None = None) -> str:
    """注入先。conf `inject_backend` が "screen" か "herdr" なら従う。それ以外（既定の "auto"）は、
    環境に HERDR_PANE_ID があれば herdr、無ければ screen。"""
    from _jscompat import UNDEFINED, js_str

    v = "auto" if value is None or value is UNDEFINED else js_str(value)
    if v in ("screen", "herdr"):
        return v
    return "herdr" if (os.environ if env is None else env).get("HERDR_PANE_ID") else "screen"


# --- 注入 ----------------------------------------------------------------------------------------------
#
# screen 版（skills/ops/screen/screen-inject.sh）と対＝契約（引数の並び・終了コード・診断行の形）は同じにしてある。
#
#   <session>  herdr の名前付きセッション（本番は nilkani06）。`-` なら既定セッション（--session を付けない）
#   <pane>     ペイン id（本番は w1:p1。ペインの中で走る側からは $HERDR_PANE_ID）
#   <本文>     1行。改行を含むと何も送らずに終わる（多行は Claude Code が <pasted_content> に包み、起床文の先頭一致が崩れる）
# 環境:  HERDR_BIN_PATH          herdr の実体（ペインの中では herdr が置く。無ければ PATH → ~/.cargo/bin → ~/opt/herdr/target/release/herdr）
#        XDG_CONFIG_HOME         herdr の置き場。そのまま herdr に渡る（使い捨て環境はこれで隔離する）
#        HERDR_INJECT_VERBOSE=1  判定の途中経過を stderr に出す
#        HERDR_INJECT_ALLOW_DIRTY=1  入力欄の残骸を消さずに連結して送る（理由は SKILL.md）
#        HERDR_INJECT_CLEAR_MAX  Ctrl-U の上限回数（既定 40）
#        HERDR_INJECT_MIN_AGE_SEC claude の起動からこの秒数未満なら撃たない（既定 10。起動中の TUI は入力を捨てる）
#        HERDR_INJECT_WAIT_MS    送ったあと working/blocked を待つ上限ミリ秒（既定 8000。herdr 側の 5000ms の判定が先に来る）
# 終了コード: 0=送出できた（herdr が agent_prompted を返した）／非0=送っていない
#   2=使い方・前提（引数、改行、サーバ無し、ペイン無し）  3=入力欄が空にならず、本文を送らずに中止（screen 版と同じ番号）
#   4=見送り: 前景に claude が居ない  5=見送り: blocked  6=見送り: working  7=見送り: agent 未検知（unknown）
#   8=herdr が送出を拒否した（診断行にコード）  9=見送り: claude が起動直後
# 診断行は stderr に `herdr-inject: …` で出す（dream.py は失敗時にこれを watcher.log へ写す）。
# ⚠️ 診断行の頭の「herdr-inject:」は、中身が Python に移ったあともこのまま（動作ログを読む側がこの字で探す）。

_APP_ROOT = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
# 注入の入口（このファイル）。別プロセスで撃つ側は `python3 <CLI> inject <session> <pane> <本文>` と呼ぶ。
CLI = os.path.realpath(__file__)
_PANE_BOX = f"{_APP_ROOT}/skills/ops/herdr/pane-box.py"
_ENC = ("utf-8", "surrogateescape")  # 外から来た字は、読めないバイトもそのまま通す


def _say(msg: str) -> None:
    sys.stderr.buffer.write(("herdr-inject: " + msg + "\n").encode(*_ENC))
    sys.stderr.buffer.flush()


def herdr_bin_cli() -> str:
    """手で撃つ入口が使う herdr の実体：指定（HERDR_BIN_PATH）→ PATH → ~/.cargo/bin（cargo install の置き場。systemd は
    .bashrc を読まないので PATH に乗っていないことがある）→ ~/opt のチェックアウトで組んだもの、の順（2026-10-18 に cargo install へ移した）。
    対象（watcher）は herdr_bin() で決めた実体を HERDR_BIN_PATH に入れて渡すので、いつも1つめで決まる。"""
    b = os.environ.get("HERDR_BIN_PATH") or shutil.which("herdr") or ""
    if not b:
        home = os.path.expanduser("~")
        b = f"{home}/.cargo/bin/herdr" if os.access(f"{home}/.cargo/bin/herdr", os.X_OK) else f"{home}/opt/herdr/target/release/herdr"
    return b


def _json_values(text: str) -> list:
    """先頭から JSON の値を順に読む（読めない所で止める。値が1つでなくてもよい）。"""
    dec = json.JSONDecoder()
    vals: list = []
    i, n = 0, len(text)
    while True:
        while i < n and text[i] in " \t\r\n":
            i += 1
        if i >= n:
            break
        try:
            v, i = dec.raw_decode(text, i)
        except ValueError:
            break
        vals.append(v)
    return vals


def _path(v: object, keys: tuple[str, ...]) -> tuple[bool, object]:
    """v から keys を順に辿る。（辿れたか, 値）。null の先は null、オブジェクトでないものは辿れない。"""
    for k in keys:
        if v is None:
            return True, None
        if not isinstance(v, dict):
            return False, None
        v = v.get(k)
    return True, v


def _text(v: object, pretty: bool = True) -> str:
    """値を字にする（文字列はそのまま、ほかは JSON の形）。"""
    if isinstance(v, str):
        return v
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False, indent=2) if pretty else json.dumps(v, ensure_ascii=False, separators=(",", ":"))
    return json.dumps(v)


def _pick(text: str, keys: tuple[str, ...], default: str | None = None) -> str:
    """JSON から keys の先の値を字で取る。無い（null、false、辿れない）ときは default（None なら何も出さない）。"""
    outs = []
    for v in _json_values(text):
        ok, x = _path(v, keys)
        if ok and x is not None and x is not False:
            outs.append(_text(x))
        elif default is not None:
            outs.append(default)
    return "\n".join(outs)


def _first_field_after(text: str, head: str) -> str:
    """head で始まる最初の行の、空白区切りの2つめの語（無ければ空）。"""
    for line in text.split("\n"):
        if line.startswith(head):
            f = line.split()
            return f[1] if len(f) > 1 else ""
    return ""


def _etimes(pid: str) -> int | None:
    """その pid の起動からの秒数（`ps -o etimes=` と同じ数え方）。読めなければ None。"""
    if not re.fullmatch(r"[0-9]+", pid):
        return None
    try:
        with open(f"/proc/{int(pid)}/stat", "rb") as f:
            raw = f.read().decode("utf-8", "replace")
        with open("/proc/uptime", "rb") as f:
            up = int(float(f.read().split()[0]))
        start = int(raw[raw.rfind(")") + 2:].split()[19])
    except (OSError, ValueError, IndexError):
        return None
    return max(0, up - start // os.sysconf("SC_CLK_TCK"))


def _int_env(name: str, default: str) -> tuple[str, int | None]:
    """環境変数を（そのままの字, 整数として読めた値）で返す。"""
    raw = os.environ.get(name) or default
    try:
        return raw, int(raw.strip())
    except ValueError:
        return raw, None


def inject(session: str, pane: str, body: str, herdr: str | None = None) -> int:
    """herdr のペインの入力欄へ body を置いて送信する。返り値は終了コード（上の表）。診断行は stderr に出す。"""
    bin_ = herdr or herdr_bin_cli()
    clear_raw, _clear_i = _int_env("HERDR_INJECT_CLEAR_MAX", "40")
    min_age_raw, min_age = _int_env("HERDR_INJECT_MIN_AGE_SEC", "10")
    wait_ms = os.environ.get("HERDR_INJECT_WAIT_MS") or "8000"
    verbose = bool(os.environ.get("HERDR_INJECT_VERBOSE"))

    def dbg(msg: str) -> None:
        if verbose:
            _say(msg)

    def hh(*args: str, merge_stderr: bool = False) -> tuple[int, str]:
        """herdr を1回呼ぶ（上限 20 秒）。（終了コード, stdout）。merge_stderr なら stderr も同じ所へ混ぜる。"""
        cmd = [bin_] + ([] if session == "-" else ["--session", session]) + list(args)
        try:
            r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT if merge_stderr else subprocess.DEVNULL,
                               timeout=20)
            return r.returncode, r.stdout.decode(*_ENC).rstrip("\n")
        except subprocess.TimeoutExpired as e:
            return 124, (e.stdout or b"").decode(*_ENC).rstrip("\n")
        except OSError:
            return 127, ""

    if not os.access(bin_, os.X_OK):
        _say(f"herdr の実体が無い: {bin_}")
        return 2
    if not body:
        _say("本文が空")
        return 2
    if "\n" in body or "\r" in body:
        _say("本文に改行がある＝多行は <pasted_content> に包まれて起床文の先頭一致が崩れるので送らない")
        return 2

    # 1) サーバとペイン
    _rc, st = hh("status", "server", "--json")
    if '"running":true' not in st:
        _say(f"サーバが走っていない（session={session} socket={_pick(st, ('socket',), '?')}）")
        return 2

    def pane_status() -> str:
        return _pick(hh("pane", "get", pane)[1], ("result", "pane", "agent_status"))

    status = pane_status()
    if not status:
        panes = ""
        outs = []
        for v in _json_values(hh("pane", "list")[1]):
            ok, arr = _path(v, ("result", "panes"))
            if not ok or not isinstance(arr, (list, dict)):
                continue
            items = arr if isinstance(arr, list) else list(arr.values())
            if any(e is not None and not isinstance(e, dict) for e in items):
                continue
            outs.append(_text([None if e is None else e.get("pane_id") for e in items], pretty=False))
        panes = "\n".join(outs)
        _say(f"ペイン {pane} が無い（panes={panes}）")
        return 2

    def rule() -> str:
        return _first_field_after(hh("agent", "explain", pane)[1], "rule:")

    # 2) 前景に claude が居るか（agent_status は前景の消滅に追従しないので、必ずプロセスで見る）。
    #    前景プロセス群の全員を見る＝`exec ./loop.bash` の下では loop.bash と claude が同じプロセスグループに居て、
    #    先頭が loop.bash のことがある。
    pi = hh("pane", "process-info", "--pane", pane)[1]
    fg_parts: list[str] = []
    claude_pids: list[str] = []
    for v in _json_values(pi):
        ok, arr = _path(v, ("result", "process_info", "foreground_processes"))
        if not ok or not isinstance(arr, (list, dict)):
            continue
        items = arr if isinstance(arr, list) else list(arr.values())
        for e in items:
            if e is not None and not isinstance(e, dict):
                break
            fg_parts.append(f"{_text(None if e is None else e.get('pid'), pretty=False)}:{_text(None if e is None else e.get('name'), pretty=False)}")
        if all(e is None or isinstance(e, dict) for e in items):
            hit = [e.get("pid") for e in items if isinstance(e, dict) and e.get("name") == "claude"]
            if hit and hit[0] is not None and hit[0] is not False:
                claude_pids.append(_text(hit[0]))
    claude_pid = "\n".join(claude_pids)
    if not claude_pid:
        _say(f"見送り: 前景に claude が居ない（fg=[{' '.join(fg_parts)}] agent_status={status}）")
        return 4
    age = _etimes(claude_pid)
    if age is not None and min_age is not None and age < min_age:
        _say(f"見送り: claude が起動直後（{age}s < {min_age_raw}s。起動中の TUI は入力を捨てる）")
        return 9

    # 3) agent_status（blocked は確認画面・working は走行中＝どちらにも撃たない）
    if status == "blocked":
        _say(f"見送り: blocked（確認画面が開いている・rule={rule()}）")
        return 5
    if status == "working":
        _say("見送り: working（走行中のターンに重ねない＝キューにも入れない）")
        return 6
    if status not in ("idle", "done"):
        _say(f"見送り: herdr が claude を検知していない（agent_status={status} rule={rule()}）。"
             "続くなら検知規則の更新（herdr server update-agent-manifests）を疑う")
        return 7

    # 4) 入力欄（属性つきで読み、プレースホルダーの薄字と残骸を見分ける）
    def read_box() -> str:
        cmd = [bin_] + ([] if session == "-" else ["--session", session]) + ["pane", "read", pane, "--source", "visible", "--format", "ansi"]
        try:
            raw = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=20).stdout
        except subprocess.TimeoutExpired as e:
            raw = e.stdout or b""
        except OSError:
            raw = b""
        try:
            r = subprocess.run([shutil.which("python3") or sys.executable, _PANE_BOX], input=raw, stdout=subprocess.PIPE)
            return r.stdout.decode(*_ENC).rstrip("\n")
        except OSError:
            return ""

    def box_state(box: str) -> str:
        return "\n".join(m.group(1) for m in (re.match(r"box=([a-z]*)", ln) for ln in box.split("\n")) if m).rstrip("\n")

    def box_content(box: str) -> str:
        outs = [m.group(1)[:120] for m in (re.fullmatch(r"box=[a-z]* rows=[0-9]* content='(.*)'", ln) for ln in box.split("\n")) if m]
        return "\n".join(outs).rstrip("\n")

    # アタッチ判定（API に接続数は無い。クライアントソケットへの接続を ss で数える）。0=アタッチ中 1=誰も居ない 2=分からない
    def attached() -> int:
        sock = re.sub(r"herdr\.sock$", "herdr-client.sock", _pick(st, ("socket",)), flags=re.M)
        if not sock:
            return 2
        try:
            out = subprocess.run(["ss", "-xH", "state", "connected"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.decode(*_ENC)
        except OSError:
            out = ""
        n = sum(1 for ln in out.split("\n") if sock in ln)
        return 0 if n > 0 else 1

    box = read_box()
    state = box_state(box)
    dbg(box)
    if state == "dirty":
        leftover = box_content(box)
        if os.environ.get("HERDR_INJECT_ALLOW_DIRTY"):
            _say(f"入力欄が dirty だが ALLOW_DIRTY のため消さずに続行／残骸=[{leftover}]")
        else:
            att = attached()
            if att == 0:
                _say(f"入力欄が dirty で、かつクライアントがアタッチ中＝人の打鍵かもしれないので消さずに中止／残骸=[{leftover}]")
                return 3
            if att == 2:
                _say(f"入力欄が dirty で、アタッチ判定ができない＝消さずに中止／残骸=[{leftover}]")
                return 3
            # Ctrl-U は視覚行を1つしか消さない。空になるまで反復（上限つき）。Ctrl-C は空の入力欄で2回押すと claude が終わるので使わない。
            try:
                clear_max = int(float(clear_raw.strip()))
            except ValueError:
                clear_max = 0
            rounds = stuck = 0
            prev = ""
            for _ in range(max(0, clear_max)):
                if hh("pane", "send-keys", pane, "ctrl+u")[0] != 0:
                    break
                rounds += 1
                time.sleep(0.25)
                box = read_box()
                state = box_state(box)
                dbg(f"clear round={rounds} {box}")
                if state != "dirty":
                    break
                if box == prev:
                    stuck += 1
                    if stuck >= 2:
                        break
                else:
                    stuck = 0
                prev = box
            if state == "dirty":
                _say(f"入力欄の残骸が消えない（Ctrl-U {rounds}回）。本文を連結しないで中止する／残骸=[{leftover}]")
                return 3
            _say(f"入力欄の残骸を Ctrl-U {rounds}回で消した（いま {state}）／残骸=[{leftover}]")
    elif state == "unknown":
        _say(f"入力欄の行が見つからない（{box}）＝判定不能。従来どおり撃つ（fail-open）")

    # 5) 送る直前にもう一度だけ状態を見る（掃除のあいだに走り出していないか）
    status = pane_status()
    if status == "blocked":
        _say("見送り: 送る直前に blocked になった")
        return 5
    if status == "working":
        _say("見送り: 送る直前に working になった")
        return 6
    if status not in ("idle", "done"):
        _say(f"見送り: 送る直前に agent_status={status}")
        return 7

    # 6) 本文＋Enter を1回で届ける。--wait は「TUI が受け取って動き出した」の確認（受理の最終判定は呼び手＝transcript）。
    time.sleep(0.2)
    rc, res = hh("agent", "prompt", pane, body, "--wait", "--until", "working", "--until", "blocked", "--timeout", wait_ms,
                 merge_stderr=True)
    typ = _pick(res, ("result", "type"))
    code = _pick(res, ("error", "code"))
    if typ == "agent_prompted":
        _say(f"送出した（agent_prompted・agent_status={_pick(res, ('result', 'agent', 'agent_status'), '?')}・{len(body)}字）")
        return 0
    if typ == "" and code in ("agent_prompt_stalled", "timeout"):
        _say(f"送ったが {wait_ms}ms 以内に working/blocked を観測できなかった（{code}）＝受理は呼び手が確かめる")
        return 0
    if typ == "" and code == "agent_blocked":
        _say("herdr が拒否: agent_blocked（確認画面）")
        return 5
    if typ == "" and code in ("agent_not_ready", "agent_not_found", "empty_agent_prompt"):
        _say(f"herdr が拒否: {code}（{_pick(res, ('error', 'message'), '')[:160]}）")
        return 8
    _say(f"herdr の返りが読めない（rc={rc}）: {res.replace(chr(10), '')[:200]}")
    return 8


def main(argv: list[str]) -> int:
    if len(argv) >= 1 and argv[0] == "inject":
        a = argv[1:]
        # <session> と <pane> は空でも駄目。<本文> は、渡されていれば空でも受ける（空なら「本文が空」で返す）。
        if len(a) < 3 or not a[0] or not a[1]:
            sys.stderr.buffer.write("herdr-inject: usage: python3 site-python/_herdr.py inject <session> <pane> <body>\n".encode("utf-8"))
            return 2
        return inject(a[0], a[1], a[2])
    sys.stderr.buffer.write("usage: python3 site-python/_herdr.py inject <session> <pane> <body>\n".encode("utf-8"))
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
