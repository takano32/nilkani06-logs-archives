#!/usr/bin/env python3
"""watcher の制御（start | stop | status | restart [targets]）。

  bash watcher.sh {start|stop|status|restart} [targets]                     … ふだんの入口（リポジトリ直下。これを呼ぶだけの薄い入口）
  python3 site-python/_watcher_ctl.py {start|stop|status|restart} [targets] … 同じもの

見張りの本体 skills/ops/watcher/watcher.py を **detached** で 1 プロセスだけ起動し、
親（Claude）の寿命と切り離して常駐させる。監視対象は watcher.py が
configs/watcher-<name>.json から **自動発見**する（targets/<name>.py が実在し
"enabled" が false でないもの）＝呼び出し側（settings.json のフック等）に対象名を
ハードコードしない。第2引数はデバッグ用の明示指定（カンマ区切り）で、通常は不要。

対象の追加 = skills/ops/watcher/targets/<name>.py ＋ configs/watcher-<name>.json
を足すだけ（このファイルも settings.json も触らない）。

**2026-11-21 に scripts/watcher.sh（bash 568 行）から移した**（takano32 承認・管理チャンネル「やってください」）。
振る舞い（出す文、終了コード、動作ログの行、pidfile の扱い、止め方、野良の見分け方）は旧版のまま。
旧版と同じ箱を2つ作って同じ手順を当て、出力と終了コードと残ったプロセスを突き合わせてから入れ替えた。
入口の watcher.sh は同じ日に scripts/ からリポジトリ直下へ移した（「sh は APPDIR 直下にしない？」）。
.claude/settings.json の SessionStart フックと手順書は、直下の watcher.sh を呼ぶ。watcher.sh は python3 を探して
このファイルへ渡すだけで、判断は持たない。

旧版と違う所:
  - 起動失敗の通報に curl と jq を使わない（標準ライブラリの urllib で送る）。失敗の文の中身が
    「curl exit N・HTTP M」から「HTTP M」か「送れなかった（理由）」に変わった
  - 通報の文に書く復旧の手順が `bash scripts/watcher.sh …` から `bash watcher.sh …` になった（入口が直下へ移ったため）
  - 起動確認の別プロセスが、自分で通報する（旧版は scripts/watcher.sh --notify-start-failed を呼び直していた。
    その口は残してある）
  - restart の「同じ claude に紐づいた見張りが居るか」を、引数1つぶんの一致で見る
    （旧版はコマンドライン全体への部分一致で、--parent-pid=3766 が --parent-pid=37660 にも当たっていた）
  - 生死と親と稼働時間は /proc から読む（旧版は ps を呼んでいた）
  - 出力を読む側が先に閉じても（`bash watcher.sh status | head -1`）、手順を最後までやる（旧版は、閉じたパイプへ書いた所で黙って終わっていた）
  - コードの指紋に入れるのは、見張りが実際に読み込むファイルだけ（本体、対象、そこから import で辿れる部品）。
    旧版は site-python/*.py の全部とスキル配下の *.js まで入れていて、見張りと関係のない部品を直しただけで指紋が変わっていた

**このファイルは watcher 本体（watcher.py）と別にしてある**。走っている watcher の見分け方が
「コマンドラインの2つめの語が watcher.py の実パスか」なので、制御の入口を watcher.py に持たせると、
制御中のプロセス自身が watcher に見えて、野良の掃除が自分を止めてしまう。
置き場が site-python/ なのは、リポジトリルートからの位置が動かないから（スキルの置き場が動いても、
`bash watcher.sh status` と `stop` はここだけで動く）。

設定（post / channel_ids / min_scale / enabled）の解釈は watcher.py 側。
投稿は conf の "post": true のときだけ（安全側既定 OFF、takano32 の判断で有効化）。

依存は Python の標準ライブラリだけ。外部コマンドは呼ばない。
"""
from __future__ import annotations

import ast
import fcntl
import glob
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request

# 起動失敗を知らせる先（管理チャンネル）。**ここ以外へは投げない。**
ADMIN_CHAT_ID = "1509823187293048884"
DISCORD_API = "https://discord.com/api/v10"
# 起動確認の別プロセスが、起動ログを待つ上限（秒）。
START_WAIT_MAX = 180

# リポジトリルート（このファイルは直下の site-python/ にある）。
APP_DIR = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

# 見張りの本体（対象 targets/ の隣）。スキルの置き場は 2026-11-22 に .agents/skills から直下の skills/ へ移った
# （.agents/skills は古いパスのための symlink）。古いパスから起こした見張りが走っていても、照らし合わせは
# 実パスどうしでやるので見分けられる（下の is_watcher_pid）。
WATCH_PY = f"{APP_DIR}/skills/ops/watcher/watcher.py"
# 前の置き場と旧版。起こしはしない。走っているものを watcher として見分けるためだけに持つ。
#   WATCH_PY_ROOT … 2026-11-21 の数時間だけ、本体はリポジトリ直下にあった（その場所から起こしたものが走っていれば止められる）
#   WATCH_JS ……… 2026-11-21 までの旧版（bun）
WATCH_PY_ROOT = f"{APP_DIR}/watcher.py"  # hook-deps: optional（前の置き場。いまは無いのが正しい）
WATCH_JS = f"{APP_DIR}/skills/ops/watcher/watcher.js"
PID_FILE = f"{APP_DIR}/configs/watcher.pid"
# start／stop／restart の排他（pidfile の隣）。pidfile の read→write は2本が重なると競合する
# （坂本＝~/zerozari00/watch.bash の flock に倣った。2026-11-22 takano32「坂本の参考になるところ、ぜんぶパクろう」）。
LOCK_FILE = f"{PID_FILE}.lock"
# 後から来た側が待つ上限（秒）。restart は stop（最大5秒）＋1秒＋start（1秒）で、ふつう10秒かからない。
LOCK_WAIT_MAX = 20
LOG_FILE = f"{APP_DIR}/logs/watcher.log"  # 動作ログ（JSONL {ts,level,target,msg}・stderr）
# イベント正規系は watcher.py 自身が対象別に logs/watcher-<name>.jsonl / .md へ追記する
# （1 プロセス多重化で stdout が対象混在になるため）。stdout の同報は捨てる。

WATCHER_REALS = (os.path.realpath(WATCH_PY), os.path.realpath(WATCH_PY_ROOT), os.path.realpath(WATCH_JS))


def _emit(stream, s: str) -> None:
    """1行出す。出せなくても落ちない（読む側が先に閉じた `bash watcher.sh status | head -1` など）。

    Python は SIGPIPE を無視するので、閉じたパイプへ書くと BrokenPipeError になる。そのままにすると、トレースバックが出るうえに、
    起こす・止めるの途中で手順が切れる（旧版の bash も、閉じたパイプへ echo した所で SIGPIPE を受けて、そこで黙って終わっていた）。
    ここでは出せなかった行を捨てて先へ進み、手順を最後までやる。出力先を /dev/null に付け替えるのは、
    終了のときの flush で同じエラーがもう一度出ないようにするため。
    """
    if stream is None:  # 起動のときに閉じてあった（`>&-`）
        return
    try:
        stream.buffer.write((s + "\n").encode("utf-8", "replace"))
        stream.buffer.flush()
    except (OSError, ValueError):
        try:
            fd = os.open(os.devnull, os.O_WRONLY)
            os.dup2(fd, stream.fileno())
            os.close(fd)
        except (OSError, ValueError):
            pass


def out(s: str) -> None:
    _emit(sys.stdout, s)


def err(s: str) -> None:
    _emit(sys.stderr, s)


def _log_line(level: str, msg: str) -> None:
    """動作ログ（logs/watcher.log）に1行足す。書けなくても落ちない。"""
    line = json.dumps({"ts": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()), "level": level, "target": "-", "msg": msg},
                      ensure_ascii=False, separators=(",", ":")) + "\n"
    try:
        with open(LOG_FILE, "ab") as f:
            f.write(line.encode("utf-8"))
    except OSError:
        pass


def _cat(paths: list[str]) -> bytes:
    """ファイルをつないで返す（読めないものは飛ばす）。"""
    buf = []
    for p in paths:
        try:
            with open(p, "rb") as f:
                buf.append(f.read())
        except OSError:
            continue
    return b"".join(buf)


def _imports(path: str) -> set[str]:
    """そのファイルが import している、名前が `_` で始まるモジュールの名前（読めなければ空）。"""
    try:
        with open(path, "rb") as f:
            tree = ast.parse(f.read())
    except (OSError, SyntaxError, ValueError):
        return set()
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module.split(".")[0])
    return {n for n in names if n.startswith("_")}


def watcher_files() -> list[str]:
    """見張りが実際に読み込むファイル＝本体、対象（targets/*.py）、そこから import で辿れる site-python/ の部品。

    並びは、本体、部品（名前の文字コード順）、対象（同じ）。部品は名前の一覧を手で持たず、import の行から辿る
    （部品を足したときに、ここを直し忘れて指紋から漏れる、を無くす）。
    """
    targets = sorted(glob.glob(f"{os.path.dirname(WATCH_PY)}/targets/*.py"))
    parts: dict[str, str] = {}
    todo = [WATCH_PY] + targets
    while todo:
        for name in sorted(_imports(todo.pop())):
            p = f"{APP_DIR}/site-python/{name}.py"
            if name not in parts and os.path.isfile(p):
                parts[name] = p
                todo.append(p)
    return [WATCH_PY] + [parts[k] for k in sorted(parts)] + targets


def fingerprints() -> tuple[str, str]:
    """コードと設定の指紋（sha256 の頭 12 桁）。

    コードの指紋に入れるのは、**見張りが実際に読み込むファイルだけ**（watcher_files）。
    旧版は site-python/*.py の全部と、スキル配下の *.js まで入れていた。site-python/ には見張りと関係のない部品
    （_oauth1.py、_media_fetch.py など）もあるので、それらを直しただけで指紋が変わり、wake-record.py が見張りの
    入れ替わりの理由を「コードが変わった」と読み違えていた（2026-11-21 のレビューで見つかった）。
    本体が無ければ「?」（旧版は、スキルのディレクトリへ入れないときに「?」だった）。
    """
    code = hashlib.sha256(_cat(watcher_files())).hexdigest()[:12] if os.path.isfile(WATCH_PY) else "?"
    conf = hashlib.sha256(_cat(sorted(glob.glob(f"{APP_DIR}/configs/watcher-*.json")))).hexdigest()[:12]
    return code, conf


# 起動要求の1行を動作ログに書く（2026-10-23 に足した。観測を増やすだけで、起動の判断には使わない）。
# **なぜ要るか**＝`wake-record.py` は watcher の入れ替わりを、`watcher 起動` 行が1つ前と比べて
# 何か変わったか（targets・parent_pid など）で読む。**設定ファイルやコードを直して stop→start した
# 入れ替わりは、その行が1文字も変わらない**ので「理由が読めない」の旗になっていた
# （2026-10-17 04:25・08:27、10-22 09:09 の3件。3件とも手で撃った stop→start で、SessionStart フックではなかった）。
# ここで、呼び元（SessionStart フックか、それ以外か）と、コードと設定の指紋（sha256 の頭 12 桁）を残す。
# 指紋は中身を出さない（設定に投稿先などが入っていても、ハッシュしか書かない）。
# ⚠️ 行の頭の「watcher.sh 起動要求」は、中身が Python に移ったあともこのまま（wake-record.py がこの字で探す）。
def log_launch_request(subcmd: str) -> None:
    via = "SessionStartフック" if os.environ.get("CLAUDE_PARENT_PID") else "フック外"
    code, conf = fingerprints()
    _log_line("info", f"watcher.sh 起動要求: 口={subcmd or '?'} 呼び元={via} code={code} conf={conf}")


# python3 のパス解決。**絶対パスで起こす**＝プロセス名（comm）がその実行ファイルの名前に決まり、野良の走査が名前で絞れる
# （走査は python3 と、ここで決まった名前の両方を候補にする＝kill_stray_watchers）。
def find_python() -> str | None:
    p = shutil.which("python3")
    if p:
        return p
    if os.access("/usr/bin/python3", os.X_OK):
        return "/usr/bin/python3"
    return None


# --- /proc の読み方 -------------------------------------------------------------------------------------

def _stat(pid: int) -> tuple[str, str, int, int] | None:
    """/proc/<pid>/stat から（名前, 状態, 親の pid, 起動時刻（clock tick））を読む。読めなければ None。"""
    try:
        with open(f"/proc/{pid}/stat", "rb") as f:
            raw = f.read().decode("utf-8", "replace")
    except OSError:
        return None
    lp, rp = raw.find("("), raw.rfind(")")
    if lp < 0 or rp < 0:
        return None
    rest = raw[rp + 2:].split()
    try:
        return raw[lp + 1:rp], rest[0], int(rest[1]), int(rest[19])
    except (IndexError, ValueError):
        return None


def _comm(pid: int) -> str:
    """`ps -o comm=` と同じ見え方の名前（ゾンビは「名前 <defunct>」＝名前の一致には当たらない）。"""
    st = _stat(pid)
    if st is None:
        return ""
    return st[0] + (" <defunct>" if st[1] == "Z" else "")


def _ppid(pid: int) -> int | None:
    st = _stat(pid)
    return None if st is None else st[2]


def _alive(pid: int) -> bool:
    """`kill -0` と同じ判定（signal を送れない相手は「居ない」扱い）。"""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _pids_by_comm(name: str) -> list[int]:
    """プロセス名（comm）が厳密に name のものを、pid の小さい順に返す（`pgrep -x` と同じ絞り方）。"""
    res = []
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        try:
            with open(f"/proc/{d}/comm", "rb") as f:
                if f.read().rstrip(b"\n").decode("utf-8", "replace") == name:
                    res.append(int(d))
        except OSError:
            continue
    return sorted(res)


def _argv(pid: int) -> list[bytes] | None:
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            raw = f.read()
    except OSError:
        return None
    parts = raw.split(b"\0")
    if parts and parts[-1] == b"":
        parts.pop()
    return parts


# その pid が watcher 本体なら True を返す。
# 見るのは **コマンドラインの2つめの語（実行系が走らせているスクリプト）だけ**＝それが watcher.py（旧版なら
# watcher.js）の実パスなら watcher。「コマンドラインのどこかに watcher.py という字がある」では決めない
# （引数にそのパスを持っているだけの別のプロセス＝構文チェックやエディタを、watcher と取り違えないため）。
# 相対パスで起こしたもの（手で `python3 watcher.py --target=…` と打った野良）は、そのプロセスの cwd から解く。
# ⚠️ 読むのは `/proc/<pid>/cmdline`（`ps -o args=` は端末幅で切れる＝下の running_pid の注記）。
def is_watcher_pid(pid: int) -> bool:
    argv = _argv(pid)
    if argv is None or len(argv) < 2 or not argv[1]:
        return False
    script = os.fsdecode(argv[1])
    if not script.startswith("/"):
        try:
            cwd = os.readlink(f"/proc/{pid}/cwd")
        except OSError:
            return False
        script = f"{cwd}/{script}"
    return os.path.realpath(script) in WATCHER_REALS


# 自分の PID から親を辿り、comm が "claude" である最初の祖先の PID を返す（無ければ None）。
# **親の pid を1ホップとして使わない**：フック経由なら親が claude だが、手で
# `bash watcher.sh restart` と打つとその bash が1段挟まってずれる（2026-07-15 実機確認）。
# ⚠️ 2026-09-08 に cmd_start から切り出した＝**restart の冪等判定でも同じ答えが要る**ため。
# 2箇所で別々に辿ると、片方だけ直したときに食い違う。
# ⚠️ 起点を渡せるようにした（2026-09-11・takano32 判断「あ」・管理チャンネル）。
# 既定は従来どおり自分から辿る。**引数があれば、その pid から辿る。**
#
# 【なぜ要るか】SessionStart フックは `… & exit 0` の形で撃つので、
# **この関数が走るときには、もう親が居ない**（ppid=1 で1段目に打ち切られる）。
# 実測＝同じ形を5回撃って5回とも ppid=1（競合ではなく、この形なら毎回そうなる）。
# ログの数も一致（渡ったのは手で叩いた4回だけ、フック経由の8回は全部フォールバック）。
# 落ちる先の `pgrep -x claude` は、2026-07-15 の修正が「バグだった」と名指ししている判定で、
# 当時は世代交代のたびに watcher が積み上がり、同時に7本走っていた。
#
# 【どう直したか】フック側が `CLAUDE_PARENT_PID=$PPID` を付けて撃つ。
# `$PPID` は**フックのシェルが `&` で切り離される前に展開される**ので、親が居るうちの値が入る。
# ここでは**その値を起点にして、同じ歩き方で上へ辿る**＝
# フックのシェルの親が claude なら1段で当たるし、間に何か挟まっていても辿って届く。
#
# 【安全側】渡された値は**信じない**。`comm` が `claude` であることを確かめてから返す。
# 数でなければ無視、死んでいれば無視、別のプロセスなら無視して、**従来のフォールバックへ落ちる。**
# ＝この変更で新しく壊れる経路は無い（渡らなければ、いままでと同じ動きになる）。
def find_claude_pid(start: int | None = None) -> int | None:
    walk_pid = os.getpid() if start is None else start
    # 起点そのものが claude のこともある（フックのシェルの親が claude の場合）
    if _comm(walk_pid) == "claude":
        return walk_pid
    for _ in range(8):
        walk_ppid = _ppid(walk_pid)
        if walk_ppid is None or walk_ppid in (0, 1):
            break
        if _comm(walk_ppid) == "claude":
            return walk_ppid
        walk_pid = walk_ppid
    return None


# 自分から辿り、だめならフックが渡した起点から辿る（上の理由）。
# ⚠️ 順番は「自分から」が先＝手で叩いたときは環境変数が無いか古いことがあるので、
#    その場に居る親のほうを信じる。
def resolve_claude_pid() -> int | None:
    p = find_claude_pid()
    if p is not None:
        return p
    v = os.environ.get("CLAUDE_PARENT_PID", "")
    if re.fullmatch(r"[0-9]+", v):
        return find_claude_pid(int(v))
    return None


# pidfile の pid が「この watcher として」生きていれば、その pid を返す（生死判定）。
# kill -0 だけだと再起動を挟んだ pid 再利用で別プロセスを起動中と誤認しうるので、
# コマンドラインが watcher 本体のものであることまで確認する（is_watcher_pid）。
#
# 【結果の受け取り方】（pid, 理由）の組で返す。生きていなければ pid は None で、理由に落ちた訳が入る。
#
# 【なぜ理由を分けるのか】以前は呼び出し側が
# `起動していません（pidfile 無し or プロセス不在）` の1文で済ませていて、**3つの別物**
# （①pidfile が無い ②pid が死んでいる ③生きているが watcher ではない）を潰していた。
# 2026-08-03 の誤診（`ps` が COLUMNS 幅で切られて③に落ちていた）は、この1文のせいで
# **原因の切り分けに調査を1回まるごと使った**。分けて出せば次は文面だけで分かる。
def running_pid() -> tuple[int | None, str]:
    if not os.path.isfile(PID_FILE):
        return None, f"pidfile が無い（{PID_FILE}）"
    try:
        with open(PID_FILE, "rb") as f:
            raw = f.read().decode("utf-8", "replace").rstrip("\n")
    except OSError:
        raw = ""
    if not re.fullmatch(r"[0-9]+", raw):
        return None, f"pidfile の中身が pid になっていない（\"{raw}\"）"
    pid = int(raw)
    # 存在の判定は `/proc` で見る。`kill -0` 単独だと、**生きていても signal を送れない相手**
    # （別ユーザーのプロセス）で EPERM になり、「存在しない」と誤って報告する
    # （実測＝pid 1 に対して `kill -0` が失敗する）。この watcher は常に自分の持ち物なので
    # 実運用では起きないが、**理由を出すために書き分けている以上、嘘の理由を出さない。**
    if not os.path.isdir(f"/proc/{raw}"):
        return None, f"pid {raw} のプロセスが存在しない（pidfile が古い）"
    if not _alive(pid):
        return None, f"pid {raw} は存在するが signal を送れない（別ユーザーのプロセス＝pid 再利用）"
    # ⚠️ ここで `ps -o args=` を使ってはいけない。`ps` は出力を COLUMNS 幅で切るので、
    # 狭い端末（SessionStart フックの環境は COLUMNS=42 だった）だと引数が途中で消え、
    # 生きている本人を「別プロセス」と誤判定する。実測＝COLUMNS<=85 で不一致・86 以上で一致
    # （当時の本体 "watcher.js" が 86 桁目で終わるため）。2026-08-03 に実害が出た＝正しい pidfile を
    # 消したうえで、正規の watcher を「野良」として kill していた。`/proc` は幅で切られない。
    if not is_watcher_pid(pid):
        return None, f"pid {raw} は生きているが watcher 本体（watcher.py）ではない（pid 再利用か、判定側の不具合）"
    return pid, ""


# 旧世代（対象別プロセス watcher-<name>.js ＋ watcher-<name>.pid）の残骸 pidfile を掃除する。
# 本体の kill はしない：watcher-<name>.js は 6b9c924（1プロセス多重化）で消えており、その名前で
# 走っているプロセスはもう存在しえない。書き手も残っていない（pidfile を書くのはこの
# ファイルの PID_FILE だけ）ので、これは古い箱から引き継いだファイルを消すだけの掃除。
def sweep_legacy_pidfiles() -> None:
    for p in glob.glob(f"{APP_DIR}/configs/watcher-*.pid"):
        try:
            os.remove(p)
        except OSError:
            pass


def _signal(pid: int, sig: int) -> None:
    """プロセスグループ（-pid）へ送り、だめなら pid へ送る（setsid で起こしてあるので pid=pgid）。"""
    if pid <= 1:  # -1 は「送れる相手すべて」になる。watcher の pid が 1 以下のことは無い
        return
    try:
        os.kill(-pid, sig)
    except OSError:
        try:
            os.kill(pid, sig)
        except OSError:
            pass


# pidfile に載っていない野良 watcher を止める（takano32 承認 2026-07-25＝旧 stop_legacy の置き換え）。
#
# 旧実装は「pidfile を辿って kill」する形で、しかも一致しない相手でも pidfile だけは消していた。
# 直そうとして前提を確かめたら、**辿るべき pidfile がそもそも作られない**と分かった＝ad-hoc 起動
# （`bun watcher.js --target=dream` を手で叩く）は pidfile を書かないので、旧実装が塞げていた穴は
# 最初から存在しなかった。実際の危険はこちらで、野良は running_pid() から見えないため
# **start は二重起動を拒否できず、stop も殺せない**。dream が二重に注入しうる。
#
# なので pidfile ではなく**プロセスを走査**して、追跡中の pid 以外を止める。
#
# 【重要】コマンドラインへの部分一致（`pgrep -f` / `pkill -f` の類）では探さない。あれは「コマンドラインに
# 文字列を含む」だけで一致するので、**その文字列を本文に持っているだけの無関係なプロセス**（呼び出し側のシェル、
# エディタ、grep 自身）まで拾う。2026-07-25 に実際に踏んだ：`watcher\.js` への部分一致が
# このスクリプトを起動したシェルに一致し、TERM が**そのプロセスグループごと**落とした
# （実行中のシェルが死んだ）。掃除のつもりが巻き添えを出す。
# 代わりに **プロセス名が厳密に python3（旧版は bun）のものだけ**を候補にし、走らせているスクリプトが
# watcher.py（旧版は watcher.js）の実パスかで絞る（is_watcher_pid）。名前で絞るのでシェルや grep は原理的に入らない。
# python3 は bun と違ってこの箱で何本も走っているので、**「引数のどこかにパスがある」では絞らない**
# ＝watcher.py を引数に取るだけの python3（構文チェックなど）を野良と取り違えて落とさないため。
# この制御のプロセス自身も python3 だが、走らせているスクリプトがこのファイルなので当たらない。
# TERM を送り、最大 5 秒だけ終了を待ち、残っていれば KILL で確実に落とす。
# setsid で pid=pgid なので、まずプロセスグループ（-pid）へ送る。
#
# 【なぜ待つのか】投げっぱなしにすると、相手が TERM を無視した／終了処理が長引いた場合に
# **古いものが生きたまま新しいものが起動して二重稼働**しうる（dream の二重注入・
# 地震速報の二重投稿）。cmd_stop には元から待ちがあったが kill_stray_watchers には
# 無く、そちらは約1秒後に新起動へ進んでいた（2026-08-03 takano32 判断 A・管理チャンネル
# ＝「残留がないように保証しようぜ」）。実発生の観測はゼロだが、**起動が数秒遅れる代償で
# 二重稼働の芽を潰す**ほうを採った。
#
# 【返り値】落とせたら True、5 秒待って KILL してもまだ生きていたら False（呼び出し側が報告できる）。
def terminate_pid(pid: int) -> bool:
    _signal(pid, signal.SIGTERM)
    # 刻みは 1 秒のまま（cmd_stop が元から持っていた形）。0.2 秒刻み×25 も試したが、
    # **この箱では差が出なかった。**実測（TERM に従う相手／無視する相手）＝
    # 1 秒刻み 1.78s・2.02s ／ 8.27s・6.49s、0.2 秒刻み 1.24s ／ 8.25s。
    # **同じ設定でも回ごとに 2 秒以上ぶれる**ので、刻みの差はこのぶれに埋もれている。
    # 5 秒の予算に対して 6〜8 秒かかっているとおり、**所要を決めているのは刻みの細かさではなく
    # 箱の負荷**（2 vCPU を本流と取り合う）。**ここを速くしたいなら、刻みではなく負荷を見ること。**
    for _ in range(5):
        if not _alive(pid):
            return True
        time.sleep(1)
    _signal(pid, signal.SIGKILL)
    # KILL は無視できないが、刈り取りまでに一瞬かかる。
    time.sleep(1)
    return not _alive(pid)


def kill_stray_watchers(tracked: int | None, py: str) -> None:
    # 候補の並びは旧版（pgrep を3回）と同じ＝python3、起こすのに使う実行ファイルの名前、bun の順。
    cands = _pids_by_comm("python3") + _pids_by_comm(os.path.basename(py)) + _pids_by_comm("bun")
    for pid in cands:
        if tracked is not None and pid == tracked:
            continue
        if not is_watcher_pid(pid):
            continue
        out(f"野良 watcher (pid {pid}) を停止します（pidfile に載っていない）")
        if terminate_pid(pid):
            out(f"  停止を確認しました (pid {pid})")
        else:
            err(f"  ⚠️ SIGKILL 後も生存しています (pid {pid})＝二重稼働の恐れ")


# 管理チャンネルへ1行知らせる（起動失敗の通報専用）。
#
# 【なぜ要るか】**2026-08-04 に、止めたあと起動側が静かに失敗して約1時間 watcher が不在になった。**
# pidfile だけが古いまま残り、**気づいたのは、たまたま状態を見たから。**
# `cmd_start` は失敗を stderr に書いていたが、**SessionStart フックから呼ばれると誰も読まない。**
# 見張りが居ないことは見張り自身には通報できないので、**起動する側が知らせる**（takano32 承認 2026-08-04・管理チャンネル）。
#
# 【失敗しても止めない】通報が飛ばなくても起動処理の成否は変えない（通報は付帯であって本務ではない）。
def notify_admin(text: str) -> bool:
    token = os.environ.get("DISCORD_BOT_TOKEN", "")  # 環境変数だけ（.env は開かない）
    if not token:
        err("⚠️ 管理チャンネルへ知らせられません（環境変数 DISCORD_BOT_TOKEN が無い（.env に置いて /quit で反映））")
        return False
    # ⚠️ 成否は HTTP の状態で見る（2026-10-26）。それまでは本文を捨てたまま送信コマンドの終了コードだけを見ていたので、
    #    Discord が 401（トークン失効）・403（権限剥奪）・429（レート）を返しても「送れた」として成功を返していた
    #    （2026-09-11 の点検で実測。`data/REVIEW_TASKS.md` の決着「watcher.sh の notify_admin が、HTTP 401/403/429 でも…」）。
    #    失敗は stderr の1行に加えて logs/watcher.log にも1行残す＝SessionStart 経由は stderr も終了コードも捨てられるので、
    #    後から追えるのはログだけ。呼び出し側は変えない（どちらも失敗を無視する＝上の【失敗しても止めない】のまま）。
    body = json.dumps({"content": text}, ensure_ascii=False, indent=2).encode("utf-8")
    req = urllib.request.Request(f"{DISCORD_API}/channels/{ADMIN_CHAT_ID}/messages", data=body, method="POST",
                                 headers={"Authorization": f"Bot {token}", "Content-Type": "application/json",
                                          "User-Agent": "DiscordBot (watcher, 1.0)", "Accept": "*/*"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            status = r.status
        why = "" if 200 <= status < 300 else f"HTTP {status}"
    except urllib.error.HTTPError as e:
        why = f"HTTP {e.code}"
        e.close()
    except Exception as e:  # つながらない、時間切れ、など
        why = f"送れなかった（{type(e).__name__}）"
    if why:
        err(f"⚠️ 管理チャンネルへの通報に失敗しました（{why}）")
        _log_line("warn", f"管理チャンネルへの通報に失敗: {why}")
        return False
    return True


def cmd_start(targets_arg: str, subcmd: str, py: str) -> int:
    pid, _reason = running_pid()
    if pid is not None:
        # 追跡中のものは残し、野良だけ落とす（放置すると dream が二重に注入しうる）。
        kill_stray_watchers(pid, py)
        err(f"すでに起動中です (pid {pid})。二重起動はしません。")
        return 1
    sweep_legacy_pidfiles()
    # 追跡中が居ない＝走っている watcher は全部野良。
    kill_stray_watchers(None, py)
    # 古い stale pidfile は掃除。
    try:
        os.remove(PID_FILE)
    except OSError:
        pass

    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    args = []
    if targets_arg:
        args.append(f"--target={targets_arg}")
    # この入口からの起動は supervised＝watcher が親(Claude)の生存を監視し、Claude が止まったら
    # 自滅する（detached でもオーファンにしない。SessionStart フックでの常駐用）。
    args.append("--supervised")
    # この制御を起動した claude 本体の特定 PID を渡す。watcher.py 側はこの PID の
    # 生死だけを見て自滅判定する（2026-07-15 修正：以前は「claude という名前のプロセスが
    # どれか1つでも存在するか」を pgrep で見ていたため、loop.bash の即再起動で判定がほぼ
    # 常に真になり、世代交代のたびに古い watcher が自滅せず積み上がるバグがあった。実測で
    # 3日以上生きた watcher が複数、同時に7プロセス走っていたのを発見）。
    # 親の pid を単純に1ホップとして使わない：SessionStart フック経由なら親が直接 claude の
    # PID になるが、bash 経由で手動実行するとその bash 自体が1段挟まってずれる
    # （2026-07-15 実機確認：手動 `bash watcher.sh restart` で親の pid が claude と一致しなかった）。
    # 代わりに自分の PID から親を辿り、comm が "claude" である最初の祖先を探す。
    claude_pid = resolve_claude_pid()
    if claude_pid is not None:
        args.append(f"--parent-pid={claude_pid}")

    # 新しいセッションに分離＝親の寿命と切り離す（detached）。
    # stdin は /dev/null。イベントは本体が対象別ファイルへ書くので stdout は捨て、
    # stderr（動作ログ JSONL）だけ .log に追記する。
    # 起動前のログ長を控える＝この起動が書いた行だけを見るため。
    try:
        log_before = os.path.getsize(LOG_FILE) if os.path.isfile(LOG_FILE) else 0
    except OSError:
        log_before = 0
    # 起動要求の1行は log_before を取った後に書く（下の確かめ役が探すのは `watcher 起動` 行なので、混ざっても当たらない）。
    log_launch_request(subcmd)

    with open(LOG_FILE, "ab") as lf:
        proc = subprocess.Popen([py, WATCH_PY, *args], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=lf,
                                start_new_session=True)
    newpid = proc.pid
    with open(PID_FILE, "w", encoding="utf-8") as f:
        f.write(f"{newpid}\n")

    # 起動直後に即死していないかだけ、ここで軽く見る（速い判定＝フックを待たせない）。
    # ⚠️ 自分の子なので、生死は poll で見る（終わった子は刈り取るまでゾンビで残り、kill -0 の判定では生きて見える）。
    time.sleep(1)
    if proc.poll() is not None:
        err(f"起動に失敗しました（起動直後に落ちた）。log を確認してください: {LOG_FILE}")
        try:
            os.remove(PID_FILE)
        except OSError:
            pass
        notify_admin("⚠️ 見張りの起動に失敗しました（起動直後に落ちた）。**いま見張りは居ません。**復旧は `bash watcher.sh restart`、様子は `logs/watcher.log`。")
        return 1

    # **「1秒生きている」だけでは足りない**（2026-08-04）。プロセスが居ても、初期化まで届かずに
    # 静かに消えることがある＝そのときログには起動行すら残らない。**だから watcher 自身が
    # 「起動」を書くまで待って、書かなければ知らせる。**
    #
    # **⚠️ ただし待つのは別プロセスで、殺さない**（2026-08-04 に同日修正）。
    # 最初は「8秒待って、書かなければ落として失敗にする」と書いた。**それが実地で誤射した**——
    # 箱が swap で詰まって load が 7 を超えていた窓で、**まだ初期化中だっただけの watcher を
    # 起動失敗と判定して落とした。**遅いのと死んでいるのは別物で、**8秒は忙しい箱には短すぎる。**
    # 直し方を2つ変えた：
    #   1. **前景で待たない**＝SessionStart フックを何十秒も止めない。確かめ役は detached で回す
    #   2. **確かめ役は殺さない**＝遅れて立ち上がるほうが、落とされるより遥かにまし。
    #      **知らせるだけにして、判断は人に返す**（見送りの向きに倒す）
    wait_max = START_WAIT_MAX
    subprocess.Popen([py, os.path.realpath(__file__), "--check-start", str(log_before), str(newpid), str(wait_max)],
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)

    out(f"起動しました (pid {newpid}, targets: {targets_arg or '自動発見'})。動作ログ: {LOG_FILE} / イベント: {APP_DIR}/logs/watcher-<target>.jsonl")
    out(f"  （起動ログが出るかは別プロセスが最大 {wait_max} 秒見張ります。出なければ管理chへ知らせます。落としはしません）")
    return 0


START_FAILED_TEXT = ("⚠️ 見張りの起動を確かめられませんでした（{why}）。**落としてはいません**——遅れて立ち上がっているかもしれないので、"
                     "まず `bash watcher.sh status` を見てください。居なければ `restart`。様子は `logs/watcher.log`。")


# 起動確認の別プロセス（cmd_start が detached で起こす。人が直に叩くものではない）。
# **知らせるだけで、プロセスには触らない**（誤射の再発を構造で防ぐ＝この経路に kill は無い）。
def check_start(log_before: int, newpid: int, wait_max: int) -> int:
    needle = '"msg":"watcher 起動'.encode("utf-8")
    why = None
    for _ in range(wait_max):
        time.sleep(1)
        try:
            with open(LOG_FILE, "rb") as f:
                f.seek(log_before)
                if needle in f.read():
                    return 0
        except OSError:
            pass
        if not _alive(newpid):
            why = "起動ログを書かないまま消えた"
            break
    if why is None:
        why = f"{wait_max}秒たっても起動ログを書かない（プロセスは居る）"
    _log_line("warn", f"起動確認に失敗: {why}")
    notify_admin(START_FAILED_TEXT.format(why=why))
    return 0


def cmd_stop(py: str) -> int:
    sweep_legacy_pidfiles()
    pid, reason = running_pid()
    if pid is None:
        out(f"起動していません＝{reason}")
        try:
            os.remove(PID_FILE)
        except OSError:
            pass
        # pidfile が無くても野良が走っていることがある（それがこの修正の主眼）。
        kill_stray_watchers(None, py)
        return 0
    # TERM → 最大5秒待ち → 残れば KILL（実体は terminate_pid。野良掃除と同じ手順を使う）。
    if not terminate_pid(pid):
        err(f"⚠️ SIGKILL 後も生存しています (pid {pid})")
    try:
        os.remove(PID_FILE)
    except OSError:
        pass
    # 追跡外の野良も一緒に落とす（stop は「watcher を止める」であって
    # 「pidfile に載っているものだけ止める」ではない）。
    kill_stray_watchers(None, py)
    out(f"停止しました (pid {pid})。")
    return 0


def _etime(pid: int) -> str:
    """稼働時間を `ps -o etime=` と同じ形（[[日-]時:]分:秒）で返す。読めなければ空。"""
    st = _stat(pid)
    try:
        with open("/proc/uptime", "rb") as f:
            up = int(float(f.read().split()[0]))
    except (OSError, ValueError, IndexError):
        return ""
    if st is None:
        return ""
    t = max(0, up - st[3] // os.sysconf("SC_CLK_TCK"))
    ss, t = t % 60, t // 60
    mm, t = t % 60, t // 60
    hh, dd = t % 24, t // 24
    s = f"{dd}-" if dd else ""
    if dd or hh:
        s += f"{hh:02d}:"
    return s + f"{mm:02d}:{ss:02d}"


def cmd_status() -> int:
    pid, reason = running_pid()
    if pid is not None:
        ppid = _ppid(pid)
        out(f"running (pid {pid}, ppid {'?' if ppid is None else ppid}, 稼働 {_etime(pid) or '?'})")
        out(f"  動作ログ: {LOG_FILE}")
        out(f"  イベント(正規系): {APP_DIR}/logs/watcher-<target>.jsonl（対象別）")
        return 0
    # 理由まで出す＝「stopped」だけだと、pidfile が無いのか・pid が死んでいるのか・
    # 生きているのに判定が外れているのかが区別できない（2026-08-03 の誤診がまさにこれ）。
    out(f"stopped（{reason}）")
    return 1


def cmd_restart(targets_arg: str, subcmd: str, py: str) -> int:
    # ⚠️ 撃つ前に「もう要らないか」を見る（2026-09-08・takano32 判断 か・管理チャンネル）。
    # このフックがやりたいのは**見張りが親に紐づいている状態にすること**であって、
    # **撃ち直すことではない。**同じ claude に紐づいた見張りが既に生きているなら、何もしない。
    #
    # **なぜ要るか**＝`SessionStart` は matcher が無いので `compact` でも発火する。
    # **コンパクションでは claude の pid が変わらない**ので、張り直しても紐づく先は同じ。
    # 得るものが無いのに、**落として起こし直す 6 秒だけ見張りが居なくなる**
    # （実測＝PreCompact は 14日で 16件・1日あたり 1.1 回）。
    #
    # ⚠️ **発火元の名前で絞らない**（matcher を `startup|resume` にする案は採らなかった）＝
    # 名前が増減すると黙って外れる。**条件そのものを見るほうが、発火元が増えても腐らない。**
    want_pid = resolve_claude_pid()
    if want_pid is not None:
        pid, _reason = running_pid()
        if pid is not None:
            # 引数1つぶんの一致で見る（部分一致だと --parent-pid=3766 が --parent-pid=37660 にも当たる）
            if f"--parent-pid={want_pid}".encode() in (_argv(pid) or []):
                out(f"既に claude({want_pid}) に紐づいた見張りが居ます (pid {pid})。何もしません。")
                return 0
    cmd_stop(py)
    time.sleep(1)
    return cmd_start(targets_arg, subcmd, py)


# --- 短命セッション（`claude --print`）からの乗っ取りを断る ------------------
#
# **2026-07-27 に実害が出たので入れた。**シャドー評価で `claude --print --model sonnet` を
# 1問ずつ回したところ、**その短命セッションが SessionStart フックでここを叩き**、
# watcher を起動し直した。**起動し直された watcher は、その短命セッションを親だと思い込む**
# （`--parent-pid` に渡すのが「自分の祖先で最初に見つかる claude」なので）。
# 結果、**試験が終わって親が消えた瞬間に watcher も道連れで自滅**した。
# ログに「親（claude）が 3 回連続で見つからない→watcher を終了します」が2回残っている
# （13:00 と 13:09＝試験の最後の2問が終わった時刻と一致）。
#
# **本体はずっと生きていたのに、watcher だけが 2 時間13分死んでいた。**
# 止まったのは夢だけでなく**地震速報も**で、**黙って止まる最悪の落ち方**をしていた。
#
# 断り方は2つ重ねる：
#   1. `NILKANI_SHADOW=1`（呼ぶ側が明示。`scripts/phase1-shadow.sh` が渡す）
#   2. 祖先の claude が `--print`／`-p` 付き＝非対話の短命セッション
# 1 は確実だが**こちらが仕込んだ経路にしか働かない**。2 は取りこぼしを拾う一般則。
# **どちらかに当たったら、走っている watcher に一切触らずに終わる**（止めない・入れ替えない）。
def watcher_skip_reason() -> str | None:
    # `NILKANI_SHADOW` が正名。`NILKANI_WATCHER_SKIP` は旧名（2026-07-27 の数時間だけ使った）。
    if os.environ.get("NILKANI_SHADOW"):
        return "NILKANI_SHADOW"
    if os.environ.get("NILKANI_WATCHER_SKIP"):
        return "NILKANI_WATCHER_SKIP（旧名）"
    walk_pid = os.getpid()
    for _ in range(8):
        walk_ppid = _ppid(walk_pid)
        if walk_ppid is None or walk_ppid in (0, 1):
            break
        if _comm(walk_ppid) == "claude":
            raw = b" ".join(_argv(walk_ppid) or [])
            # 引数だけを見る＝プロンプト本文に "--print" が入っていても誤爆しないよう、
            # 先頭の実行ファイル名の直後から、最初の非オプション語までで判定する。
            for tok in raw.split()[1:]:
                if tok in (b"--print", b"-p"):
                    return f"親 {walk_ppid} が --print（非対話）"
                if not tok.startswith(b"-"):
                    break  # 非オプション＝プロンプト本文に入ったので打ち切り
            break
        walk_pid = walk_ppid
    return None


# start／stop／restart を1本ずつにする（2026-11-22）。2本目は退かずに、前の1本が終わるまで短く待つ。
# 待つほうを選んだ理由＝どの操作も「いまの状態を見てから動く」作りなので（start は走っていれば断る、
# restart は同じ claude に紐づいていれば何もしない）、前の1本が終わってから見直せば正しい答えになる。
# 退くと、前の1本が失敗したとき（起動直後に落ちた等）にやり直す機会を捨てる。
# 待つ上限を過ぎたら退く（SessionStart フックを長く止めない）。ロックは fd を閉じれば外れ、
# プロセスが死んでもカーネルが外す（pidfile と違って、残骸で詰まらない）。
# open() の fd は既定で子に継がれない（Python 3.4 以降）＝起こした watcher がロックを抱えたままにならない。
def take_lock():
    try:
        os.makedirs(os.path.dirname(LOCK_FILE), exist_ok=True)
        f = open(LOCK_FILE, "a")
    except OSError as e:
        err(f"⚠️ 排他ロックを開けない（{e}）。ロックなしで続けます")
        return open(os.devnull, "a")
    deadline = time.monotonic() + LOCK_WAIT_MAX
    told = False
    while True:
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return f
        except OSError:
            if time.monotonic() >= deadline:
                f.close()
                return None
            if not told:
                err(f"別の start／stop／restart が走っているので、終わるのを待ちます（最大 {LOCK_WAIT_MAX} 秒）")
                told = True
            time.sleep(0.2)


def main(argv: list[str]) -> int:
    py = find_python()
    if py is None:
        err("python3 が見つかりません")
        return 1
    a1 = argv[0] if argv else ""
    targets_arg = argv[1] if len(argv) > 1 else ""

    # 起動確認の別プロセスから呼ばれる内部の口（人が直に叩くものではない）。
    if a1 == "--notify-start-failed":
        notify_admin(START_FAILED_TEXT.format(why=(argv[1] if len(argv) > 1 and argv[1] else "理由不明")))
        return 0
    if a1 == "--check-start":
        try:
            return check_start(int(argv[1]), int(argv[2]), int(argv[3]))
        except (IndexError, ValueError):
            return 2

    if a1 in ("start", "restart"):
        reason = watcher_skip_reason()
        if reason is not None:
            err(f"短命セッションからの起動要求なので何もしません（{reason}）。走っている watcher には触れていません。")
            return 0

    if a1 == "status":
        return cmd_status()
    if a1 in ("start", "stop", "restart"):
        lock = take_lock()
        if lock is None:
            err(f"別の start／stop／restart が {LOCK_WAIT_MAX} 秒たっても終わらないので、何もしません（{LOCK_FILE}）。")
            _log_line("warn", f"{a1}: 排他ロックが {LOCK_WAIT_MAX} 秒取れず退いた")
            return 1
        try:
            if a1 == "start":
                return cmd_start(targets_arg, a1, py)
            if a1 == "stop":
                return cmd_stop(py)
            return cmd_restart(targets_arg, a1, py)
        finally:
            lock.close()
    argv0 = os.environ.get("WATCHER_CTL_ARGV0") or sys.argv[0]
    err(f"usage: {argv0} {{start|stop|status|restart}} [targets]  (targets 省略時は configs から自動発見)")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
