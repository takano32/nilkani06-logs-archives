#!/usr/bin/env python3
"""JavaScript の値の扱いの写し（watcher.py と targets/*.py が使う）。

watcher は 2026-11-21 に watcher.js（Bun）から Python へ書き直した。記録（logs/watcher-*.jsonl）、
Discord へ出す本文、動作ログ（logs/watcher.log）は、ほかの道具（wake-record.py、status.py、wake-triage.py）と
人が読むので、旧版と1字まで同じ形にしてある。そのために要る JavaScript の決まりを、ここにまとめた。

  - 数を文字にする形（12.0 でなく 12、1e-7、1e+21）と JSON.stringify の形（区切りに空白なし、数字のキーが先）
  - Math.round（0.5 は常に上へ）と toFixed
  - 文字列の長さと切り出しは UTF-16 の単位（絵文字は2つぶん）
  - 真偽の判定（0、空文字、null、undefined、NaN が偽。空の配列と空のオブジェクトは真）
  - Date.parse と toISOString、trim が落とす空白、Number() の読み方

依存は標準ライブラリだけ。入出力はしない。確かめは `python3 site-python/_jscompat.py --self-test`（リポジトリ直下で）。
"""
from __future__ import annotations

import calendar
import json
import math
import re
import time
from decimal import ROUND_HALF_UP, Decimal


class _Undefined:
    """JavaScript の undefined（キーが無い、を null と分けたい所でだけ使う）。"""

    __slots__ = ()

    def __repr__(self) -> str:
        return "undefined"

    def __bool__(self) -> bool:
        return False


UNDEFINED = _Undefined()
NAN = float("nan")

# trim() と正規表現の \s が空白として扱う文字（ECMAScript の WhiteSpace と LineTerminator）。
# Python の str.strip() と \s は U+001C〜001F と U+0085 も空白に数え、U+FEFF を数えないので、そのままは使えない。
JS_WS = "\t\n\v\f\r                  　﻿"
# 正規表現の中で \s の代わりに置く文字クラス。
RE_WS = "[\\t\\n\\v\\f\\r \\u00a0\\u1680\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000\\ufeff]"
# 正規表現の . の代わり（JavaScript の . は \n \r U+2028 U+2029 に当たらない。Python の . は \n だけ）。
RE_DOT = "[^\\n\\r\\u2028\\u2029]"


def truthy(v: object) -> bool:
    """`if (v)` と同じ判定。"""
    if v is None or v is UNDEFINED or v is False:
        return False
    if v is True:
        return True
    if isinstance(v, (int, float)):
        return not (v == 0 or v != v)
    if isinstance(v, str):
        return v != ""
    return True


def oror(*vals: object) -> object:
    """`a || b || c`。"""
    v: object = None
    for v in vals:
        if truthy(v):
            return v
    return v


def nullish(v: object, default: object) -> object:
    """`v ?? default`。"""
    return default if v is None or v is UNDEFINED else v


def is_num(v: object) -> bool:
    """`typeof v === "number"`。"""
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def is_finite(v: object) -> bool:
    """`Number.isFinite(v)`。"""
    return is_num(v) and not (v != v or v in (math.inf, -math.inf))


def orn(v: object) -> object:
    """`v || null`。"""
    return v if truthy(v) else None


def map_key(v: object) -> object:
    """Set や Map の鍵としての同じさ（文字列は文字列どうし、数は数どうし。1 と "1" と true は別物）。

    Python の dict は 1 と 1.0 と True を同じ鍵として扱うので、型ごとに分けた鍵に直す。
    オブジェクトや配列は「その物そのもの」で比べる（中身が同じでも別物）。
    """
    if isinstance(v, str):
        return v
    if isinstance(v, bool):
        return ("bool", v)
    if isinstance(v, (int, float)):
        return ("num", float(v))
    if v is None or v is UNDEFINED:
        return ("nil", repr(v))
    return ("obj", id(v))


def lt(a: object, b: object) -> bool:
    """`a < b`（数と文字列が混じっても比べられる。JavaScript と同じく、片方が数なら両方を数にして比べる）。"""
    if isinstance(a, str) and isinstance(b, str):
        return a < b
    x, y = js_number(a), js_number(b)
    return x < y


def get(obj: object, *keys: str) -> object:
    """`obj?.a?.b`（途中がオブジェクトでなければ None）。"""
    for k in keys:
        if isinstance(obj, dict):
            obj = obj.get(k)
        else:
            return None
    return obj


# --- 数 ---------------------------------------------------------------------------------------------------

def num_str(x: float | int) -> str:
    """Number を文字にする（`String(x)`、テンプレートの `${x}`、JSON.stringify の数）。"""
    if isinstance(x, bool):
        return "true" if x else "false"
    if isinstance(x, int):
        if -(2 ** 53) <= x <= 2 ** 53:
            return str(x)
        x = float(x)
    if x != x:
        return "NaN"
    if x == math.inf:
        return "Infinity"
    if x == -math.inf:
        return "-Infinity"
    if x == 0:
        return "0"
    sign = "-" if x < 0 else ""
    r = repr(abs(x))  # 元の値に戻せる最短の桁（JavaScript と同じ選び方）
    mant, _, exp = r.partition("e")
    e10 = int(exp) if exp else 0
    ip, _, fp = mant.partition(".")
    e10 -= len(fp)
    digits = (ip + fp).lstrip("0")
    stripped = digits.rstrip("0")
    e10 += len(digits) - len(stripped)
    digits = stripped
    k = len(digits)
    n = k + e10
    if k <= n <= 21:
        return sign + digits + "0" * (n - k)
    if 0 < n <= 21:
        return sign + digits[:n] + "." + digits[n:]
    if -6 < n <= 0:
        return sign + "0." + "0" * (-n) + digits
    e = n - 1
    es = ("+" if e >= 0 else "-") + str(abs(e))
    if k == 1:
        return sign + digits + "e" + es
    return sign + digits[0] + "." + digits[1:] + "e" + es


def js_round(x: float | int) -> float | int:
    """`Math.round(x)`（0.5 は常に正の無限大の側へ。Python の round は偶数へ寄せる）。"""
    if isinstance(x, int):
        return x
    if x != x or x in (math.inf, -math.inf):
        return x
    f = math.floor(x)
    return f + 1 if x - f >= 0.5 else f


def round1(x: float | int) -> float | int:
    """`Math.round(x * 10) / 10`。"""
    r = js_round(x * 10)
    return r / 10 if is_finite(r) else r


def to_fixed(x: float | int, digits: int) -> str:
    """`x.toFixed(digits)`。"""
    x = float(x)
    if x != x:
        return "NaN"
    if abs(x) >= 1e21:
        return num_str(x)
    if x == 0:
        x = 0.0
    d = Decimal(x).quantize(Decimal(1).scaleb(-digits), rounding=ROUND_HALF_UP)
    return format(d, "f")


_NUM_RE = re.compile(r"[+-]?(?:[0-9]+\.?[0-9]*(?:[eE][+-]?[0-9]+)?|\.[0-9]+(?:[eE][+-]?[0-9]+)?)\Z")


def js_number(v: object) -> float | int:
    """`Number(v)`。"""
    if v is None:
        return 0
    if v is UNDEFINED:
        return NAN
    if v is True:
        return 1
    if v is False:
        return 0
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, str):
        s = v.strip(JS_WS)
        if s == "":
            return 0
        if _NUM_RE.match(s):
            f = float(s)
            return int(f) if f == int(f) and abs(f) <= 2 ** 53 and "." not in s and "e" not in s.lower() else f
        if s in ("Infinity", "+Infinity"):
            return math.inf
        if s == "-Infinity":
            return -math.inf
        m = re.match(r"0([xXoObB])([0-9a-fA-F]+)\Z", s)
        if m:
            base = {"x": 16, "o": 8, "b": 2}[m.group(1).lower()]
            try:
                return int(m.group(2), base)
            except ValueError:
                return NAN
        return NAN
    if isinstance(v, (list, tuple)):
        return js_number(js_str(v))
    return NAN


def is_integer(v: object) -> bool:
    """`Number.isInteger(v)`。"""
    return is_finite(v) and float(v) == math.floor(v)


def at_least(minimum: float | int, v: object) -> float | int:
    """`Math.max(minimum, v)`。v が数として読めないときは minimum（旧版は NaN になり、間隔が 0 に落ちていた）。"""
    n = js_number(v)
    return max(minimum, n) if is_finite(n) else minimum


# --- 文字列 -----------------------------------------------------------------------------------------------

def js_str(v: object) -> str:
    """`String(v)`（テンプレートの `${v}` も同じ）。"""
    if isinstance(v, str):
        return v
    if v is None:
        return "null"
    if v is UNDEFINED:
        return "undefined"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, (int, float)):
        return num_str(v)
    if isinstance(v, (list, tuple)):
        return ",".join("" if (x is None or x is UNDEFINED) else js_str(x) for x in v)
    if isinstance(v, dict):
        return "[object Object]"
    return str(v)


def js_trim(s: str) -> str:
    """`s.trim()`。"""
    return s.strip(JS_WS)


def u16len(s: str) -> int:
    """`s.length`（UTF-16 の単位。BMP の外の文字は2つぶん）。"""
    if s.isascii():
        return len(s)
    return len(s) + sum(1 for c in s if ord(c) > 0xFFFF)


def u16slice(s: str, start: int = 0, end: int | None = None) -> str:
    """`s.slice(start, end)`（UTF-16 の単位で切る。サロゲートの対の途中で切れることもあり、それも旧版と同じ）。"""
    if s.isascii() or max(s) <= "￿":
        return s[start:end]
    b = s.encode("utf-16-le", "surrogatepass")
    n = len(b) // 2

    def clamp(i: int) -> int:
        return max(n + i, 0) if i < 0 else min(i, n)

    i = clamp(start)
    j = n if end is None else clamp(end)
    if j <= i:
        return ""
    return b[2 * i:2 * j].decode("utf-16-le", "surrogatepass")


_SURROGATE_RE = re.compile("[\ud800-\udfff]")


def encode_utf8(s: str) -> bytes:
    """ファイルや stdout へ書くときの UTF-8（対になっていないサロゲートは U+FFFD にする＝Bun の書き出しと同じ）。"""
    try:
        return s.encode("utf-8")
    except UnicodeEncodeError:
        return _SURROGATE_RE.sub("�", s).encode("utf-8")


# --- JSON -------------------------------------------------------------------------------------------------
_ESC_RE = re.compile('["\\\\\x00-\x1f\ud800-\udfff]')
_ESC_MAP = {'"': '\\"', "\\": "\\\\", "\b": "\\b", "\f": "\\f", "\n": "\\n", "\r": "\\r", "\t": "\\t"}


def _esc(m: re.Match) -> str:
    c = m.group()
    return _ESC_MAP.get(c) or "\\u%04x" % ord(c)


def _quote(s: str) -> str:
    return '"' + _ESC_RE.sub(_esc, s) + '"'


def _is_index_key(k: str) -> bool:
    # 配列の添字として読める文字列（"0"、"12"）。JavaScript のオブジェクトは、こういうキーを数の小さい順に先頭へ置く。
    return k.isascii() and k.isdigit() and (k == "0" or k[0] != "0") and int(k) < 4294967295


def _ordered_items(d: dict) -> list:
    idx = [k for k in d if isinstance(k, str) and _is_index_key(k)]
    if not idx:
        return list(d.items())
    idx.sort(key=int)
    seen = set(idx)
    return [(k, d[k]) for k in idx] + [(k, v) for k, v in d.items() if k not in seen]


def json_dumps(v: object) -> str:
    """`JSON.stringify(v)`（区切りに空白を入れない。NaN と無限大は null。undefined のキーは出さない）。"""
    if v is None or v is UNDEFINED:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, str):
        return _quote(v)
    if isinstance(v, (int, float)):
        return num_str(v) if is_finite(v) else "null"
    if isinstance(v, (list, tuple)):
        return "[" + ",".join(json_dumps(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ",".join(_quote(js_str(k)) + ":" + json_dumps(x) for k, x in _ordered_items(v) if x is not UNDEFINED) + "}"
    return _quote(str(v))


def _parse_int(s: str) -> int | float:
    n = int(s)
    return n if -(2 ** 53) <= n <= 2 ** 53 else float(s)  # 大きい整数は、JavaScript と同じく倍精度に丸める


def _bad_constant(name: str) -> object:
    raise ValueError(f"JSON に無い値: {name}")


def _pairs(pairs: list) -> dict:
    d = dict(pairs)
    return dict(_ordered_items(d)) if any(_is_index_key(k) for k in d) else d


def json_loads(s: str) -> object:
    """`JSON.parse(s)`（読めなければ ValueError）。"""
    if not isinstance(s, str):
        raise ValueError("JSON の入力が文字列でない")
    try:
        return json.loads(s, parse_int=_parse_int, parse_constant=_bad_constant, object_pairs_hook=_pairs)
    except RecursionError as e:
        raise ValueError(str(e)) from e


# --- 時刻 -------------------------------------------------------------------------------------------------

def now_ms() -> int:
    """`Date.now()`。"""
    return time.time_ns() // 1_000_000


def iso(ms: float | int) -> str:
    """`new Date(ms).toISOString()`。"""
    ms = int(math.floor(ms)) if not isinstance(ms, int) else ms
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(ms // 1000)) + ".%03dZ" % (ms % 1000)


_ISO_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?)?"
    r"\s*(Z|z|[+-][0-9]{2}:?[0-9]{2})?\Z"
)
_SLASH_RE = re.compile(r"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})(?: ([0-9]{1,2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?)?\Z")


def date_parse(s: object) -> float | int:
    """`Date.parse(s)`（ミリ秒。読めなければ NaN）。

    読めるのは、この watcher が受け取る形だけ＝ISO 8601（`2026-11-21T12:16:16.325Z`、`+09:00` つき、日付だけ）と
    `2026/11/21 12:16:16`。時差の無い日時は、JavaScript と同じくその箱の地方時として読む。
    """
    if not isinstance(s, str):
        return NAN
    s = s.strip(JS_WS)
    m = _ISO_RE.match(s)
    slash = None if m else _SLASH_RE.match(s)
    if not m and not slash:
        return NAN
    g = (m or slash).groups()
    y, mo, d = int(g[0]), int(g[1]), int(g[2])
    hh, mi, ss = int(g[3] or 0), int(g[4] or 0), int(g[5] or 0)
    ms = int((g[6] or "0")[:3].ljust(3, "0"))
    tz = g[7] if m else None
    date_only = g[3] is None
    if not (1 <= mo <= 12 and 1 <= d <= calendar.monthrange(y, mo)[1]):
        return NAN
    if hh > 24 or mi > 59 or ss > 59 or (hh == 24 and (mi or ss or ms)):
        return NAN
    days = calendar.timegm((y, mo, d, 0, 0, 0))
    sec = days + hh * 3600 + mi * 60 + ss
    if tz is None and not (m and date_only):
        # 時差の指定が無い日時＝地方時（日付だけの ISO は UTC）
        lt = time.localtime(sec)
        off = calendar.timegm(lt[:6]) - sec
        lt2 = time.localtime(sec - off)
        off = calendar.timegm(lt2[:6]) - (sec - off)
        sec -= off
    elif tz not in (None, "Z", "z"):
        sign = -1 if tz[0] == "-" else 1
        digits = tz[1:].replace(":", "")
        sec -= sign * (int(digits[:2]) * 3600 + int(digits[2:]) * 60)
    return sec * 1000 + ms


# --- 並べ替え（日本語の地名）-----------------------------------------------------------------------------------

def ja_key(s: str) -> tuple:
    """`a.localeCompare(b, "ja")` の代わりに使う並べ替えの鍵。

    旧版は ICU の日本語の照合順で地域名を並べていた。標準ライブラリに ICU は無いので、JIS X 0208 の区点の順で比べる。
    ICU の日本語の照合順は、JIS X 0208 の漢字をその区点の順に並べている（第1水準、第2水準の順）ので、
    漢字どうしの順は同じになる（2026-11-21 に JIS X 0208 の漢字6,355字と、漢字だけの地名3,000件を bun の並びと突き合わせて全部一致）。
    かな、英数字、記号が絡む順は ICU と違うことがある（ICU は ひらがな と カタカナ を同じ字として扱い、濁点を後から比べる）。
    JIS X 0208 に無い字は、漢字より後ろにコードポイントの順で置く。
    """
    out = []
    for c in s:
        try:
            b = c.encode("euc_jp")
            out.append((0, int.from_bytes(b, "big") if len(b) > 1 else b[0]))
        except UnicodeEncodeError:
            out.append((1, ord(c)))
    return tuple(out)


# --- 自己検査 ---------------------------------------------------------------------------------------------

def _self_test() -> int:
    """旧版の実行系（bun 1.4.4）の出力を写した例を、同じ値になるか確かめる。

    書き直しのとき（2026-11-21）は、これとは別に、乱数で作った値およそ12万件を bun と Python の両方に通して
    全部が同じ結果になるのを確かめた（数を文字にする形、Math.round、toFixed、文字列の長さと切り出しと trim、
    JSON の文字列、Number()、JIS X 0208 の漢字6,355字と漢字の地名3,000件の並び順）。
    """
    ng = 0

    def check(label: str, got: object, want: object) -> None:
        nonlocal ng
        if got != want:
            ng += 1
            print(f"NG {label}: {got!r} != {want!r}")

    # 手で確かめた例（bun 1.4.4 の出力を写した）
    for x, w in ((0.1 + 0.2, "0.30000000000000004"), (1e21, "1e+21"), (1e-7, "1e-7"), (123456789012345680000.0, "123456789012345680000"),
                 (0.000001, "0.000001"), (1.0, "1"), (-0.0, "0"), (5e-324, "5e-324"), (1.7976931348623157e308, "1.7976931348623157e+308"),
                 (25.0, "25"), (2 ** 53, "9007199254740992"), (-1e-7, "-1e-7"), (1.5, "1.5"), (float("nan"), "NaN")):
        check(f"num_str({x!r})", num_str(x), w)
    for x, w in ((0.5, 1), (1.5, 2), (2.5, 3), (-0.5, 0), (-1.5, -1), (-2.5, -2), (0.49999999999999994, 0), (2.4999999, 2)):
        check(f"js_round({x!r})", js_round(x), w)
    for (x, d), w in (((0.25, 1), "0.3"), ((0.35, 1), "0.3"), ((2.5, 0), "3"), ((1.005, 2), "1.00"), ((12.34, 1), "12.3")):
        check(f"to_fixed({x!r},{d})", to_fixed(x, d), w)
    for s, w in (("2026-11-21T12:16:16.325Z", 1795263376325), ("2026-11-21T12:16:16.3256Z", 1795263376325),
                 ("2026-11-21T12:16:16.32Z", 1795263376320), ("2026-11-21T12:16:16+09:00", 1795230976000),
                 ("2026-11-21T12:16:16.829+09:00", 1795230976829), ("2026-11-21", 1795219200000),
                 ("2026-11-21T12:16Z", 1795263360000), ("2026-11-21T12:16:16-0500", 1795281376000),
                 ("2026-11-21T24:00:00Z", 1795305600000)):
        check(f"date_parse({s!r})", date_parse(s), w)
    for s in ("garbage", "", "20261121T121616Z", "2026-13-01T00:00:00Z", None, 12345):
        check(f"date_parse({s!r}) は NaN", date_parse(s) != date_parse(s), True)
    check("iso", iso(1795263376325), "2026-11-21T12:16:16.325Z")
    check("json", json_dumps({"b": 1, "10": [1.0, None, UNDEFINED, "é\n\x01 "], "2": {"x": UNDEFINED, "y": float("nan")}, "s": "a\ud83dz"}),
          '{"2":{"y":null},"10":[1,null,null,"é\\n\\u0001 "],"b":1,"s":"a\\ud83dz"}')
    check("loads", json_dumps(json_loads('{"z":1,"10":2,"2":3,"big":1509823187293048884,"f":1.0,"e":1e2}')),
          '{"2":3,"10":2,"z":1,"big":1509823187293048800,"f":1,"e":100}')
    check("u16len", u16len("a😀b"), 4)
    check("u16slice", u16slice("a😀b", 0, 2), "a\ud83d")
    check("u16slice 負", u16slice("a😀b", -2), "\ude00b")
    check("encode", encode_utf8("a\ud83dz"), "a�z".encode())
    check("js_str", " ".join(js_str(x) for x in (1, 2.5, None, UNDEFINED, True, [1, [2, 3], None], {"a": 1})),
          "1 2.5 null undefined true 1,2,3, [object Object]")
    for v, w in ((None, 0), ("", 0), (" 12 ", 12), ("0x10", 16), ("1e3", 1000), (True, 1), ([], 0), ([5], 5), (".5", 0.5), ("5.", 5)):
        check(f"js_number({v!r})", js_number(v), w)
    for v in (UNDEFINED, "12px", {}, "１２"):
        check(f"js_number({v!r}) は NaN", js_number(v) != js_number(v), True)
    check("truthy", [truthy(x) for x in (0, "", None, UNDEFINED, float("nan"), False, [], {}, "0", 1, -1)],
          [False, False, False, False, False, False, True, True, True, True, True])

    print(f"{'すべて通過' if ng == 0 else f'{ng} 件 失敗'}")
    return 1 if ng else 0


if __name__ == "__main__":
    import sys

    if "--self-test" in sys.argv:
        raise SystemExit(_self_test())
    print(__doc__)
