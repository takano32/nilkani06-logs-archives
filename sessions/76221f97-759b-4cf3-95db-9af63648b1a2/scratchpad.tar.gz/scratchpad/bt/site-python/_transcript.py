#!/usr/bin/env python3
"""本流（claude）の transcript（JSONL）の読み方（targets の noresponse・noauth・dream・trend-digest が共通で使う）。

旧版は対象ごとに同じ読み方を書いていた（「片方だけ壊れることがない」ように手でそろえていた）。
Python へ書き直すとき、ここ1か所にまとめた。読み方そのものは旧版のまま。
"""
from __future__ import annotations

import os

from _jscompat import date_parse, get, iso, js_number, js_str, js_trim, json_loads, truthy, u16len
from _runtime import APP_ROOT


def default_dir() -> str:
    """Claude Code の transcript 置き場。ディレクトリ名は cwd のパスの "/" を "-" に置換したもの。"""
    slug = (APP_ROOT[:-1] if APP_ROOT.endswith("/") else APP_ROOT).replace("/", "-")
    return f"{os.path.expanduser('~')}/.claude/projects/{slug}"


def transcript_dir(explicit: object) -> str:
    """conf の transcript_dir があればそれ、無ければ既定の置き場。"""
    return js_str(explicit) if truthy(explicit) else default_dir()


class Newest:
    """いちばん新しい transcript。mtime_ms は旧版の mtimeMs と同じミリ秒（小数つき）。"""

    def __init__(self, path: str, name: str, mtime_ms: float, size: int) -> None:
        self.path = path
        self.name = name
        self.mtime_ms = mtime_ms
        self.size = size


def newest(dir_: str, files_only: bool = False) -> Newest | None:
    """現セッション＝ディレクトリ直下で最も新しい *.jsonl。無ければ None。

    ・圧縮済み（*.jsonl.gz）は過去ぶんなので拾わない
    ・サブディレクトリ（<セッションID>/subagents/…）は降りない＝委譲先の transcript を混ぜない
    files_only=True は、名前が .jsonl で終わるディレクトリを除く（noresponse・noauth の読み方）。
    ディレクトリが読めないときの OSError は呼び手へ返す（握るかどうかは対象ごとに違う）。
    """
    if not os.path.exists(dir_):
        return None
    best: Newest | None = None
    for name in os.listdir(dir_):
        if not name.endswith(".jsonl"):
            continue
        try:
            st = os.stat(f"{dir_}/{name}")
        except OSError:
            continue
        if files_only and not os.path.isfile(f"{dir_}/{name}"):
            continue
        t = st.st_mtime_ns / 1e6
        if best is None or t > best.mtime_ms:
            best = Newest(f"{dir_}/{name}", name, t, st.st_size)
    return best


def read_tail(path: str, max_bytes: object) -> str:
    """末尾 max_bytes だけ読む。切れた先頭行は捨てる（途中から読むと 1 行目は必ず断片）。"""
    with open(path, "rb") as f:
        size = os.fstat(f.fileno()).st_size
        limit = js_number(max_bytes)
        start = max(0, size - int(limit)) if limit == limit else 0
        n = size - start
        if n <= 0:
            return ""
        f.seek(start)
        s = f.read(n).decode("utf-8", "replace")
    if start > 0:
        nl = s.find("\n")
        s = s[nl + 1:] if nl >= 0 else ""
    return s


def read_from(path: str, offset: int) -> str:
    """offset バイトめから末尾までを読む（注入のあとに追記されたぶんを見るのに使う）。"""
    with open(path, "rb") as f:
        f.seek(offset)
        return f.read().decode("utf-8", "replace")


def parse_records(chunk: str) -> list[dict]:
    out = []
    for line in chunk.split("\n"):
        s = js_trim(line)
        if not s.startswith("{"):
            continue
        try:
            d = json_loads(s)
        except ValueError:
            continue
        if isinstance(d, dict):
            out.append(d)
    return out


def text_blocks(d: dict) -> list:
    c = get(d, "message", "content")
    if isinstance(c, str):
        return [c]
    if not isinstance(c, list):
        return []
    return [(x.get("text") if truthy(x.get("text")) else "") for x in c if isinstance(x, dict) and x.get("type") == "text"]


def has_block(d: dict, type_: str) -> bool:
    c = get(d, "message", "content")
    return isinstance(c, list) and any(isinstance(x, dict) and x.get("type") == type_ for x in c)


def joined_text(d: dict, sep: str = "") -> str:
    return sep.join(js_str(t) for t in text_blocks(d))


def incoming_prompt(d: dict) -> dict | None:
    """「届いた呼びかけ」＝ツール結果でない user レコード。Discord のメッセージ・夢の起床文・
    サブエージェントの完了通知がここに入る（どれも「返事を待っている入力」）。"""
    if d.get("type") != "user" or d.get("isSidechain") is True:
        return None
    if truthy(d.get("isCompactSummary")):
        return None
    if "toolUseResult" in d:
        return None  # ツール結果は呼びかけではない
    if has_block(d, "tool_result"):
        return None
    text = js_trim(joined_text(d))
    if not text:
        return None
    if text.startswith("<channel "):
        kind = "channel"  # Discord から届いた本物の呼びかけ
    elif text.startswith("<task-notification"):
        kind = "task"  # 委譲先の完了通知
    else:
        kind = "local"  # 夢の起床文・手元からの入力
    ts = d.get("timestamp")
    return {"kind": kind, "ts": ts if truthy(ts) else None, "chars": u16len(text)}


def has_wake_turn(chunk: str, needle: str) -> bool:
    """追記されたぶんの transcript に「起床文で始まる本物の user ターン」があるか。

    素のバイト検索だと偽陽性が出る（2026-07-25 に実地で踏んだ）。コンパクション要約は直前の会話を
    引用するので、起床文そのものが要約本文の中に現れる。それは type:"user" のレコードとして書かれる
    ため、単純な部分一致では「起きた」と誤判定しうる。だから3つ全部を満たすものだけを数える：
      1) type が "user"（assistant の言及や note では駄目）
      2) isCompactSummary でない（要約は過去の引用であって、いま起きた証拠ではない）
      3) 本文が起床文で**始まる**（含むではなく先頭一致。引用は必ず前置きを伴う）
    """
    for d in parse_records(chunk):
        if d.get("type") != "user" or truthy(d.get("isCompactSummary")):
            continue
        if js_trim(joined_text(d)).startswith(needle):
            return True
    return False


def jst_hm(ts: object) -> str:
    """UTC の時刻（ISO 8601）を、人に見せる JST の `HH:MM JST` にする。読めなければ "?"。"""
    if not truthy(ts):
        return "?"
    d = date_parse(ts)
    if d != d:
        return "?"
    return iso(d + 9 * 3600 * 1000)[11:16] + " JST"
