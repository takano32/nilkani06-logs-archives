#!/usr/bin/env python3
"""OAuth 1.0a (HMAC-SHA1) 署名と必須環境変数の確認の共通モジュール（Python 標準ライブラリのみ）。

X (Twitter) v2 投稿・はてな各 API（AtomPub / Bookmark REST / OAuth setup）など、
OAuth 1.0a を使うスクリプトで重複していた「署名生成・パーセントエンコード・必須 env の確認」を
1 箇所に集約する。外部依存なし（urllib + hmac + hashlib + base64 + secrets）。

設計メモ:
  - 署名ロジックは旧 oauth.oauth1_header / twitter.post._oauth_header から
    verbatim 抽出している（リファクタ前後で同一署名になることを確認済み）。
  - twitter.post は params=[] / token 必須の特殊形として、この共通実装を呼ぶ。
  - 鍵は環境変数だけから読む。`.env` は開かない（2026-11-22 takano32 指示・管理チャンネル
    「直接 .env を読むのは密結合でよくないからぜんぶ辞めましょう」）。環境に入れるのは systemd の
    EnvironmentFile と loop.bash の load_env の仕事で、claude の子はそれを継ぐ。
"""
import os
import time
import hmac
import hashlib
import base64
import secrets
import sys
import urllib.parse

def need_env(*names: str) -> list[str]:
    """必須の環境変数をまとめて確かめ、値を順に返す。欠けていれば名前だけ並べて sys.exit する（値は出さない）。"""
    missing = [k for k in names if not os.environ.get(k)]
    if missing:
        sys.exit(f"環境変数 {', '.join(missing)} が無い（.env に置いて /quit で反映）。値は出力しません。")
    return [os.environ[k] for k in names]


def q(s: object) -> str:
    """OAuth 用パーセントエンコード（'/' も含め全部）。"""
    return urllib.parse.quote(str(s), safe="")


def oauth1_header(method: str, url: str, params: list[tuple[str, str]],
                  consumer_key: str, consumer_secret: str,
                  token: str | None = None, token_secret: str = "",
                  extra_oauth: dict[str, str] | None = None) -> str:
    """OAuth 1.0a (HMAC-SHA1) の Authorization ヘッダを生成する。

    params: [(key, value), ...]
      - フォーム POST / クエリのパラメータは署名対象に含める（はてブの追加など）。
      - application/atom+xml や JSON ボディは含めない → params=[] を渡す（ブログ投稿・X v2 投稿など）。
    extra_oauth: oauth_callback / oauth_verifier 等を足したいとき。
    """
    oauth = {
        "oauth_consumer_key": consumer_key,
        "oauth_nonce": secrets.token_hex(16),
        "oauth_signature_method": "HMAC-SHA1",
        "oauth_timestamp": str(int(time.time())),
        "oauth_version": "1.0",
    }
    if token:
        oauth["oauth_token"] = token
    if extra_oauth:
        oauth.update(extra_oauth)

    # RFC 5849 §3.4.1: 署名ベース文字列の URI は query を含めない。URL に query が
    # 付いていたら、そのパラメータは正規化パラメータ（§3.4.1.3）へ合流させる。
    # これを怠ると query 付き URL（例: はてな AtomPub のページング atom/entry?page=N）で
    # 署名不一致の 401 になる（query 無しの URL では従来と完全に同一の署名）。
    split = urllib.parse.urlsplit(url)
    base_url = urllib.parse.urlunsplit((split.scheme, split.netloc, split.path, "", ""))
    query_params = urllib.parse.parse_qsl(split.query, keep_blank_values=True)
    all_params = [(k, v) for k, v in oauth.items()] + list(params) + query_params
    encoded = sorted((q(k), q(v)) for k, v in all_params)
    param_str = "&".join(f"{k}={v}" for k, v in encoded)
    base = "&".join([method.upper(), q(base_url), q(param_str)])
    key = f"{q(consumer_secret)}&{q(token_secret)}"
    oauth["oauth_signature"] = base64.b64encode(
        hmac.new(key.encode(), base.encode(), hashlib.sha1).digest()
    ).decode()
    return "OAuth " + ", ".join(f'{q(k)}="{q(v)}"' for k, v in sorted(oauth.items()))
