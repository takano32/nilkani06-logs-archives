"""transcript（`~/.claude/projects/<proj>/*.jsonl`）を読む側の共通部品。

**なぜ共有にしたか**＝`*.jsonl` だけを glob している読み手が複数ある
（いまは `log/build_json.py` の backfill と `scripts/announce-gap-recompute.py` の2本。
**3本目だった `scripts/canary-count.py` は 2026-08-18 にカナリアごと廃止**）。
退避で `.gz` にした瞬間、これらは**黙って対象を落とす**——エラーも警告も出ず、ただ分母が小さくなる。
静かに壊れる形なので、開き方と集め方を1箇所に寄せた。

依存は標準ライブラリのみ（`glob` / `gzip` / `os`）。

**watcher の `_transcript.py` とは別のまま置いている**（2026-11-21 に `.agents/skills/lib/transcripts.py` から移したとき）。
あちらは今のセッションの `.jsonl` だけを見て `.gz` をわざと拾わず、watcher の `_jscompat`・`_runtime` を読み込む。
こちらは過去ぶんの `.gz` まで集めるのが役目。重なる関数が無く、まとめるとセッションログの書き出しが
watcher の下回り（asyncio、HTTP）に依存する。
"""

import glob
import gzip
import os


def transcript_paths(proj_dir: str, newest_first: bool = False) -> list[str]:
    """生（`.jsonl`）と退避済み（`.jsonl.gz`）の両方を集めて返す。

    `glob("*.jsonl")` は `.jsonl.gz` に当たらない（末尾一致）ので二重には拾わない。
    `newest_first=True` で mtime の新しい順（backfill が使う順序）。
    """
    paths = glob.glob(os.path.join(proj_dir, "*.jsonl")) + \
        glob.glob(os.path.join(proj_dir, "*.jsonl.gz"))
    if newest_first:
        paths.sort(key=os.path.getmtime, reverse=True)
    else:
        paths.sort()
    return paths


def open_transcript(path: str, errors: str = "strict"):
    """transcript を text mode で開く（`.gz` は透過的に解く）。

    `errors` は呼ぶ側の従来の挙動をそのまま渡せるように残してある
    （build_json は壊れた1バイトで全体を落とさないため "replace"）。
    """
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors=errors)
    return open(path, encoding="utf-8", errors=errors)
