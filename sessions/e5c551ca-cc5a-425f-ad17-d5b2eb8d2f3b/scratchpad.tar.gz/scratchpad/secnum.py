"""Remove section numbers from headings and rewrite §N refs to heading names.
usage:
  secnum.py map                 -> writes MAP json (from current tree; run once before edits)
  secnum.py run [--apply] FILES -> rewrite given files using MAP; prints log
"""
import json, os, re, sys, subprocess
ROOT = '/home/takano32/nilkani06'
SP = os.path.dirname(os.path.abspath(__file__))
MAPF = SP + '/secmap.json'
HEAD = re.compile(r'^(#{1,6}\s+)(?:第\s*|§\s*)?(\d+(?:\.\d+)*[a-z]?(?:-[\da-z]+)?|\([a-z]\))(?:([\.．、）)]|節)(?:\s+|(?=[^\x00-\x7f]))|(?<=[\da-z\)])\s+(?=\S))(.*)$')

def scope_files():
    out = subprocess.run(['git', '-C', ROOT, 'ls-files'], capture_output=True, text=True).stdout.split('\n')
    res = []
    for f in out:
        if not f: continue
        if f.startswith(('skills/vendor/','skills/japanese/references/','skills/japanese/upstream/')) or f in ('skills/japanese/stop-ai-slop-jp.md','skills/prompt-audit/2026-09-26.md'): continue
        if not (f.startswith(('skills/', '.claude/', 'scripts/', 'site-python/')) or f in ('AGENTS.md',) or (f.endswith('.bash') and '/' not in f)):
            continue
        res.append(f)
    return res

def headings(path):
    r = subprocess.run(['git', '-C', ROOT, 'show', '632861c8:' + path], capture_output=True, text=True)
    if r.returncode: return {}
    L = r.stdout.split('\n')
    inc = False; m_ = {}; parent = None
    for i, l in enumerate(L):
        if l.startswith('```') or l.startswith('~~~'): inc = not inc; continue
        if inc: continue
        m = HEAD.match(l)
        if m and not m.group(4).startswith('の'):
            num = m.group(2); sep = m.group(3)
            if num.startswith('('):
                if parent: m_.setdefault(parent + '-' + num[1], (m.group(4).strip(), i + 1))
                continue
            if sep is None and '.' not in num and '-' not in num and '§' not in l[:12]: continue  # "## 3 つの" style
            m_.setdefault(num, (m.group(4).strip(), i + 1))
            if '-' not in num and '.' not in num: parent = num
    return m_

def short(title):
    t = title.strip().rstrip('。')
    for cut in ['（', '(', '＝', ' — ', '——', '：']:
        k = t.find(cut)
        if k >= 2: t = t[:k]
    t = t.strip().replace('**', '')
    t = t.replace('「', '『').replace('」', '』')
    return t

ALIAS = {}
def build_alias(files):
    for f in files:
        if f.startswith('.claude/skills/') and f.endswith('/SKILL.md'):
            d = f.split('/')[2]
            for a in {d, d.replace('nilkani06-', ''), '.claude/skills/' + d}:
                ALIAS[a] = f
            ALIAS[d + '/SKILL.md'] = f
    ALIAS['persona'] = '.claude/skills/nilkani06-persona-and-conversation/SKILL.md'
    ALIAS['playbook'] = '.claude/skills/nilkani06-debugging-playbook/SKILL.md'
    ALIAS['PLAN'] = 'skills/ops/herdr/PLAN.md'

def resolve(tok, cur, files):
    tok = tok.strip('`').rstrip('/')
    if not tok: return None
    if tok in ALIAS: return ALIAS[tok]
    if tok.startswith('.agents/'): tok = tok[len('.agents/'):]
    cand = [f for f in files if f == tok or f.endswith('/' + tok)]
    if tok.endswith('.md') or '/' in tok:
        d = os.path.dirname(cur)
        p = os.path.normpath(os.path.join(d, tok))
        if p in files: return p
        if len(cand) == 1: return cand[0]
        if cand:
            # prefer same top dir
            same = [c for c in cand if c.startswith(os.path.dirname(cur))]
            if len(same) == 1: return same[0]
        return 'AMBIG:' + tok if cand else 'EXT:' + tok
    if tok + '.md' and [f for f in files if f.endswith('/' + tok + '.md')]:
        c = [f for f in files if f.endswith('/' + tok + '.md')]
        if len(c) == 1: return c[0]
    return None

FALLBACK = {'skills/ops/tasks/SKILL.md': 'skills/ops/tasks/wake-measurement.md'}
REF = re.compile(r'§\s*(\d+(?:\.\d+)*[a-z]?)(?:-([\da-z]+))?(?![a-zA-Z\d])')
TOK = re.compile(r'(`?[\w\.\-/]+`?)\s?(の)?\s?$')

ONLY = None
def process(path, MAP, files, apply, log):
    full = os.path.join(ROOT, path)
    txt = open(full).read()
    is_md = path.endswith('.md')
    lines = txt.split('\n')
    # candidates.md: '# xxx.md' blocks set default target
    block_default = {}
    if path == 'skills/agents/harvest/candidates.md':
        curb = None
        for i, l in enumerate(lines):
            m = re.match(r'^# (\S+\.md)\s*$', l)
            if m: curb = 'skills/agents/' + m.group(1)
            block_default[i] = curb
    out = []; inc = False
    for i, l in enumerate(lines):
        if is_md and (l.startswith('```') or l.startswith('~~~')):
            inc = not inc; out.append(l); continue
        nl = l
        if is_md and not inc:
            m = HEAD.match(l) if ONLY is None else None
            if m and not m.group(4).startswith('の') and not (m.group(3) is None and '.' not in m.group(2) and '-' not in m.group(2) and '(' not in m.group(2) and '§' not in l[:12]):
                nl = m.group(1) + m.group(4)
                log.append(('HEAD', path, i + 1, l[:90], '=>', nl[:90]))
        # refs
        res = []; pos = 0; prev_t = None; prev_end = -10
        for m in REF.finditer(nl):
            num = m.group(1); subk = m.group(2)
            before = nl[:m.start()]
            tm = TOK.search(before)
            target = None; tok = None
            if tm:
                tok = tm.group(1)
                r = resolve(tok, path, files)
                if r: target = r
            chained = False
            if target is None and prev_t and re.fullmatch(r'\s*[・、,/／〜～と\-]\s*(?:§)?\s*', nl[prev_end:m.start()] or ' '):
                target = prev_t; chained = True
            default = block_default.get(i) or path
            explicit = target is not None
            if target is None: target = default
            if target.startswith(('EXT:', 'AMBIG:')):
                log.append(('SKIP-' + target.split(':')[0], path, i + 1, nl[max(0, m.start() - 40):m.end() + 10]))
                res.append(nl[pos:m.end()]); pos = m.end(); prev_t = None; prev_end = m.end(); continue
            if ONLY is not None and not target.startswith(ONLY):
                res.append(nl[pos:m.end()]); pos = m.end(); prev_t = target; prev_end = m.end(); continue
            hm = MAP.get(target, {})
            if num not in hm and target == path and block_default.get(i):
                # candidates: number may be candidates' own moved section
                pass
            suffix = ''
            if subk:
                if num + '-' + subk in hm: num = num + '-' + subk
                elif num in hm and subk.isdigit(): suffix = 'の' + subk
                else: num = num + '-' + subk
            fb = FALLBACK.get(path)
            if num not in hm and fb and not explicit and num in MAP.get(fb, {}):
                target = fb; hm = MAP[fb]
                if path != target: pass
            if num not in hm:
                log.append(('UNMAPPED', path, i + 1, target, num, nl[max(0, m.start() - 40):m.end() + 10]))
                res.append(nl[pos:m.end()]); pos = m.end(); prev_t = target; prev_end = m.end(); continue
            name = short(hm[num][0])
            seg = nl[pos:m.start()]
            if chained:
                rep = '「%s」' % name
            elif target != path and not (explicit and tm):
                rel = os.path.relpath(target, os.path.dirname(path)) if os.path.dirname(target) == os.path.dirname(path) else target
                rep = '`%s` の「%s」' % (rel, name)
            elif explicit and tm:
                rep = ('' if seg.rstrip().endswith('の') or not seg.strip() else 'の') + '「%s」' % name
                if seg.endswith(' ') and not seg.rstrip().endswith('の'): seg = seg  # "`x` §2" -> "`x` の「..」"
            else:
                rep = '「%s」' % name
            rep += suffix
            pre_all = ''.join(res) + seg
            if pre_all.count('「') > pre_all.count('」'):
                rep = rep.replace('「', '『').replace('」', '』')
            res.append(seg + rep)
            log.append(('REF', path, i + 1, nl[max(0, m.start() - 30):m.end() + 6], '=>', rep))
            pos = m.end(); prev_t = target; prev_end = m.end()
        res.append(nl[pos:])
        out.append(''.join(res))
    new = '\n'.join(out)
    if apply and new != txt:
        open(full, 'w').write(new)
    return new != txt

if __name__ == '__main__':
    files = scope_files()
    build_alias(files)
    if sys.argv[1] == 'map':
        MAP = {f: headings(f) for f in files if f.endswith('.md')}
        MAP = {k: v for k, v in MAP.items() if v}
        json.dump(MAP, open(MAPF, 'w'), ensure_ascii=False, indent=0)
        print(len(MAP), 'files with numbered headings')
    else:
        MAP = json.load(open(MAPF))
        apply = '--apply' in sys.argv
        for a in sys.argv:
            if a.startswith('--only='): ONLY = a[7:]
        targets = [a for a in sys.argv[2:] if not a.startswith('--')]
        log = []; changed = []
        for t in targets:
            if process(t, MAP, files, apply, log): changed.append(t)
        for x in log: print(*x, sep=' | ')
        print('CHANGED', len(changed))
