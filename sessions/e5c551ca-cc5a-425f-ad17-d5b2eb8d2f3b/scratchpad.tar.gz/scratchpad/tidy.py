"""Remove spaces around inserted 「name」/『name』 on lines that git diff shows as added. usage: tidy.py FILE..."""
import re,sys,subprocess
ROOT='/home/takano32/nilkani06'
for f in sys.argv[1:]:
    d=subprocess.run(['git','-C',ROOT,'diff','-U0','--',f],capture_output=True,text=True).stdout
    added=set(l[1:] for l in d.split('\n') if l.startswith('+') and not l.startswith('+++'))
    L=open(ROOT+'/'+f).read().split('\n'); n=0
    for i,l in enumerate(L):
        if l not in added: continue
        o=l
        l=re.sub(r'([^\x00-\x7f|｜]) ([「『][^「」『』]{1,80}[」』])', r'\1\2', l)
        l=re.sub(r'([」』]) ([^\x00-\x7f|｜])', r'\1\2', l)
        l=re.sub(r'([」』]) ([A-Z]\d?)(?=[ 「（の])', r'\1の \2', l)
        if l!=o: n+=1; L[i]=l
    open(ROOT+'/'+f,'w').write('\n'.join(L)); print(f,n)
