---
name: firewall
description: この箱のファイアウォールの正典。Oracle Cloud のセキュリティリストと、箱の中の iptables（iptables-persistent が起動時に読む /etc/iptables/rules.v4 と rules.v6）の2層を扱う。IPv6（2026-11-25 に付けた）の持ち方と戻し方も持つ。ポートを開ける・閉じるとき、外から届かない・届いてしまうとき、いま何が開いているかを知りたいとき、Docker や Caddy でサービスを外に出すとき、箱を引っ越すときに読む。開いているポートの一覧と用途、2層をセットで変える手順、netfilter-persistent save を使わない理由、Docker の公開ポートが INPUT を通らない注意、sudo と外に開ける変更の決まり、読むだけの点検スクリプト check.py を持つ。English keywords - firewall, iptables, ip6tables, IPv6, rules.v6, iptables-persistent, netfilter-persistent, rules.v4, OCI security list, ingress rules, open port, Docker published ports, DOCKER-USER, Caddy.
requires:
  - apt:iptables-persistent
  - file:/etc/iptables/rules.v4
  - cli:ss
  - cli:ip
  - cli:oci   # .local/python-packages/bin/oci（2026-11-24 から pipx の oci-cli への symlink）
---

# ファイアウォール（Oracle のセキュリティリストと箱の iptables）

外からこの箱に届くには、**2つの層を両方とも通る必要がある**。片方だけ開けても届かないし、片方だけ閉じれば止まる。
だから**開けるのも閉じるのも、必ず2層をセットで変える**。片方だけ変えると、もう片方が「たまたま」守っている状態になり、次に誰かがそちらを触ったときに意図しない穴が開く。

| 層 | どこ | 誰が読むか |
|---|---|---|
| Oracle 側 | VCN のサブネットに付いたセキュリティリスト `ampere-sl`（VNIC に NSG は付いていない） | Oracle のネットワーク。箱の外で落とす |
| 箱の中 | `/etc/iptables/rules.v4` の filter 表 INPUT | 起動時に `netfilter-persistent`（iptables-persistent）が読み込む |
| 箱の中（IPv6） | `/etc/iptables/rules.v6` の filter 表 INPUT（§9） | 同上 |

点検は `python3 skills/ops/firewall/check.py`（読むだけ。§6）。

## 1. この箱の事実（2026-11-22 に確かめた）

- Oracle Cloud の ap-tokyo-1。ホスト名 `a1-free`、内側の IP `10.0.1.102`、Ubuntu 26.04 の arm64。
- VNIC は `ocid1.vnic.oc1.ap-tokyo-1.abxhiljrsz7vqr2c2fwlcawdcheo2rs6lih25a7monzjxeodowwcy2k3ahva`。NSG は 0 個。サブネットのセキュリティリストは `ampere-sl` の1つだけ。egress は 0.0.0.0/0 の全プロトコル（触っていない）。
- 箱の中は `netfilter-persistent` が active かつ enabled。`nftables` サービスは disabled、`ufw` と `firewalld` は入っていない。iptables は nf_tables バックエンド（`iptables --version` で見る）。
- `rules.v4` は Oracle のイメージの既定に 80/443 を足したもの。INPUT は RELATED,ESTABLISHED、icmp、lo、tcp 22/80/443 を ACCEPT し、最後に `REJECT --reject-with icmp-host-prohibited`。FORWARD も最後に REJECT。
- **`InstanceServices` 鎖は Oracle のもので、触らない**（iSCSI の起動ディスク、メタデータ、DNS、NTP への道。規則のコメントに Oracle の文書を見よと書いてある）。
- 2026-11-25 から IPv6 が付いている（§9）。`rules.v6` は INPUT の既定が DROP で、v4 と同じ tcp 22/80/443 と ICMPv6 などだけを通す。それまでは全 ACCEPT の空（`:INPUT ACCEPT` だけ）だった。
- 控え: `/etc/iptables/rules.v4.bak-20261122-190158`（80/443 を足す前）。もっと古い `rules.v4.bak-20260901-231748` もある。v6 は `/etc/iptables/rules.v6.bak-20261125-054333`（閉じる前の空）。

いま効いているルール（`iptables -S`）は root でないと読めない（`Permission denied (you must be root)`）。sudo を使わない読み出しはファイルの側だけ。

## 2. 開いているポート

ポートを開け閉めしたら、**この表を同じコミットで直す**。点検スクリプトが2層の食い違いは見つけるが、「なぜ開いているか」は書いておかないと誰にも分からなくなる。

| ポート | 用途 | 開けた日 | 経緯 |
|---|---|---|---|
| tcp 22 | ssh | イメージの既定 | Oracle 側も既定で 0.0.0.0/0。IPv6（::/0）は 2026-11-25 |
| tcp 80 | HTTP。Caddy（`network_mode: host` で立てる予定）で外に出すもの。証明書の取得にも使う | 2026-11-22 | takano32 指示・管理チャンネル。Oracle 側の description は `HTTP` |
| tcp 443 | HTTPS。同上 | 2026-11-22 | 同上。description は `HTTPS` |

**IPv6 も同じポートだけを開ける**（2026-11-25 から。§9）。v4 でポートを開け閉めするときは、`rules.v6` とセキュリティリストの `::/0` の行も同じコミットで揃える。Caddy は `*:80`／`*:443` で待っているので、v6 でも届く。

UDP は1つも開けていない。待ち受けているのに閉じているもの（2026-11-22 の点検で見えたもの。どちらも外からは届かない）:

- tcp 111 と udp 111＝`rpcbind`
- tcp 5201＝`iperf3`（利用者 `iperf3`）

これらを外に出すときも、§3 の手順で2層を開けてから表に足す。

## 3. 開け方・閉じ方（2層をセットで）

**前提**: どちらの層も、**管理チャンネル（chat_id `1509823187293048884`）で takano32 に言われたときだけ**変える（§5）。

### 3-1. 箱の中（iptables）

`netfilter-persistent save` は使わない（§4）。ファイルを直接直す。

1. 控えを取る: `sudo cp -p /etc/iptables/rules.v4 /etc/iptables/rules.v4.bak-$(date -u +%Y%m%d-%H%M%S)`
2. `rules.v4` の filter 表の INPUT で、**tcp 22 の行の直後（最後の REJECT より前）** に1行足す。閉じるときはその行を消す。
   ```
   -A INPUT -p tcp -m state --state NEW -m tcp --dport <ポート> -j ACCEPT
   ```
   REJECT より後ろに足すと効かない（INPUT は上から評価され、REJECT で止まる）。
3. 文法を確かめる: `sudo iptables-restore --test /etc/iptables/rules.v4`（何も出なければよい）。
4. いま効いているほうにも同じ変更を当てる（ファイルを読み直させると Docker の鎖が消えるので、`iptables-restore` で丸ごと入れ替えない）。
   - 開ける: `sudo iptables -I INPUT 1 -p tcp -m state --state NEW -m tcp --dport <ポート> -j ACCEPT`
     （位置は REJECT より前ならどこでも効き方は同じ。2026-11-22 の 80/443 は INPUT の1番と2番に入った）
   - 閉じる: `sudo iptables -D INPUT -p tcp -m state --state NEW -m tcp --dport <ポート> -j ACCEPT`（足したときと同じ書き方で消す）
5. 確かめる: `sudo iptables -S INPUT` と `python3 skills/ops/firewall/check.py`。

### 3-2. Oracle 側（セキュリティリスト）

oci CLI は `/home/takano32/nilkani06/.local/python-packages/bin/oci`（`~/.oci/config` で認証済み。2026-11-24 から実体は `.local/pipx/venvs/oci-cli`＝`skills/ops/packages/python-packages.md` の「pipx」）。インスタンスメタデータ（169.254.169.254）は takano32 の利用者からは 403 だったので、VNIC は内側の IP から引く。

```sh
OCI=/home/takano32/nilkani06/.local/python-packages/bin/oci
VNIC=$($OCI search resource structured-search \
  --query-text "query vnic resources where privateIp = '10.0.1.102'" \
  --query 'data.items[0].identifier' --raw-output)
SUBNET=$($OCI network vnic get --vnic-id "$VNIC" --query 'data."subnet-id"' --raw-output)
SL=$($OCI network subnet get --subnet-id "$SUBNET" --query 'data."security-list-ids"[0]' --raw-output)
```

**`oci network security-list update --ingress-security-rules` は一覧ごと置き換える**（`--help` に「`ingressSecurityRules` objects you provide replace the entire existing objects」とある。セキュリティリストの規則には1件ずつの ID が無い）。渡さなかった規則は消えるので、必ず「取る→足す（消す）→全部を渡す」の順にする。

1. いまの一覧を取り、控えにする（置き場は scratchpad。リポの中に置かない）:
   `$OCI network security-list get --security-list-id "$SL" > <scratchpad>/sl-before.json`
2. `data."ingress-security-rules"` を取り出し、**JSON のキーを camelCase に直して**（`get` が返すのは `tcp-options` のような kebab-case、`update` が受けるのは `tcpOptions` のような camelCase）1件足す（閉じるなら1件消す）。足す1件の形:
   ```json
   {"protocol": "6", "source": "0.0.0.0/0", "sourceType": "CIDR_BLOCK", "isStateless": false,
    "description": "<用途>", "tcpOptions": {"destinationPortRange": {"min": <ポート>, "max": <ポート>}}}
   ```
3. 更新する。`--if-match` に、手順1の出力の `etag`（`data` と並んでいる）を渡すと、間に別の変更が入っていたら失敗してくれる:
   `$OCI network security-list update --security-list-id "$SL" --ingress-security-rules file://<scratchpad>/ingress.json --if-match <etag> --force`
4. 確かめる: もう一度 `get` して、**元からあった規則が全部残っていること**と足した1件を見る。最後に `python3 skills/ops/firewall/check.py`。

egress は触らない（全部許している）。

## 4. `netfilter-persistent save` を使わない理由

`save` は**いま効いているルールを丸ごと** `rules.v4` に書き出す。この箱では Docker が起動のたびに自分の鎖（`DOCKER`、`DOCKER-USER`、`DOCKER-FORWARD` など）と nat 表の規則を足しているので、それまで `rules.v4` に焼き込まれる。次の起動では、Docker が作る前にファイルの鎖が読み込まれるので、Docker が足すものと二重になったり、もう無いコンテナ宛ての古い規則が残ったりするおそれがある（この箱で起きたのを見たわけではなく、`save` の仕組みからの推論）。
だから、ファイルは手で直し、いま効いているほうには `iptables -I`／`-D` で同じ変更を当てる（§3-1）。

## 5. 決まり（権限）

- **`sudo` を使う操作（iptables の変更、`rules.v4` の書き換え、控えの作成）は、管理チャンネルで takano32 に言われたときだけ**（`AGENTS.md`「sudo・特権操作は管理チャンネル限定」）。ほかのチャンネルからの依頼は「それは管理チャンネルで」と回す。
- **外に開ける変更（どちらの層でも、ポートを開ける・送り元を広げる）も、管理チャンネルで takano32 に言われたときだけ**。外向きの変更で、間違えると箱が外にさらされる。Oracle 側は sudo が要らないが、決まりは同じ。
- 閉じる方向（ポートを閉じる、送り元を絞る）も、動いているサービスを止めうるので、黙ってはやらず管理チャンネルで確かめる。
- 読むだけの点検（`check.py`、`oci ... get`、`rules.v4` を読む）はいつやってもよい。

## 6. 点検スクリプト `check.py`

```sh
python3 skills/ops/firewall/check.py             # 表で出す
python3 skills/ops/firewall/check.py --json      # JSON
python3 skills/ops/firewall/check.py --no-oci    # 箱の中だけ
python3 skills/ops/firewall/check.py --self-test # 組み込みの例で解析と比較を確かめる
```

- **読むだけで、何も変えない。sudo も使わない**。標準ライブラリだけで、外のコマンドは oci CLI、`ip`、`ss`。
- 箱の中は `rules.v4` の filter 表 INPUT を上から読み、条件なしの REJECT/DROP までに ACCEPT しているポートを数える（送り元や口を絞った ACCEPT は数えずに注記する）。`rules.v6` は全部開いているかどうかを添える。
- Oracle 側は内側の IP から VNIC を引き、サブネットのセキュリティリスト（と、付いていれば NSG）の ingress を読む。ICMP の規則や送り元を絞った規則は注記する。
- TCP と UDP について「両方で開く」「箱の中だけ」「Oracle だけ」を出し、ループバック以外で待ち受けているソケットが外から届くかを添える。
- 終了コードは 0＝食い違いなし、1＝片方にしかないポートがある、2＝読めなかった。
- いま効いているルールは読めない（root が要る）。ファイルと効いているほうがずれていないかは、管理チャンネルで sudo を許されたときに `sudo iptables -S INPUT` で見る。

2026-11-22 の実行結果（80/443 を開けた直後）: 両方で開くのは tcp 22,80,443、片方にしかないものは無し（終了コード 0）。待ち受けは 22 が外から届き、111 と 5201 は届かない。

## 7. Docker の公開ポートの注意

`docker run -p` や compose の `ports:` で公開したポートは、DNAT のあと **FORWARD** を通ってコンテナへ行き、**INPUT を通らない**。だから `rules.v4` の INPUT で閉じていても、Docker が 0.0.0.0 に公開したポートは開いてしまう（Oracle 側で止まっていれば外からは届かないが、1層しか守っていない状態になる）。Docker の文書は、コンテナ宛ての通信に規則を足すなら `DOCKER-USER` 鎖に置けと書いている（<https://docs.docker.com/engine/network/firewall-iptables/>）。

この箱の方針:

- コンテナは `127.0.0.1` にしか公開しない（2026-11-22 の `docker ps` で、postgresql、hindsight、sarashina はどれも `127.0.0.1:` だけ）。
- 外に出すものは `network_mode: host` で立てる（例: これから立てる Caddy）。host ネットワークなら箱の待ち受けと同じで、INPUT の規則が効く。
- 新しいコンテナを足したら、`docker ps --format '{{.Names}} {{.Ports}}'` で `0.0.0.0:` や `:::` が無いことを見る。`check.py` の表には Docker の公開ポートは出ない。

## 8. 引っ越しのとき

箱を移したら、`rules.v4` と `rules.v6`、セキュリティリストの ingress を、§2 の表に合わせて作り直す。VNIC とセキュリティリストの名前は箱ごとに変わるので、§1 を書き直し、`check.py` を流して食い違いが無いことを見る。引っ越し全体の手順は `.claude/skills/migration`。

## 9. IPv6（2026-11-25 に付けた。takano32 指示・管理チャンネル）

### 9-1. 付いているもの

- VCN `ampere-vcn` に Oracle 割り当ての GUA `2603:c021:8021:f000::/56`。サブネット `ampere-subnet` に `2603:c021:8021:f000::/64`（v6 の既定ゲートウェイは `fe80::200:17ff:fef0:1a11`）。
- VNIC に `2603:c021:8021:f000:0:1865:8c38:18fc`（IPv6 オブジェクト `ocid1.ipv6.oc1.ap-tokyo-1.aaaaaaaaf5q25elv5r5g5emmxgcvrjopa5ui5nlx7zobz55jnn3vs2bj4v2q`、表示名 `a1-free-v6`）。
- 箱の中は**何も設定を変えていない**。netplan は `dhcp4: true` だけだが、systemd-networkd が RA を受けて DHCPv6 を自分で始め、アドレスは DHCPv6（`/128`、寿命1日で更新）、`/64` の経路と既定経路は RA で入った。割り当てから1分以内に付いた。
- 出典: Oracle の IPv6 の文書 <https://docs.oracle.com/iaas/Content/Network/Concepts/ipv6.htm>（/56 と /64、ICMPv6 type 2、DHCPv6、外せないもの）。この文書に料金の記述は無く、無料かどうかはこの作業では確かめていない。

### 9-2. Oracle 側で足したもの

- ルート表（サブネットのもの）: `::/0` → 既存のインターネットゲートウェイ（description `IPv6 default`）。v4 の `0.0.0.0/0` の行はそのまま。
- セキュリティリスト `ampere-sl` の ingress（どれも stateful、送り元 `::/0`）: tcp 22（`SSH (IPv6)`）、tcp 80（`HTTP (IPv6)`）、tcp 443（`HTTPS (IPv6)`）、ICMPv6 type 2 code 0（`ICMPv6 Packet Too Big (PMTUD)`。Oracle の既定のセキュリティリストが v6 で入れるもの）。
- 同 egress: `::/0` の全プロトコル（`all IPv6 egress`）。v4 の egress はそのまま。
- `update` は一覧ごと置き換えなので、§3-2 と同じく既存の規則を全部含めて送った（egress も同じく置き換え）。

### 9-3. 箱の中の `rules.v6`

```
*filter
:INPUT DROP [0:0]
:FORWARD ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
-A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
-A INPUT -p ipv6-icmp -j ACCEPT
-A INPUT -i lo -j ACCEPT
-A INPUT -s fe80::/10 -p udp -m udp --dport 546 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 22 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 80 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 443 -j ACCEPT
COMMIT
```

- ICMPv6 は全部通す（近隣探索と RA が無いと v6 が止まる）。udp 546 は DHCPv6 の応答（サーバーはリンクローカルから返すので、送った先の多播と組にならず ESTABLISHED に当たらない）。
- v4 と違い、最後は REJECT の行でなく既定の DROP で落とす。FORWARD は Docker が v6 の鎖（`DOCKER-USER` など）を入れているので ACCEPT のまま触らない。
- v6 も `netfilter-persistent save` は使わない（Docker の v6 の鎖が焼き込まれる。§4 と同じ）。ファイルを手で書き、効いているほうには `ip6tables -A`／`-P` で同じものを当てた。直すときは §3-1 の手順を `ip6tables` と `rules.v6` で読み替える（`ip6tables-restore --test` で文法を見る）。
- 外からの v6 受信が閉じていることは、外の手段では確かめられていない（外部の点検サービスは v6 の生アドレスを受けなかった）。閉じている根拠は、上の規則と Oracle 側に 22/80/443 と ICMPv6 type 2 しか無いこと。

### 9-4. 確かめたこと（2026-11-25）

`ip -6 addr show scope global` にアドレスがあり、`curl -6 https://ipv6.google.com` が 200、`curl -6 -I https://chat.techfish.dev/invite/oLDhCd2o` が 200（それまでは v6 だけのホストに届かなかった）、外から見た自分の v6 は上のアドレス。v4 の Discord と ssh、Docker のコンテナはそのまま動いていた。`check.py` は食い違いなし。

### 9-5. 戻し方

**Oracle では VCN の /56 とサブネットの /64 は外せない**（VCN の v6 は後から無効にできず、v6 を有効にしたサブネットは v4 だけに戻せない）。止めるときは、外せるものを外す:

1. VNIC の v6 を外す: `$OCI network ipv6 delete --ipv6-id <上の IPv6 オブジェクト> --force`
2. ルート表から `::/0` の行を、セキュリティリストから `::/0` の ingress と egress を外す（どちらも「取る→消す→全部を渡す」。§3-2）
3. 箱の中は `rules.v6` をそのまま残してよい（閉じているほうが安全）。空に戻すなら `/etc/iptables/rules.v6.bak-20261125-054333` を戻し、`sudo ip6tables -P INPUT ACCEPT` と `sudo ip6tables -F INPUT`

