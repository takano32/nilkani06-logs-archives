const ws = new WebSocket(process.argv[2]);
ws.onopen = () => ws.send(JSON.stringify({id:1, method:"Browser.close"}));
ws.onmessage = (e) => console.log("返り:", e.data);
ws.onclose = () => process.exit(0);
setTimeout(() => { console.log("5秒たっても閉じない"); process.exit(2); }, 5000);
