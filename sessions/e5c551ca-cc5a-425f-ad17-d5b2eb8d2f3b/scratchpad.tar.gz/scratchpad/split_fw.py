import re,sys
D='/home/takano32/nilkani06/skills/ops/firewall/'
L=open(D+'SKILL.md').read().split('\n')
def sec(a,b):  # 1-based inclusive line numbers
    return L[a-1:b]
n=len(L)
heads=[i+1 for i,l in enumerate(L) if re.match(r'^## \d',l)]
print(heads)
def body(start):
    idx=heads.index(start); end=(heads[idx+1]-1) if idx+1<len(heads) else n
    s=sec(start,end)
    while s and s[-1]=='': s.pop()
    return s
OC='`open-close.md` の「Oracle 側（セキュリティリスト）」'
IC='`open-close.md` の「箱の中（iptables）」'
NS='`netfilter-persistent-save.md`'
RULES='`SKILL.md` の「決まり（権限）」'
def fix(t):
    t=t.replace('§3-2',OC).replace('§3-1',IC).replace('§4',NS).replace('§9','`ipv6.md`')
    t=t.replace('§6','`check.md`').replace('§5',RULES).replace('§3 の手順','`open-close.md` の手順')
    t=t.replace('§2 の表','`ports.md` の表').replace('§1 を','`facts.md` を')
    return t
files={
 'facts.md':(25,'facts','この箱のファイアウォールの事実（VNIC、セキュリティリスト、netfilter-persistent、rules.v4 と rules.v6 の中身、控えのファイル）。2026-11-22 に確かめたもの。'),
 'ports.md':(37,'ports','いま開いているポートの一覧と用途・開けた日・経緯。待ち受けているが閉じているもの。ポートを開け閉めしたら同じコミットで直す表。'),
 'open-close.md':(56,'open-close','ポートの開け方・閉じ方。箱の中（rules.v4 と iptables -I/-D）と Oracle 側（oci network security-list update は一覧ごと置き換える）を2層セットで変える手順。'),
 'netfilter-persistent-save.md':(105,'netfilter-persistent-save','netfilter-persistent save を使わない理由（Docker の鎖が rules.v4 に焼き込まれる）。'),
 'check.md':(117,'check','読むだけの点検スクリプト check.py の使い方、何を見るか、終了コード、2026-11-22 の結果。'),
 'docker.md':(135,'docker','Docker の公開ポートが INPUT を通らない注意と、この箱の方針（127.0.0.1 にだけ公開、外に出すものは network_mode: host）。'),
 'ipv6.md':(149,'ipv6','この箱の IPv6（2026-11-25 に付けた）。付いているもの、Oracle 側で足したもの、rules.v6 の中身、確かめたこと、戻し方（VCN の /56 とサブネットの /64 は外せない）。'),
}
for fn,(st,name,desc) in files.items():
    s=body(st)
    h=s[0]
    h=re.sub(r'^## \d+\. ','# ',h)
    out=[h]
    for l in s[1:]:
        l=re.sub(r'^### \d+-\d+\. ','## ',l)
        out.append(l)
    txt='---\nname: '+name+'\ndescription: '+desc+'\n---\n\n'+fix('\n'.join(out))+'\n'
    open(D+fn,'w').write(txt)
# keep for SKILL.md: rules (110) and moving (145)
rules=body(110); mv=body(145)
open('/tmp/claude-1001/-home-takano32-nilkani06/e5c551ca-cc5a-425f-ad17-d5b2eb8d2f3b/scratchpad/keep.md','w').write(fix('\n'.join(rules+['']+mv))+'\n')
