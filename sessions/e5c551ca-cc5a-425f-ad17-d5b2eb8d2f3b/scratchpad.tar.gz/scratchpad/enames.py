import re,sys,json
N={0:'実装基盤の多段ピボット',1:'ログの別リポ分離と履歴の書き換え',2:'Opus 4.8 指定の即リバート',3:'幻の成功報告',4:'承認なしコミットのリバート',
5:'コンソール独り言の露出',6:'pip の break-system-packages 事故',7:'再起動2階層の混同',8:'空メッセージの正体',9:'チャンネル分離の連続違反',
10:'ブログ本文に残った下書きの断り',11:'montage の ImageMagick 化の撤回',12:'古いメモで撃った URL 付き X 投稿',13:'他ボットに反応できない',
14:'バイアスを論理に偽装',15:'セッション JSON の51件欠落',16:'自分の bot ID の誤読',17:'サブエージェントの二重投稿',18:'URL 要約だけの投稿',
19:'reply の壊れタグ',20:'3手詰の手読みの誤答',21:'一次証言を盛りと誤判定',22:'解散済み企業の現在形断定',23:'sudo の管理チャンネル限定',
24:'kill の宣言だけで終えたターン',25:'地震 watcher の誤自滅',26:'transcript の先走り削除',27:'安全フィルタのプロービング',28:'再フレーム要求への一律拒否',
29:'crash loop の指数バックオフ導入',30:'機微ログの方針転換',31:'検索の空振りを出典なしと断定',32:'詐欺業者の肯定',33:'ステータス表の転記ミス',
34:'internet-access-hook の新設',35:'再起動連発の誤診断',36:'前提から誤っていた承認待ち3件',37:'退避先リポの名前の2転',38:'名前で殺す掃除で自分を殺した',
39:'委譲の禁止を人で切った',40:'UTC のままの「これから」',41:'口調の規定の廃止',42:'同じ手順を2箇所に持った',43:'送らずに完了報告した委譲先',44:'見た目で段を選んだスキル編集'}
FA='.claude/skills/nilkani06-failure-archaeology/SKILL.md'
def q(n,inq):
    t=N[n]
    if inq: return '『%s』'%t.replace('「','“').replace('」','”')
    return '「%s」'%t.replace('「','『').replace('」','』')
E=r'(?<![A-Za-z0-9_.\[/])E(\d{1,2})(?:-(\d+)(?:/(\d+))?)?(?![\d\w\]\.])'
def conv(path,s):
    out=[]
    for line in s.split('\n'):
        if path==FA:
            m=re.match(r'^\*\*E(\d+)(.*)\*\*$',line)
            if m:
                n=int(m.group(1)); rest=m.group(2).strip()
                out.append('#### '+N[n]); out.append('')
                if rest: out.append('**'+rest+'**')
                continue
        def rng(m): return q(int(m.group(1)),False)+'から'+q(int(m.group(2)),False)+'まで'
        line=re.sub(r'(?<![A-Za-z0-9_.\[])E(\d{1,2})〜E(\d{1,2})',rng,line)
        res=[];pos=0;prev_end=-10
        for m in re.finditer(E,line):
            n=int(m.group(1))
            if n not in N: continue
            seg=line[pos:m.start()]
            pre=''.join(res)+seg
            inq=pre.count('「')>pre.count('」')
            rep=q(n,inq)
            if m.group(2):
                rep+='のその'+m.group(2)+('とその'+m.group(3) if m.group(3) else '')
            chained = prev_end>=0 and re.fullmatch(r'\s*[・、,／/と]\s*',line[prev_end:m.start()]) is not None
            if not chained:
                if re.search(r'(failure-archaeology`?|事件簿|考古学)\s*(の)?\s*$',seg):
                    seg=re.sub(r'\s*(の)?\s*$','の',seg)
                elif path!=FA and not re.search(r'[「『]$',seg):
                    rep='事件簿の'+rep
            elif seg.strip()==',':
                seg='、'
            res.append(seg+rep); pos=m.end(); prev_end=m.end()
        res.append(line[pos:]); out.append(''.join(res))
    return '\n'.join(out)
for p in sys.argv[1:]:
    s=open(p).read(); t=conv(p,s)
    if t!=s: open(p,'w').write(t); print('changed',p)
