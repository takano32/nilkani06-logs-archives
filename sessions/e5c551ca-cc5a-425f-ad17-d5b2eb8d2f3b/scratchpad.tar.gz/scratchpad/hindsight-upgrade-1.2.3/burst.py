# ja-test にだけ、自作の無害な4文を並列で同期の取り込み。そのあいだ recall フックと同じ呼び方（本番 bank、scope:global）で recall を撃って所要を測る。
import importlib.util, json, threading, time, urllib.request
BASE = "http://127.0.0.1:18888/v1/default/banks/ja-test"
spec = importlib.util.spec_from_file_location("rh", "/home/takano32/nilkani06/scripts/hindsight-recall-hook.py")
rh = importlib.util.module_from_spec(spec); spec.loader.exec_module(rh)
stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
texts = [
 "再来週の月曜日に、近所の図書館で料理の本を3冊借りる予定。返却は2週間後。",
 "週末に自転車でダム湖まで走った。往復で42キロ、途中の茶屋で抹茶のアイスを食べた。",
 "新しいノートパソコンのキーボードは打鍵音が静かで、長文を書くときに疲れにくい。",
 "来月の第2土曜日に、友人と陶芸教室へ行く。作るのは湯のみと小皿で、焼き上がりは1か月後。",
]
res = {}
def one(i, t):
    body = json.dumps({"items": [{"content": t, "document_id": f"upgrade-123-burst-{stamp}-{i}", "context": "upgrade-1.2.3 burst"}], "async": False}).encode()
    req = urllib.request.Request(BASE + "/memories", data=body, method="POST", headers={"Content-Type": "application/json"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            ok = json.load(r).get("success")
        res[i] = (round(time.time() - t0, 1), ok)
    except Exception as e:
        res[i] = (round(time.time() - t0, 1), type(e).__name__)
th = [threading.Thread(target=one, args=(i, t)) for i, t in enumerate(texts)]
t_start = time.time()
for x in th: x.start()
probes = []
while any(x.is_alive() for x in th) and len(probes) < 8:
    time.sleep(20)
    t0 = time.time(); r = rh.recall("Hindsight の版を上げた後の見張り", [rh.GLOBAL_TAG]); dt = time.time() - t0
    probes.append((round(time.time() - t_start), None if r is None else len(r), round(dt, 2)))
for x in th: x.join()
print("burst 同期 retain の所要（秒, success）:", dict(sorted(res.items())), "全体", round(time.time() - t_start), "秒")
print("負荷中の recall（開始から秒, 返り件数, 所要秒）:", probes)
open("burst_stamp.txt", "w").write(stamp)
