# 前回の続きから、最新のサンプル行と、TRIGGER／WARN／REVIEW／error の行だけを出す。引数: 待つ秒数（最大 170）
import os, sys, time
OFF = "tail2.off"
wait = min(int(sys.argv[1]) if len(sys.argv) > 1 else 0, 170)
off = int(open(OFF).read()) if os.path.exists(OFF) else 0
t0 = time.time()
while True:
    raw = open("watch-loop.out", "rb").read()
    new = raw[off:].decode("utf-8", "ignore")
    if time.time() - t0 >= wait or "  TRIGGER " in new:
        break
    time.sleep(5)
open(OFF, "w").write(str(len(raw)))
lines = new.splitlines()
samples = [l for l in lines if l.startswith("[")]
keep = [l for l in lines if (" WARN:" in l or "TRIGGER" in l or "REVIEW" in l or "llm error" in l or "SAMPLE ERRORS" in l)]
for l in keep[-6:]: print(l[:300])
print(f"（新しいサンプル {len(samples)} 件）最新:")
if samples: print(samples[-1][:420])
print("--", time.strftime("%H:%M:%S", time.gmtime()), "UTC")
