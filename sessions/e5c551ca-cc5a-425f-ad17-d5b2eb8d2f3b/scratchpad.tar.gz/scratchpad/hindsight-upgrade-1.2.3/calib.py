# 見張りの化け検出の較正。上げる前の24時間（1.1.0で作られた観察＝正常と見なす）に同じ検査を当て、検出語ごとの誤検出の率を出す。
import importlib.util, json, re, subprocess, sys
spec = importlib.util.spec_from_file_location("watch", "watch.py"); w = importlib.util.module_from_spec(spec); spec.loader.exec_module(w)
CUT = "2026-11-23T03:52:31Z"   # T1 の24時間前
def psql(sql):
    p = subprocess.run(["docker", "exec", "postgresql", "psql", "-U", "postgres", "-d", "hindsight", "-At", "-c", sql], capture_output=True, text=True, timeout=300)
    if p.returncode: raise SystemExit(p.stderr[:200])
    return p.stdout
# 1. 24時間より前の文章だけの漢字の集まり
uni, bi = set(), set(); n = 0
for sql in (f"select text from memory_units where created_at < '{CUT}'",
            f"select original_text from documents where created_at < '{CUT}' and original_text is not null",
            f"select chunk_text from chunks where created_at < '{CUT}'"):
    t = psql(sql); u, b = w.kanji_grams(t); uni |= u; bi |= b; n += len(t)
print(f"較正用の集まり: {n} 文字、漢字 {len(uni)} 字、2字連 {len(bi)} 種（{CUT} より前）")
# 2. 検査対象: 24時間前から T1 までに作られた観察（出所の本文つき）
rows = w.J(f"select o.id, o.bank_id, o.created_at, o.updated_at, o.text, o.tags, "
           f"(select coalesce(string_agg(s.text, E'\\n¶\\n'), '') from memory_units s where s.id = any(o.source_memory_ids)) src "
           f"from memory_units o where o.fact_type='observation' and o.created_at >= '{CUT}' and o.created_at < '{w.T1}'")
print("検査対象の観察:", len(rows), "件", dict(__import__('collections').Counter(r['bank_id'] for r in rows)))
cnt = __import__('collections').Counter(); examples = {}
for o in rows:
    fl = w.audit_obs(o, uni, bi)
    for k in fl:
        cnt[k] += 1; examples.setdefault(k, []).append((o["id"][:8], o["bank_id"], fl[k]))
for k in ("leak", "esc", "example", "degen", "novel", "long"):
    print(f"  {k:8s} {cnt[k]:4d} 件 ({100*cnt[k]/max(1,len(rows)):.1f}%)")
for k in ("leak", "esc", "example", "degen"):
    for e in examples.get(k, [])[:4]:
        print("   例", k, e[0], e[1], json.dumps(e[2], ensure_ascii=False)[:150])
nov = examples.get("novel", [])
print("novel の例（頭 8 件）:")
for e in nov[:8]:
    print("   ", e[0], e[1], json.dumps(e[2], ensure_ascii=False)[:150])
