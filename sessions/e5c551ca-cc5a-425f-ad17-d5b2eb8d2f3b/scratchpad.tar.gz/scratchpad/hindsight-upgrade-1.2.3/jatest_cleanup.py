# ja-test の試験用の記憶を取り下げ（PATCH state=invalidated。訂正フックと同じ経路）、引けなくなることを確かめる。ja-test にだけ撃つ。
import json, subprocess, time, urllib.request
BASE = "http://127.0.0.1:18888/v1/default/banks/ja-test"
doc = open("jatest_doc_id.txt").read().strip()
def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.status, json.load(r)
ids = subprocess.run(["docker", "exec", "postgresql", "psql", "-U", "postgres", "-d", "hindsight", "-At", "-c",
                      f"select id from memory_units where bank_id='ja-test' and fact_type<>'observation' and document_id='{doc}'"],
                     capture_output=True, text=True).stdout.split()
print("取り下げる事実:", ids)
for i in ids:
    st, r = call("PATCH", f"/memories/{i}", {"state": "invalidated", "reason": "upgrade 1.2.3 check cleanup"})
    print("PATCH", st, json.dumps(r, ensure_ascii=False)[:160])
time.sleep(5)
st, r = call("POST", "/memories/recall", {"query": "京都に行くのはいつ？", "budget": "low", "max_tokens": 2048})
res = r.get("results") or []
print("recall:", len(res), "件, 今回の文書の事実/観察が残っているか:", any(x.get("document_id") == doc for x in res))
