# 作業の控え。cl "<打つコマンドそのまま>" で時刻つきで cmdlog.txt に足す
WD=/tmp/claude-1001/-home-takano32-nilkani06/e5c551ca-cc5a-425f-ad17-d5b2eb8d2f3b/scratchpad/hindsight-upgrade-1.2.3
cl() { printf '%s  %s\n' "$(date -u +%FT%TZ)" "$*" >> "$WD/cmdlog.txt"; }
