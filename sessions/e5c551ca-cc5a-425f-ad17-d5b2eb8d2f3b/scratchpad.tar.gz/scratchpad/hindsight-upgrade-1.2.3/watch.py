#!/usr/bin/env python3
"""Hindsight 1.2.3 試験の見張り（読み取りだけ。本番には何も書かない）。

使い方（python3 -I で撃つ）:
  watch.py sample                  1回測って1行出し、watch.jsonl に足す
  watch.py loop --seconds 570 --every 60 [--stop-on-trigger]
                                   every 秒おきに測る。トリガが立つか seconds 経つまで
  watch.py corpus                  上げる前の文章（T1 より前）の漢字の集まりを corpus-kanji.json に作る
  watch.py summary                 T1 以降の全体の数字（最後の報告用）を JSON で出す

指標の定義（すべて T1＝新しいコンテナの起動時刻 以降。T1 は t1.txt）:
  health      GET /health の 200 と所要 ms
  queue       async_operations の pending（next_retry_at が無いか過去＝すぐ動けるもの）と processing の件数、
              いちばん古い pending の経過秒、いちばん古い processing の経過秒（claimed_at から）、
              worker_id が hindsight-main でない processing（取り残し）の件数
  done        completed になった operation を種類別に（直近10分と T1 以降）、wall 秒＝completed_at - claimed_at
  failed      status=failed の operation（T1 以降に updated）
  llm         llm_requests（started_at >= T1）を operation x scope x status で、件数・平均秒・p90・最大・平均出力トークン。
              LLM 呼び出しは scope が embedding_* でも rerank でもないもの
  logs        docker logs hindsight --since T1 の行を数える: ERROR、Traceback、WARNING、OutputTooLong、
              LLM batch call failed、Connection error、TimeoutError、STUCK_STACK、EVENT LOOP BLOCKED、DB POOL Slow acquire
  obs         memory_units の fact_type='observation' で created_at か updated_at が T1 以降のもの（新しい・更新された観察）を
              1件ずつ検査する（下の検出語）。出所の記憶（source_memory_ids）の本文にもある語は「元の文にある」＝化けではない
  stats       GET /v1/default/banks/{bank}/stats の pending_consolidation、failed_consolidation（5回に1回）

化けの検出（観察の本文のうち、出所の記憶の本文に無いもの。これを unexplained と呼ぶ）:
  leak     答えの型の欄の名前（observation_text、observation_about、observation_id、same_as_fact、fact_id、merged_into、
           newer_than_input_facts）と、JSON 風の "facts":/"deletes":/"existing":/"adds":/"effect":/"kind":/"about":/"new":
           と、kind: lasting のような「欄: 値」
  esc      \\uXXXX の列（日本語を \\u で書いて化けた型）
  example  プロンプトの例の語（ledger-sink、billing-sink、Paolo、Cleo、Nimbus、Zurich、Lisbon、on-call rotation、dog named Rex ほか）
  degen    同じ字の20回以上の連続、40字以上の空白の連続、6〜40字の塊の4回以上の繰り返し
  novel    漢字の1字・2字連（bigram）が、上げる前の文章（corpus-kanji.json）にも出所の本文にも無いもの。
           正常な新語・固有名詞も出るので、トリガにはせず人が読む（REVIEW）
トリガ（戻す判断）:
  garble        leak / esc / example / degen / known（11/12 の化けの熟語 了束・提情・綑変）のどれかが unexplained で1件でもある（1件でも立てる）
  cons_consec   統合の LLM 呼び出し（operation=consolidation、scope が embedding_* でも rerank でもない）の直近2件がどちらも error
  cons_hard     上のうち TimeoutError・CancelledError 以外の error が2件以上
  cons_total    上のうち error が合計4件以上（基準は 1.1.0 の24時間で2件＝1時間あたり約0.1件）
  otl           ログの OutputTooLong が2行以上（1.1.0 の24時間は0）
  retain_fail   取り込みの抽出（operation=retain の LLM scope）の直近2件がどちらも error、または error が合計4件以上
  ops_failed    status=failed の operation が2件以上
  cons_marks    memory_units.consolidation_failed_at が付いた記憶が基準（0）から2件以上増えた
  stuck_stack   ログの STUCK_STACK が直近10分に3行以上
  stuck_queue   すぐ動ける pending のいちばん古いのが1200秒以上で、直近20分の completed が0件、かつ processing が0件（誰も取りに行っていない）
  stranded      hindsight-main でない worker の processing が2回続けて残っている
  stuck_llm     processing があるのに、LLM 呼び出し（embedding と rerank を除く）の完了が1500秒（25分）以上ない。
                経過の長さでは決めない＝1.1.0 の24時間の統合は p90 830 秒、最大 4615 秒（zerozari00）で、1500 秒超が4件あった。
                LLM 1回の最長は 1.1.0 で成功 1001 秒、TimeoutError は 1207〜1220 秒
  health_down   health が3回続けて通らない
  restart       コンテナが running でない、RestartCount が2以上、OOMKilled
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone

WD = os.path.dirname(os.path.abspath(__file__))
T1 = open(os.path.join(WD, "t1.txt")).read().strip()            # 新しいコンテナの起動時刻（UTC）
STATE_F = os.path.join(WD, "watch-state.json")
LOG_F = os.path.join(WD, "watch.jsonl")
CORPUS_F = os.path.join(WD, "corpus-kanji.json")
WORKER_ID = "hindsight-main"
OWN_CHAT = "chat:1511709772322177144"

KANJI = re.compile(r"[一-鿿々〆ヶ]")
RE_LEAK = re.compile(
    r"\b(observation_text|observation_about|observation_id|same_as_fact|fact_id|merged_into|newer_than_input_facts)\b"
    r"|\"(facts|deletes|existing|adds|effect|kind|about|new)\"\s*:"
    r"|\b(kind|effect|adds)\s*[:=]\s*\"?(lasting|momentary|unrelated|repeats|changes|ends|yes|no)\b")
RE_ESC = re.compile(r"\\u[0-9a-fA-F]{4}")
RE_EXAMPLE = re.compile(r"ledger-sink|ledger-sync|billing-sink|billing-gateway|\bPaolo\b|\bPaola\b|\bCleo\b|Nimbus|Zurich|Lisbon"
                        r"|on-call rotation|dog named Rex|\bAna, Ben\b")
RE_KNOWN = re.compile(r"了束|提情|綑変")   # 2026-11-12 の 1.2.1 で出た化けの熟語（会話で話題になった語は集まりに入るので novel では拾えない）
RE_DEGEN = [re.compile(r"(.)\1{19,}", re.S), re.compile(r"\s{40,}"), re.compile(r"(.{6,40}?)\1{3,}", re.S)]


# ---------------------------------------------------------------- 取り出し
def psql_json(sql):
    p = subprocess.run(["docker", "exec", "postgresql", "psql", "-U", "postgres", "-d", "hindsight", "-At", "-c", sql],
                       capture_output=True, text=True, timeout=90)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip()[:300])
    s = p.stdout.strip()
    return json.loads(s) if s else None


def J(inner):
    return psql_json(f"select coalesce(json_agg(t), '[]'::json) from ({inner}) t")


def api_get(path, timeout=20):
    with urllib.request.urlopen("http://127.0.0.1:18888" + path, timeout=timeout) as r:
        return json.load(r)


def load_state():
    try:
        return json.load(open(STATE_F))
    except Exception:
        return {"n": 0, "health_fail": 0, "stranded_prev": 0, "audited": {}, "reviewed": [], "cons_marks_base": None, "t_first": None}


def save_state(s):
    json.dump(s, open(STATE_F, "w"), ensure_ascii=False)


def parse_ts(line):
    m = re.match(r"(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})", line)
    return datetime.strptime(m.group(1) + " " + m.group(2), "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc) if m else None


# ---------------------------------------------------------------- 各区画
def sec_health():
    t = time.time()
    try:
        h = api_get("/health", 5)
        return {"ok": h.get("status") == "healthy", "ms": round((time.time() - t) * 1000), "db_ms": h.get("db_acquire_ms"), "pool_wait": h.get("db_pool_waiting")}
    except Exception as e:
        return {"ok": False, "err": type(e).__name__}


def sec_container():
    p = subprocess.run(["docker", "inspect", "hindsight", "--format",
                        "{{.State.StartedAt}}|{{.RestartCount}}|{{.State.Status}}|{{.Config.Image}}|{{.State.OOMKilled}}"],
                       capture_output=True, text=True, timeout=20)
    f = p.stdout.strip().split("|")
    return {"started": f[0], "restarts": int(f[1]), "status": f[2], "image": f[3], "oom": f[4]}


def sec_host():
    la = open("/proc/loadavg").read().split()[:3]
    mem = {l.split(":")[0]: int(l.split()[1]) for l in open("/proc/meminfo")}
    return {"load": [float(x) for x in la], "mem_avail_mb": mem["MemAvailable"] // 1024}


def sec_queue():
    rows = J("select status, operation_type typ, count(*) n from async_operations where status in ('pending','processing') "
             "and (status='processing' or next_retry_at is null or next_retry_at <= now()) group by 1,2 order by 1,2")
    a = J(f"""select
      coalesce(max(extract(epoch from now()-created_at)) filter (where status='pending' and (next_retry_at is null or next_retry_at<=now())),0)::int pending_ready_oldest_s,
      coalesce(max(extract(epoch from now()-coalesce(claimed_at,updated_at))) filter (where status='processing'),0)::int processing_oldest_s,
      count(*) filter (where status='processing' and worker_id <> '{WORKER_ID}') foreign_processing,
      count(*) filter (where status='pending' and next_retry_at > now()) deferred
      from async_operations""")[0]
    a["llm_idle_s"] = J("select coalesce(extract(epoch from now()-max(ended_at)),-1)::int s from llm_requests "
                        "where scope not like 'embedding%' and scope not like 'rerank%'")[0]["s"]
    a["by"] = {f"{r['status']}:{r['typ']}": r["n"] for r in rows}
    a["pending"] = sum(r["n"] for r in rows if r["status"] == "pending")
    a["processing"] = sum(r["n"] for r in rows if r["status"] == "processing")
    return a


def sec_ops():
    done = J(f"select operation_type typ, count(*) n, round(avg(extract(epoch from completed_at-coalesce(claimed_at,created_at)))::numeric,1) avg_wall_s, "
             f"round(max(extract(epoch from completed_at-coalesce(claimed_at,created_at)))::numeric,1) max_wall_s "
             f"from async_operations where status='completed' and completed_at >= '{T1}' group by 1 order by 1")
    d10 = J("select operation_type typ, count(*) n from async_operations where status='completed' and completed_at >= now() - interval '10 minutes' group by 1")
    d20 = J("select count(*) n from async_operations where status='completed' and completed_at >= now() - interval '20 minutes'")[0]["n"]
    failed = J(f"select operation_type typ, count(*) n, max(left(coalesce(error_message,''),160)) err from async_operations "
               f"where status='failed' and updated_at >= '{T1}' group by 1")
    return {"done": done, "done10m": {r["typ"]: r["n"] for r in d10}, "done20m": d20, "failed": failed}


def sec_llm():
    rows = J(f"select operation, scope, status, count(*) n, round((avg(duration_ms)/1000.0)::numeric,1) avg_s, "
             f"round(((percentile_cont(0.9) within group (order by duration_ms))/1000.0)::numeric,1) p90_s, "
             f"round((max(duration_ms)/1000.0)::numeric,1) max_s, round(avg(output_tokens)::numeric) avg_out "
             f"from llm_requests where started_at >= '{T1}' group by 1,2,3 order by 1,2,3")
    errs = J(f"select to_char(started_at,'HH24:MI:SS') t, operation, scope, left(replace(coalesce(error,''),E'\\n',' '),160) err, "
             f"round((duration_ms/1000.0)::numeric,1) s from llm_requests where started_at >= '{T1}' and status <> 'success' order by started_at")
    last_c = J(f"select status, left(coalesce(error,''),60) err from llm_requests where operation='consolidation' and scope not like 'embedding%' "
               f"and scope not like 'rerank%' and started_at >= '{T1}' order by started_at desc limit 2")
    last_r = J(f"select status from llm_requests where operation='retain' and scope not like 'embedding%' and scope not like 'rerank%' "
               f"and started_at >= '{T1}' order by started_at desc limit 2")
    return {"rows": rows, "errs": errs, "last_cons": last_c, "last_retain": last_r}


LOG_PATS = {"ERROR": " - ERROR - ", "Traceback": "Traceback (most recent call last)", "WARNING": " - WARNING - ",
            "OutputTooLong": "OutputTooLong", "LLM_batch_failed": "LLM batch call failed", "Connection_error": "Connection error",
            "TimeoutError": "TimeoutError", "STUCK_STACK": "STUCK_STACK", "EVENT_LOOP_BLOCKED": "EVENT LOOP BLOCKED",
            "DB_slow_acquire": "Slow acquire"}


def parse_elb(lines):
    """EVENT LOOP BLOCKED の見出しごとに（時刻、秒、止めているコードの場所）を返す。
    watchdog は1回の停止につき1行だけ出し、括弧の中の秒は「検出した時点で止まっていた長さ」（停止全体の長さの下限）。"""
    ts_rx = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}")
    ev, i = [], 0
    while i < len(lines):
        if "EVENT LOOP BLOCKED" in lines[i]:
            m = re.match(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),\d+ .*\(([0-9.]+)s and counting\)", lines[i])
            j, st = i + 1, []
            while j < len(lines) and not ts_rx.match(lines[j]):
                st.append(lines[j]); j += 1
            files = [x.strip() for x in st if x.strip().startswith("File ")]
            m2 = re.search(r'File "([^"]+)", line (\d+), in (\S+)', files[-1]) if files else None
            where = (m2.group(1).replace("/app/api/.venv/lib/python3.11/site-packages/", "site/").replace("/app/api/hindsight_api/", "ha/")
                     + ":" + m2.group(2) + " " + m2.group(3)) if m2 else "?"
            ev.append({"t": m.group(1) if m else "?", "s": float(m.group(2)) if m else None, "where": where})
            i = j
        else:
            i += 1
    return ev


def sec_logs():
    p = subprocess.run(["docker", "logs", "hindsight", "--since", T1], capture_output=True, text=True, timeout=60)
    text = p.stdout + p.stderr
    lines = text.splitlines()
    out = {k: sum(1 for l in lines if pat in l) for k, pat in LOG_PATS.items()}
    now = datetime.now(timezone.utc)
    stuck10 = 0
    for l in lines:
        if "STUCK_STACK" in l:
            ts = parse_ts(l)
            if ts and (now - ts).total_seconds() <= 600:
                stuck10 += 1
    out["STUCK_STACK_10m"] = stuck10
    elb = parse_elb(lines)
    out["elb_events"] = elb
    out["elb_n"] = len(elb)
    out["elb_max_s"] = max((e["s"] for e in elb if e["s"] is not None), default=0.0)
    out["ELB_10m"] = sum(1 for e in elb if e["t"] != "?" and
                         (now - datetime.strptime(e["t"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)).total_seconds() <= 600)
    cons = re.findall(r"CONSOLIDATION COMPLETE: ([0-9.]+)s total", text)
    out["cons_complete_n"] = len(cons)
    out["cons_complete_avg_s"] = round(sum(float(x) for x in cons) / len(cons), 1) if cons else None
    res = re.findall(r"Results: (\d+) memories -> (\d+) actions \((\d+) created, (\d+) updated, (\d+) merged, (\d+) skipped\)", text)
    out["cons_results"] = {"memories": sum(int(r[0]) for r in res), "created": sum(int(r[2]) for r in res), "updated": sum(int(r[3]) for r in res),
                           "merged": sum(int(r[4]) for r in res), "skipped": sum(int(r[5]) for r in res)}
    out["lines"] = len(lines)
    return out


def sec_cons_marks():
    return J("select bank_id, count(*) n from memory_units where consolidation_failed_at is not null group by 1")


def sec_stats():
    out = {}
    for b in ("nilkani06", "zerozari00"):
        try:
            d = api_get(f"/v1/default/banks/{b}/stats", 30)
            out[b] = {k: d.get(k) for k in ("pending_consolidation", "failed_consolidation", "pending_operations", "failed_operations", "total_observations", "total_nodes")}
        except Exception as e:
            out[b] = {"err": type(e).__name__}
    return out


# ---------------------------------------------------------------- 観察の検査
def kanji_grams(s):
    uni, bi = set(), set()
    prev = None
    for ch in s:
        if KANJI.match(ch):
            uni.add(ch)
            if prev:
                bi.add(prev + ch)
            prev = ch
        else:
            prev = None
    return uni, bi


def load_corpus():
    try:
        d = json.load(open(CORPUS_F))
        return set(d["uni"]), set(d["bi"])
    except Exception:
        return None, None


def audit_obs(o, uni_set, bi_set):
    text, src = o["text"] or "", o["src"] or ""
    srcl = src.lower()
    flags = {}
    for name, rx in (("leak", RE_LEAK), ("esc", RE_ESC), ("example", RE_EXAMPLE), ("known", RE_KNOWN)):
        hits = [m.group(0) for m in rx.finditer(text)]
        un = [h for h in hits if h.lower() not in srcl]
        if un:
            flags[name] = un[:5]
    for rx in RE_DEGEN:
        m = rx.search(text)
        if m and m.group(0) not in src:
            flags["degen"] = [m.group(0)[:40]]
            break
    if uni_set is not None:
        tu, tb = kanji_grams(text)
        su, sb = kanji_grams(src)
        nu = sorted(c for c in tu if c not in uni_set and c not in su)
        nb = sorted(b for b in tb if b not in bi_set and b not in sb)
        if nu or nb:
            flags["novel"] = {"uni": nu[:5], "bi": nb[:8]}
    if len(text) > 1500:
        flags["long"] = len(text)
    return flags


def sec_obs(state):
    rows = J(f"select o.id, o.bank_id, o.created_at, o.updated_at, o.text, o.tags, "
             f"(select coalesce(string_agg(s.text, E'\\n¶\\n'), '') from memory_units s where s.id = any(o.source_memory_ids)) src "
             f"from memory_units o where o.fact_type='observation' and (o.created_at >= '{T1}' or o.updated_at >= '{T1}') order by o.updated_at")
    uni_set, bi_set = load_corpus()
    out = {"total": len(rows), "new": 0, "upd": 0, "new_flags": [], "hard": [], "review": [], "corpus": uni_set is not None}
    for o in rows:
        key = o["id"]
        created_after = o["created_at"] >= T1.replace("Z", "")  # 文字列比較（どちらも ISO）
        if created_after:
            out["new"] += 1
        else:
            out["upd"] += 1
        if state["audited"].get(key) == o["updated_at"]:
            continue
        state["audited"][key] = o["updated_at"]
        flags = audit_obs(o, uni_set, bi_set)
        scope = "own" if OWN_CHAT in (o.get("tags") or []) else ("global" if "scope:global" in (o.get("tags") or []) else "other")
        rec = {"id": o["id"][:8], "bank": o["bank_id"], "scope": scope, "created": o["created_at"], "updated": o["updated_at"], "flags": flags}
        if flags:
            out["new_flags"].append(rec)
        if any(k in flags for k in ("leak", "esc", "example", "degen", "known")):
            out["hard"].append(rec)
        elif "novel" in flags or "long" in flags:
            out["review"].append(rec)
    return out


# ---------------------------------------------------------------- 判定
def evaluate(s, st):
    trig, warn = [], []
    h, c = s["health"], s["container"]
    st["health_fail"] = 0 if h.get("ok") else st.get("health_fail", 0) + 1
    if st["health_fail"] >= 3:
        trig.append(("health_down", f"health が {st['health_fail']} 回続けて通らない"))
    if c["status"] != "running" or c["restarts"] >= 2 or c["oom"] == "true":
        trig.append(("restart", f"status={c['status']} restarts={c['restarts']} oom={c['oom']}"))
    elif c["restarts"] == 1:
        warn.append("コンテナの再起動が1回")
    llm = s["llm"]
    cons_err = [r for r in llm["rows"] if r["operation"] == "consolidation" and r["status"] != "success"
                and not r["scope"].startswith(("embedding", "rerank"))]
    cons_err_n = sum(r["n"] for r in cons_err)
    cons_hard = [e for e in llm["errs"] if e["operation"] == "consolidation" and not e["scope"].startswith(("embedding", "rerank"))
                 and not e["err"].startswith(("TimeoutError", "CancelledError"))]
    if len(llm["last_cons"]) == 2 and all(r["status"] != "success" for r in llm["last_cons"]):
        trig.append(("cons_consec", "統合の LLM 呼び出しの直近2件がどちらも error"))
    if len(cons_hard) >= 2:
        trig.append(("cons_hard", f"統合の LLM error（Timeout/Cancel 以外）{len(cons_hard)} 件: " + " | ".join(e['err'][:60] for e in cons_hard[:3])))
    if cons_err_n >= 4:
        trig.append(("cons_total", f"統合の LLM error が合計 {cons_err_n} 件"))
    elif cons_err_n:
        warn.append(f"統合の LLM error {cons_err_n} 件（基準は1時間あたり約0.1件）")
    if s["logs"]["OutputTooLong"] >= 2:
        trig.append(("otl", f"ログの OutputTooLong {s['logs']['OutputTooLong']} 行"))
    elif s["logs"]["OutputTooLong"]:
        warn.append(f"OutputTooLong {s['logs']['OutputTooLong']} 行")
    ret_err = sum(r["n"] for r in llm["rows"] if r["operation"] == "retain" and r["status"] != "success" and not r["scope"].startswith(("embedding", "rerank")))
    if (len(llm["last_retain"]) == 2 and all(r["status"] != "success" for r in llm["last_retain"])) or ret_err >= 4:
        trig.append(("retain_fail", f"取り込みの抽出の error（直近2件が連続、または合計 {ret_err} 件）"))
    elif ret_err:
        warn.append(f"取り込みの抽出の error {ret_err} 件")
    nfail = sum(r["n"] for r in s["ops"]["failed"])
    if nfail >= 2:
        trig.append(("ops_failed", f"failed の operation {nfail} 件: " + " | ".join(f"{r['typ']}:{r['err'][:50]}" for r in s["ops"]["failed"])))
    elif nfail:
        warn.append(f"failed の operation {nfail} 件")
    marks = sum(r["n"] for r in s["cons_marks"])
    if st.get("cons_marks_base") is None:
        st["cons_marks_base"] = marks
    if marks - st["cons_marks_base"] >= 2:
        trig.append(("cons_marks", f"consolidation_failed_at が付いた記憶が {marks - st['cons_marks_base']} 件増えた"))
    elif marks > st["cons_marks_base"]:
        warn.append(f"consolidation_failed_at が {marks - st['cons_marks_base']} 件増えた")
    if s["logs"]["STUCK_STACK_10m"] >= 3:
        trig.append(("stuck_stack", f"STUCK_STACK が直近10分に {s['logs']['STUCK_STACK_10m']} 行"))
    q = s["queue"]
    if q["pending_ready_oldest_s"] >= 1200 and s["ops"]["done20m"] == 0 and q["processing"] == 0:
        trig.append(("stuck_queue", f"すぐ動ける pending の最古 {q['pending_ready_oldest_s']} 秒、直近20分の completed 0 件"))
    if q["foreign_processing"] > 0:
        st["stranded_prev"] = st.get("stranded_prev", 0) + 1
        if st["stranded_prev"] >= 2:
            trig.append(("stranded", f"別 worker の processing が {q['foreign_processing']} 件、2回続けて残っている"))
        else:
            warn.append(f"別 worker の processing が {q['foreign_processing']} 件（1回目）")
    else:
        st["stranded_prev"] = 0
    if q["processing"] > 0 and q.get("llm_idle_s", -1) >= 1500:
        trig.append(("stuck_llm", f"processing {q['processing']} 件なのに、LLM 呼び出しの完了が {q['llm_idle_s']} 秒ない"))
    elif q["processing_oldest_s"] >= 1800:
        warn.append(f"processing のいちばん古いのが {q['processing_oldest_s']} 秒（基準: 1.1.0 の24時間で統合 p90 830 秒・最大 4615 秒）")
    if s["logs"]["ELB_10m"] >= 6:
        warn.append(f"EVENT LOOP BLOCKED が直近10分に {s['logs']['ELB_10m']} 行")
    if s["obs"]["hard"]:
        trig.append(("garble", " / ".join(f"{r['bank']}:{r['id']}({r['scope']}) {json.dumps({k: v for k, v in r['flags'].items() if k in ('leak','esc','example','degen','known')}, ensure_ascii=False)[:160]}" for r in s["obs"]["hard"])))
    return trig, warn


def line(s, trig, warn):
    h, c, q, lg = s["health"], s["container"], s["queue"], s["logs"]
    llm = s["llm"]["rows"]

    def llm_s(op):
        ok = [r for r in llm if r["operation"] == op and r["status"] == "success" and not r["scope"].startswith(("embedding", "rerank"))]
        er = [r for r in llm if r["operation"] == op and r["status"] != "success" and not r["scope"].startswith(("embedding", "rerank"))]
        n, e = sum(r["n"] for r in ok), sum(r["n"] for r in er)
        avg = round(sum(r["avg_s"] * r["n"] for r in ok) / n, 1) if n else None
        return f"{n}ok/{e}err avg{avg}s"
    o = s["obs"]
    return (f"[{s['t'][11:19]}Z #{s['n']}] h={'ok' if h.get('ok') else 'NG'}({h.get('ms')}ms) load={'/'.join(str(x) for x in s['host']['load'])} avail={s['host']['mem_avail_mb']}MB "
            f"| pend={q['pending']} proc={q['processing']} oldest(p/r)={q['pending_ready_oldest_s']}/{q['processing_oldest_s']}s "
            f"| done10m={s['ops']['done10m']} | cons llm {llm_s('consolidation')} | retain llm {llm_s('retain')} "
            f"| logs ERR{lg['ERROR']} TB{lg['Traceback']} OTL{lg['OutputTooLong']} LBF{lg['LLM_batch_failed']} CONN{lg['Connection_error']} TO{lg['TimeoutError']} STUCK{lg['STUCK_STACK']} ELB{lg['EVENT_LOOP_BLOCKED']}(max{lg.get('elb_max_s')}s) "
            f"| obs new={o['new']} upd={o['upd']} hard={len(o['hard'])} review={len(o['review'])} "
            f"| {'TRIGGER:' + ','.join(t[0] for t in trig) if trig else 'ok'}{' WARN:' + ';'.join(warn) if warn else ''}")


def sample(st, with_stats):
    s = {"t": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "n": st["n"] + 1}
    st["n"] = s["n"]
    for name, fn in (("health", sec_health), ("container", sec_container), ("host", sec_host), ("queue", sec_queue), ("ops", sec_ops),
                     ("llm", sec_llm), ("logs", sec_logs), ("cons_marks", sec_cons_marks)):
        try:
            s[name] = fn()
        except Exception as e:
            s[name] = None
            s.setdefault("errors", []).append(f"{name}: {type(e).__name__}: {str(e)[:120]}")
    if with_stats:
        try:
            s["stats"] = sec_stats()
        except Exception as e:
            s.setdefault("errors", []).append(f"stats: {e}")
    try:
        s["obs"] = sec_obs(st)
    except Exception as e:
        s["obs"] = {"total": 0, "new": 0, "upd": 0, "hard": [], "review": [], "new_flags": [], "corpus": False}
        s.setdefault("errors", []).append(f"obs: {type(e).__name__}: {str(e)[:120]}")
    if s.get("errors") or any(s.get(k) is None for k in ("health", "container", "host", "queue", "ops", "llm", "logs", "cons_marks")):
        print("SAMPLE ERRORS:", s.get("errors"))
        s.setdefault("trig", [])
        for k, d in (("health", {"ok": False}), ("container", {"started": "", "restarts": 0, "status": "unknown", "image": "", "oom": "false"}),
                     ("host", {"load": [0, 0, 0], "mem_avail_mb": 0}),
                     ("queue", {"pending": 0, "processing": 0, "pending_ready_oldest_s": 0, "processing_oldest_s": 0, "foreign_processing": 0, "deferred": 0, "by": {}}),
                     ("ops", {"done": [], "done10m": {}, "done20m": -1, "failed": []}), ("llm", {"rows": [], "errs": [], "last_cons": [], "last_retain": []}),
                     ("logs", {k: 0 for k in list(LOG_PATS) + ["STUCK_STACK_10m", "ELB_10m", "cons_complete_n", "lines"]}), ("cons_marks", [])):
            if s.get(k) is None:
                s[k] = d
    trig, warn = evaluate(s, st)
    s["trig"] = trig
    s["warn"] = warn
    with open(LOG_F, "a") as f:
        f.write(json.dumps(s, ensure_ascii=False) + "\n")
    return s, trig, warn


def cmd_sample(a):
    st = load_state()
    s, trig, warn = sample(st, with_stats=(st["n"] % 5 == 0))
    save_state(st)
    print(line(s, trig, warn))
    extras(s, trig, warn)
    return 3 if trig else 0


def extras(s, trig, warn):
    for t in trig:
        print(f"  TRIGGER {t[0]}: {t[1]}")
    for r in s["obs"]["review"]:
        print(f"  REVIEW obs {r['bank']}:{r['id']}({r['scope']}) {json.dumps(r['flags'], ensure_ascii=False)[:200]}")
    for e in s["llm"]["errs"][-3:]:
        print(f"  llm error {e['t']} {e['operation']}/{e['scope']} {e['s']}s {e['err'][:100]}")
    for e in (s["logs"].get("elb_events") or [])[-2:]:
        print(f"  ELB {e['t']} {e['s']}s {e['where']}")
    if s.get("stats"):
        print("  stats:", json.dumps(s["stats"], ensure_ascii=False))


def cmd_loop(a):
    st = load_state()
    t_end = time.time() + a.seconds
    rc = 0
    while True:
        s, trig, warn = sample(st, with_stats=(st["n"] % 5 == 0))
        save_state(st)
        print(line(s, trig, warn), flush=True)
        extras(s, trig, warn)
        sys.stdout.flush()
        if trig and a.stop_on_trigger:
            return 3
        if time.time() + a.every > t_end:
            return rc
        time.sleep(a.every)


def cmd_corpus(a):
    cut = T1
    sqls = [f"select text from memory_units where created_at < '{cut}'",
            f"select original_text from documents where created_at < '{cut}' and original_text is not null",
            f"select chunk_text from chunks where created_at < '{cut}'"]
    uni, bi = set(), set()
    n = 0
    for sql in sqls:
        p = subprocess.run(["docker", "exec", "postgresql", "psql", "-U", "postgres", "-d", "hindsight", "-At", "-c", sql],
                           capture_output=True, text=True, timeout=300)
        if p.returncode != 0:
            print("corpus error:", p.stderr[:200]); return 1
        u, b = kanji_grams(p.stdout)
        uni |= u; bi |= b; n += len(p.stdout)
    json.dump({"uni": sorted(uni), "bi": sorted(bi), "chars": n, "cut": cut}, open(CORPUS_F, "w"), ensure_ascii=False)
    print(f"corpus: {n} 文字から 漢字 {len(uni)} 字、2字連 {len(bi)} 種")
    return 0


def cmd_summary(a):
    s = {"t": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
    s["container"] = sec_container(); s["health"] = sec_health()
    s["queue"] = sec_queue(); s["ops"] = sec_ops(); s["llm"] = sec_llm(); s["logs"] = sec_logs(); s["cons_marks"] = sec_cons_marks()
    s["stats"] = sec_stats()
    rows = []
    for l in open(LOG_F):
        try:
            rows.append(json.loads(l))
        except Exception:
            pass
    s["samples"] = len(rows)
    s["max_load1"] = max((r["host"]["load"][0] for r in rows if r.get("host")), default=None)
    s["max_pending"] = max((r["queue"]["pending"] for r in rows if r.get("queue")), default=None)
    s["max_proc_oldest_s"] = max((r["queue"]["processing_oldest_s"] for r in rows if r.get("queue")), default=None)
    s["max_pending_oldest_s"] = max((r["queue"]["pending_ready_oldest_s"] for r in rows if r.get("queue")), default=None)
    s["triggers_seen"] = sorted({t[0] for r in rows for t in (r.get("trig") or [])})
    st = load_state()
    s["obs_audited"] = len(st["audited"])
    print(json.dumps(s, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("sample")
    lp = sub.add_parser("loop"); lp.add_argument("--seconds", type=int, default=570); lp.add_argument("--every", type=int, default=60)
    lp.add_argument("--stop-on-trigger", action="store_true")
    sub.add_parser("corpus"); sub.add_parser("summary")
    args = ap.parse_args()
    sys.exit({"sample": cmd_sample, "loop": cmd_loop, "corpus": cmd_corpus, "summary": cmd_summary}[args.cmd](args))
