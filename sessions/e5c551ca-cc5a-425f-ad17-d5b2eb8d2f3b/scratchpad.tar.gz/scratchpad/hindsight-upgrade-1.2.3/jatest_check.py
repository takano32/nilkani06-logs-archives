# ja-test（試験用の bank）にだけ撃つ。同期の retain → recall → 統合の観察ができるのを待つ。本番の bank には撃たない。
import json, sys, time, urllib.request
BASE = "http://127.0.0.1:18888/v1/default/banks/ja-test"
def call(method, path, body=None, timeout=300):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method, headers={"Content-Type": "application/json"})
    t = time.time()
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r), time.time() - t
stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
doc_id = f"upgrade-123-check-{stamp}"
text = "来週の水曜日に京都へ日帰りで出かける予定。嵐山の竹林を歩いて、昼は湯豆腐を食べたい。"
r, dt = call("POST", "/memories", {"items": [{"content": text, "document_id": doc_id, "context": "upgrade-1.2.3 check"}], "async": False})
print(f"retain(sync) {dt:.1f}s ->", json.dumps({k: r.get(k) for k in ("success", "items_count", "usage")}, ensure_ascii=False)[:300])
r, dt = call("POST", "/memories/recall", {"query": "京都に行くのはいつ？", "budget": "low", "max_tokens": 2048})
res = r.get("results") or []
hit = [x for x in res if doc_id == x.get("document_id")]
print(f"recall {dt:.2f}s -> {len(res)} 件, 今回の文書から {len(hit)} 件, 上位の意味スコア {[round((x.get('scores') or {}).get('semantic') or 0, 2) for x in res[:3]]}")
print("doc_id", doc_id)
open("jatest_doc_id.txt", "w").write(doc_id)
