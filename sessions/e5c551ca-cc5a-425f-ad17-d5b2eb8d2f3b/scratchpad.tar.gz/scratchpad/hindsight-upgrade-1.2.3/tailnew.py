# watch-loop.out の、前回読んだ続きだけを出す。引数: 待つ秒数（最大 170）。TRIGGER が出たら早く抜ける。
import os, sys, time
OFF = "tailnew.off"
wait = min(int(sys.argv[1]) if len(sys.argv) > 1 else 0, 170)
off = int(open(OFF).read()) if os.path.exists(OFF) else 0
t0 = time.time()
while True:
    size = os.path.getsize("watch-loop.out")
    txt = open("watch-loop.out", encoding="utf-8").read()
    new = txt.encode("utf-8")[off:].decode("utf-8", "ignore")
    if time.time() - t0 >= wait or "  TRIGGER " in new:
        break
    time.sleep(5)
open(OFF, "w").write(str(len(txt.encode("utf-8"))))
for l in new.splitlines():
    print(l[:330])
print("--", time.strftime("%H:%M:%S", time.gmtime()), "UTC")
