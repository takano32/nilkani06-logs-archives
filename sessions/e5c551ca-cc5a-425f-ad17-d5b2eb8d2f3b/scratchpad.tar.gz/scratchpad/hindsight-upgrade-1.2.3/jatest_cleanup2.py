# ja-test の試験用の事実（document_id が upgrade-123-burst-% のもの）を PATCH で取り下げる。ja-test にだけ撃つ。
import json, subprocess, time, urllib.request
BASE = "http://127.0.0.1:18888/v1/default/banks/ja-test"
def psql(sql):
    return subprocess.run(["docker", "exec", "postgresql", "psql", "-U", "postgres", "-d", "hindsight", "-At", "-F", "|", "-c", sql], capture_output=True, text=True).stdout
ids = [x for x in psql("select id from memory_units where bank_id='ja-test' and fact_type<>'observation' and document_id like 'upgrade-123-burst-%'").split()]
print("取り下げる事実:", len(ids), "件")
for i in ids:
    req = urllib.request.Request(f"{BASE}/memories/{i}", data=json.dumps({"state": "invalidated", "reason": "upgrade 1.2.3 burst check cleanup"}).encode(), method="PATCH", headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        r.read()
print("PATCH 済み。20 秒待って確認")
time.sleep(20)
print(psql("select fact_type, to_char(updated_at,'MM-DD HH24:MI'), left(replace(text,E'\\n',' '),90) from memory_units where bank_id='ja-test' and (updated_at >= '2026-11-24T03:52:31Z' or created_at >= '2026-11-24T03:52:31Z') order by fact_type, created_at"))
