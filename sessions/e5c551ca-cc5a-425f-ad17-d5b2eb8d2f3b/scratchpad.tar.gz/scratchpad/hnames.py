import re,sys
N={1:'systemd unit の実物',2:'いまのプロセス',3:'mem_snapshot の再現',4:'Discord プラグインの該当行',5:'claude 本体の文字列',6:'Discord Gateway 公式',
7:'herdr の一次資料',8:'headless-probe の実測',9:'headless-probe2 の実測',10:'systemd の一次資料',11:'箱の状態',12:'MCP の所在',
13:'XDG_CONFIG_HOME での隔離',14:'ワークスペース・早撃ち・環境変数',15:'claude をペインで起こす',16:'本文の注入と origin',
17:'ansi でプレースホルダーと残骸を見分ける',18:'agent prompt は残骸を見ない',19:'清潔な入力欄での /effort',20:'アタッチ判定',
21:'HERDR_CONFIG_PATH は置き場を動かさない',22:'/quit でペインが bash に戻る',23:'SIGTERM で孫まで消える',24:'後始末・残骸・秘密・副作用',
25:'claude-pane-probe.sh の実行',26:'herdr-boot.bash で環境を起こす',27:'blocked で見送り',28:'idle で送出',29:'残骸を Ctrl-U で消してから送る',
30:'アタッチ中の残骸で中止',31:'working で見送り',32:'idle の画面差分',33:'dream.js の herdr 経路',34:'再起動の窓',35:'herdr-boot.bash の畳み方',
36:'unit ファイルの行末コメント'}
EV='skills/ops/herdr/evidence.md'
def q(n,inq): return ('『%s』' if inq else '「%s」')%N[n]
G={(13,25):'段1 の使い捨て試験',(26,36):'段2 の使い捨て試験',(13,24):'段1 の使い捨て試験',(1,35):'証拠の一覧',(1,36):'証拠の一覧'}
E=r'(?<![A-Za-z0-9_.\[/\-])E(\d{1,2})(?:-([A-Z]|\d+))?(?![\d\w])'
def conv(path,s):
    out=[]; code=path.endswith(('.py','.sh','.js'))
    for line in s.split('\n'):
        if path==EV:
            m=re.match(r'^## E(\d+)〜E(\d+)\. (.*)$',line)
            if m: out.append('## '+m.group(3)); continue
            m=re.match(r'^## E(\d+)\. (.*)$',line)
            if m:
                out.append('## '+N[int(m.group(1))]); out.append(''); out.append('**'+m.group(2)+'**'); continue
        def rng(m):
            a,b=int(m.group(1)),int(m.group(2))
            return '「%s」'%G[(a,b)] if (a,b) in G else '「%s」から「%s」まで'%(N[a],N[b])
        line=re.sub(r'(?<![A-Za-z0-9_.\[/])E(\d{1,2})〜E?(\d{1,2})(?!\d)',rng,line)
        res=[];pos=0
        for m in re.finditer(E,line):
            n=int(m.group(1))
            if n not in N: continue
            seg=line[pos:m.start()]
            pre=''.join(res)+seg
            inq=pre.count('「')>pre.count('」')
            rep=q(n,inq)
            if m.group(2): rep+='の'+m.group(2)
            seg=re.sub(r'(evidence(\.md)?`?)\s*$',r'\1 の',seg)
            res.append(seg+rep); pos=m.end()
        res.append(line[pos:]); out.append(''.join(res))
    return '\n'.join(out)
for p in sys.argv[1:]:
    s=open(p).read(); t=conv(p,s)
    if t!=s: open(p,'w').write(t); print('changed',p)
