import re,subprocess,sys
sys.path.insert(0,'/tmp/claude-1001/-home-takano32-nilkani06/e5c551ca-cc5a-425f-ad17-d5b2eb8d2f3b/scratchpad')
import secnum
files=secnum.scope_files(); secnum.build_alias(files)
for f in sys.argv[1:]:
    t=subprocess.run(['git','-C',secnum.ROOT,'show','632861c8:'+f],capture_output=True,text=True).stdout
    for i,l in enumerate(t.split('\n')):
        ms=list(secnum.REF.finditer(l))
        if len(ms)<2: continue
        ext=False
        for m in ms:
            tm=secnum.TOK.search(l[:m.start()])
            r=secnum.resolve(tm.group(1),f,files) if tm else None
            if r and r!=f: ext=True
            elif ext and not r:
                print(f,i+1,l[max(0,m.start()-60):m.end()+20]); break
