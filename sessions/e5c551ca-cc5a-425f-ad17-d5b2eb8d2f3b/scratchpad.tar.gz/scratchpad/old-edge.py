#!/usr/bin/env python3
"""文章を音声ファイルにする（Edge TTS）。手順書ではなく道具にした版。

**⚠️ エンジンに依らない部分は `_tts.py` にある**（2026-08-20 に切り出した。
takano32 指示・会話チャンネル＝「_tts.py がきちんと分割できてることを試験したいだけ」）。
このファイルに残っているのは**Edge にしか無いもの**だけ＝声の名前、字幕、速さと音量と高さ。
読みを直す仕組み、声と文の食い違いの検出、出力の確かめ、自己検査は `_tts.py`。

**なぜ道具にするか**（takano32 指示 2026-08-20・会話チャンネル＝「edge-tts.py を skills tts に
作成してコードで動作を保証しておかない？」）＝**手順書にしか無いものは、読む側が毎回組み直す。**
組み直すたびに、下の3つが落ちる。

  1. **声の既定**。素の `edge-tts` の既定は `en-US-EmmaMultilingualNeural`＝**英語の声**で、
     日本語を渡すと潰れる（実測＝同じ文で 72,864 バイト対 10,656 バイト）。
     **ここでは既定を日本語にしてある。**
  2. **食い違いの検出**。日本語の文に日本語でない声を当てたら、**走る前に止める。**
  3. **出力の確かめ**。書けたファイルが小さすぎたら、**成功と数えない。**

**⚠️ サブプロセスを呼ばない**（takano32 指示・同日＝「サブプロセスをよばずに書けたらベター」）。
`edge_tts.Communicate` を直に使う。CLI の版が変わっても、この道具の振る舞いは変わらない。
**MeCab も同じで `import MeCab`**（takano32 指示 2026-08-20＝「import で使うこと」）。

**合成の前に MeCab で助詞だけ直せる**（`--kana`。既定は切り）。
**⚠️ 直すのは「直す理由がある語」だけで、原文はそのまま残す**（takano32 指示 2026-08-20・
会話チャンネル＝「MeCab は使うけど、誤読しない部分は元の文章を使いたいなあ」）。
理由がある語＝**表層形と発音が食い違う助詞**（`は`→`わ`、`へ`→`え`）。

    彼はGitHubへpushした。今日は10時に会議です。
    → 彼わGitHubえpushした。今日わ10時に会議です。    ← 漢字はそのまま残る

**⚠️ 全文をかなに開くのは `--kana-all`**（2026-08-20 の `--kana` がこれだった）。
**開くと、Edge TTS が漢字から取っている読みを捨てて、MeCab の読みに賭けることになる。**
実測＝IPADIC は「二行目」を「にこーめ」（正しくは「にぎょうめ」）、
「羽田」を「はた」（人名の姓として引く）と読む。**捨てた漢字は戻ってこない。**

使い方:
    python3 skills/tts/edge-tts.py "読ませたい文" --out out.mp3
    python3 skills/tts/edge-tts.py --file long.txt --voice ja-JP-KeitaNeural --out out.mp3
    python3 skills/tts/edge-tts.py "文" --out out.mp3 --srt out.srt   # 字幕も
    python3 skills/tts/edge-tts.py "本日は晴天なり" --kana --out out.mp3      # 助詞だけ直す
    python3 skills/tts/edge-tts.py "本日は晴天なり" --kana-all --out out.mp3  # 全文を開く
    python3 skills/tts/edge-tts.py "本日は晴天なり" --out out.mp3             # 何もしない（既定）
    python3 skills/tts/edge-tts.py --list-voices ja
    python3 skills/tts/edge-tts.py --self-test

⚠️ 走らせるのは `$APP_DIR/.local/python-packages` の python
   （`edge_tts` はそこにしか入っていない。`coding-conventions.md` §2）:
    .local/python-packages/bin/python3 skills/tts/edge-tts.py …

終了コード: 0=成功 / 2=使い方の誤り（MeCab が無いのに --kana／--kana-all を指定した場合も 2）
            3=合成に失敗 / 4=自己検査に失敗
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _tts  # noqa: E402  ← 置き場を sys.path に足してから読む

try:
    import edge_tts
except ImportError:  # pragma: no cover
    sys.exit("edge_tts が無い。`.local/python-packages/bin/pip install edge-tts` で入れる "
             "（⚠️ 入れる前にひとこと言う＝tts/SKILL.md §2）")

DEFAULT_VOICE = "ja-JP-NanamiNeural"


class EdgeEngine(_tts.Engine):
    """Microsoft Edge の読み上げ。**声を名前で指定する。**"""

    name = "edge-tts"
    default_voice = DEFAULT_VOICE
    voice_label = "声"
    # ⚠️ 陰性対照に使う声。**素の edge-tts の既定がこれ**＝この道具が塞いでいる罠そのもの。
    foreign_voice = "en-US-EmmaMultilingualNeural"
    supports_srt = True
    # ⚠️ 実測（2026-08-20）＝同じ趣旨の日本語で、声を指定すると 72,864 バイト、
    # 既定（英語の声）のままだと 10,656 バイト。**長さで気づける**。
    mismatch_note = "そのまま走らせると、別物が出てくる（実測＝出力が7分の1になった）。"
    # ⚠️ 実測＝MP3・48kbps・24kHz・モノラル（CBR なのでバイト数が長さに比例する）。
    bitrate = 48000
    # ⚠️ 読みの違いが長さに出る（実測 2026-08-20＝わ版 14,976 対 は版 15,264）。
    # だから自己検査の10番が撃てる。
    reading_shows_in_length = True
    epilog = ("⚠️ --rate を下げるときは = で繋ぐ（--rate=-20%）。空けると値がオプション名に見える。\n"
              "⚠️ 合成は Microsoft のサーバで行われる。読ませる文章は外へ出る。\n")

    def add_arguments(self, ap: argparse.ArgumentParser) -> None:
        # ⚠️ Edge にしか無い。gTTS には速さも音量も高さも無い（`slow` の入り切りだけ）。
        ap.add_argument("--rate", default="+0%", help="速さ（例 --rate=-20%%。⚠️ 下げるときは = で繋ぐ）")
        ap.add_argument("--volume", default="+0%", help="音量")
        ap.add_argument("--pitch", default="+0Hz", help="高さ")

    def synth_options(self, args) -> dict:
        return {"rate": args.rate, "volume": args.volume, "pitch": args.pitch}

    def synth(self, text: str, voice: str, out: str, *, srt: str | None = None,
              rate: str = "+0%", volume: str = "+0%", pitch: str = "+0Hz") -> int:
        """合成してファイルへ書く。書けたバイト数を返す。

        ⚠️ `save_sync` があるので asyncio を自分で回さなくてよい（字幕を出すときだけ stream を使う）。
        """
        comm = edge_tts.Communicate(text, voice, rate=rate, volume=volume, pitch=pitch)
        if srt is None:
            comm.save_sync(out)
        else:
            sub = edge_tts.SubMaker()
            with open(out, "wb") as f:
                for chunk in comm.stream_sync():
                    if chunk["type"] == "audio":
                        f.write(chunk["data"])
                    elif chunk["type"] in ("WordBoundary", "SentenceBoundary"):
                        sub.feed(chunk)
            with open(srt, "w", encoding="utf-8") as f:
                f.write(sub.get_srt())
        return os.path.getsize(out)

    def voice_exists(self, voice: str) -> bool | None:
        # ⚠️ Edge の声の一覧は**通信で取る**（実測 322件・0.55秒・2026-09-08）。
        # だから**失敗したときにしか引かない**＝成功経路の所要時間は変わらない。
        # ⚠️ 例外 `NoAudioReceived` は声の誤りに固有ではない（通信の失敗でも同じものが出る）ので、
        # 例外の名前だけで 2 を返してはいけない。**一覧に無いことを確かめてから返す。**
        try:
            import asyncio
            import edge_tts
            names = {v.get("ShortName") for v in asyncio.run(edge_tts.list_voices())}
            return voice in names
        except Exception:
            return None

    def list_voices(self, prefix: str | None) -> int:
        voices = asyncio.run(edge_tts.list_voices())
        rows = [v for v in voices
                if not prefix or v["ShortName"].lower().startswith(prefix.lower())]
        if not rows:
            print(f"（`{prefix}` で始まる声は見つからなかった）")
            return 0
        for v in sorted(rows, key=lambda x: x["ShortName"]):
            tags = ", ".join((v.get("VoiceTag") or {}).get("VoicePersonalities") or [])
            print(f"{v['ShortName']:<34} {v.get('Gender',''):<8} {tags}")
        return 0


if __name__ == "__main__":
    sys.exit(_tts.run(EdgeEngine()))
