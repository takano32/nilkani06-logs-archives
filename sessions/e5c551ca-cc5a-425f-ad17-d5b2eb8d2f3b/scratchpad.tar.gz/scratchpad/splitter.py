"""Split a SKILL.md at '## N.' headings into named files.
usage: splitter.py config.json [--dry]
config: {"dir": ".../skills/x", "files": {"2": ["status.md","status","desc"], ...},
         "keep": ["1"], "exclude_prefix": ["AGENTS.md ", "PLAN.md "], "intro": "table intro sentence"}
Sections not in files and not numbered stay in SKILL.md in order.
"""
import json,re,sys
cfg=json.load(open(sys.argv[1])); dry='--dry' in sys.argv
D=cfg['dir'].rstrip('/')+'/'
src=open(D+'SKILL.md').read()
L=src.split('\n')
# frontmatter end
fm_end=[i for i,l in enumerate(L) if l=='---'][1]
incode=False; heads=[]
for i,l in enumerate(L):
    if l.startswith('```'): incode=not incode
    if not incode and i>fm_end and re.match(r'^## ',l): heads.append(i)
first=heads[0]
secs=[]  # (num or None, start, end, title)
for k,h in enumerate(heads):
    e=heads[k+1] if k+1<len(heads) else len(L)
    m=re.match(r'^## (\d+(?:\.\d+)?)\.? +(.*)$',L[h])
    secs.append((m.group(1) if m else None,h,e,(m.group(2) if m else L[h][3:])))
# subheading map
sub={}  # 'N-M' -> (file, title)
num2file={}
for num,s,e,t in secs:
    if num and num in cfg['files']:
        fn=cfg['files'][num][0]; num2file[num]=fn
        for l in L[s:e]:
            m=re.match(r'^### (\d+)-(\w+)\. +(.*)$',l)
            if m: sub[m.group(1)+'-'+m.group(2)]=(fn,m.group(3))
keepnums=set(cfg.get('keep',[]))
for num,s,e,t in secs:
    if num and num in keepnums:
        for l in L[s:e]:
            m=re.match(r'^### (\d+)-(\w+)\. +(.*)$',l)
            if m: sub[m.group(1)+'-'+m.group(2)]=('SKILL.md',m.group(3))
keeptitle={num:t for num,s,e,t in secs if num in keepnums}
excl=cfg.get('exclude_prefix',[])
log=[]
def fix(text,cur,hist=False):
    def rep(m):
        pre=text[max(0,m.start()-25):m.start()]
        for x in excl:
            if pre.endswith(x): return m.group(0)
        pre2=text[max(0,m.start()-60):m.start()]
        for x in cfg.get('exclude_re',[]):
            if re.search(x+r'$',pre2): return m.group(0)
        key=m.group(1)+('-'+m.group(2) if m.group(2) else '')
        if m.group(2) and key in sub:
            fn,tt=sub[key]
            r=('`%s` の「%s」'%(fn,tt)) if fn!=cur else '「%s」'%tt
        elif m.group(1) in num2file:
            fn=num2file[m.group(1)]
            r='`%s`'%fn if fn!=cur else 'この文書'
            if hist: r='§%s（いまの %s）'%(m.group(1),r)
        elif m.group(1) in keeptitle:
            r=('`SKILL.md` の「%s」'%keeptitle[m.group(1)]) if cur!='SKILL.md' else '「%s」'%keeptitle[m.group(1)]
            if hist: r='§%s（いまの%s）'%(m.group(1),r)
        else:
            log.append(('UNMAPPED',cur,text[max(0,m.start()-40):m.end()+10].replace('\n',' '))); return m.group(0)
        log.append((cur,text[max(0,m.start()-40):m.end()+5].replace('\n',' '),'=>',r))
        return r
    return re.sub(r'§(\d+(?:\.\d+)?)(?:-(\w+))?',rep,text)
def demote(lines):
    out=[];incode=False
    for l in lines:
        if l.startswith('```'): incode=not incode
        if not incode:
            if re.match(r'^### \d+-\w+\. ',l): l=re.sub(r'^### \d+-\w+\. ','## ',l)
            elif l.startswith('#### '): l=l[1:]
            elif l.startswith('### '): l=l[1:]
        out.append(l)
    return out
newfiles={}
for num,s,e,t in secs:
    if num and num in cfg['files']:
        fn,name,desc=cfg["files"][num][:3]
        body=L[s+1:e]
        while body and body[-1]=='': body.pop()
        txt='---\nname: %s\ndescription: %s\n---\n\n# %s\n'%(name,desc,t)+'\n'.join(demote(body))+'\n'
        newfiles[fn]=fix(txt,fn)
# SKILL.md
pre='\n'.join(L[:first])
rows='\n'.join('| `%s` | %s |'%(v[0],v[3] if len(v)>3 else v[2]) for k,v in cfg['files'].items())
table='## どこに何があるか\n\n'+cfg['intro']+'\n\n| ファイル | 中身 |\n|---|---|\n'+rows+'\n\n'
rest=[]
inserted=False
for num,s,e,t in secs:
    if num and num in cfg['files']:
        if not inserted: rest.append(table); inserted=True
        continue
    chunk=L[s:e]
    if num: chunk=[re.sub(r'^## \d+(?:\.\d+)?\.? +','## ',chunk[0])]+chunk[1:]
    c='\n'.join(chunk).rstrip('\n')+'\n\n'
    rest.append(fix(c,'SKILL.md',hist=bool(re.search(cfg.get('hist_re','来歴|経緯の補足'),t))))
skill=fix(pre.rstrip('\n'),'SKILL.md')+'\n\n'+''.join(rest).rstrip('\n')+'\n'
for x in log: print(*x)
# coverage check
alltxt=skill+''.join(newfiles.values())
miss=[l for l in L if l.strip() and l not in alltxt and not re.match(r'^#',l)]
print('MISSING-LINES(not heading):',len(miss))
for l in miss: print('  ',l[:120])
if not dry:
    open(D+'SKILL.md','w').write(skill)
    for fn,t in newfiles.items(): open(D+fn,'w').write(t)
    print('written',list(newfiles))
