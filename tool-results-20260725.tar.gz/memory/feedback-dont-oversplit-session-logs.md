---
name: feedback-dont-oversplit-session-logs
description: セッションログを1〜2往復ごとの細切れで書き出さない。transcript警告hookの反復発火に過剰反応しない
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ff44cedc-eb8f-4fa4-b491-72237b5d32a9
---

2026-07-16の長時間セッションで、transcript サイズ警告hook（3MB超で発火、本来30分クールダウンのはず）が繰り返し出るたびに律儀に反応し、1〜2往復程度の小さな窓で `thinking.json` を書いてはbuild/render/commitする、というサイクルを何十回も繰り返した。半日で logs リポに35コミットも積んでしまい、takano32から「なんかメチャクチャにログの書き出ししてる？」と指摘された。

**Why**: [[feedback-json-is-canonical-log]]や[[feedback-prioritize-live-replies-over-background-chores]]は「書き出しを怠るな」という方向の教訓だったため、その反動で「警告が出たら即書く」を機械的に繰り返しすぎた。警告hookは同一セッション内で30分のクールダウンがあるはずだが、実際には短い間隔で何度も出ていた（クールダウンが機能していないか、閾値超過が続く限り出続ける仕様の可能性がある）。結果として、1つの会話の流れ（例：ブログ執筆→公開→ブクマの一連）が不必要に複数ログへ分断され、後から読んだときの一覧性・可読性がむしろ落ちた。

**How to apply**: transcript警告が出ても、直近の書き出しから十分な時間・内容が経過していないなら即座に反応せず、もう少し話が一区切りつくまで待ってからまとめて書く。目安として「1つの話題・1つの依頼が完了した単位」または「最低でも20〜30分・数往復分の内容が溜まった単位」でまとめる。警告は「そろそろ考えておいて」であって「今すぐ書け」の即時命令ではない、と読み替える。ただし[[feedback-prioritize-live-replies-over-background-chores]]は生きたまま＝会話が活発に動いている間はログ書き出しより返信を優先する、という優先順位は変わらない。
