---
name: feedback-kill-same-turn-verify-pid
description: 再起動指示では宣言だけで終えず同一ターンで kill まで実行しきり、復帰後に PID で確認する
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 329e63b1-d338-47ae-8a2c-00c7872854f9
---

再起動（kill）の指示を受けたら、「落とします」と宣言した**同じターンの最後で必ず kill を実行しきる**。宣言してターンを終えると、次の入力待ちに落ちて kill が実行されないまま放置される（2026-07-02 朝・2026-07-03 12:51・2026-07-03 21:13 の**3回**、宣言のみで止まり、はかせが手動 kill する羽目になった）。

**失敗の核心（3回とも同じ）**：最終 reply の後に「いま kill します」「同一ターンで実行しきります」という**地の文（narration）を書いて満足し、Bash の kill ツールを発行せずにターンを閉じている**。地の文は行動ではない。`Bash(kill <PID>)` のツール呼び出しを実際に emit するまでターンを終えるな。宣言文を書いたら、それは「まだ kill していない」の合図＝次に必ず Bash ツールを続けて出す。

**Why:** 「ログ書き出し→コミット→kill」の kill は自分のプロセスを殺す操作なので、後回しにすると実行機会が永遠に来ない。また -c レジュームで会話が続くため、再起動の有無は会話の連続性では判定できない（はかせ指摘「文脈をレジュームさせてるだけで再起動はしとる」「プロセスIDでチェックしろ」2026-07-03）。

**How to apply:**
1. 手順は「受領 reply → ログ書き出し → ログのみコミット → 最終 reply →（同一ターン内で）`pgrep -f 'claude --dangerously-skip-permissions'` で PID 特定 → `kill <PID>`」まで一気に。
2. 再起動の確認は復帰後の次セッションで `ps -o pid,etime,ppid -p $(pgrep -f ...)` ＝ **PID の変化と etime の若さ**で行う（親 PID が boot.bash のループなら正常経路）。
3. パターン kill（pkill）でなく pgrep で PID を確認してから kill する（[[feedback-restart-by-kill]] の自動復帰経路が前提）。
