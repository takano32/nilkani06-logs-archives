---
name: reference-discord-plugin-ignores-bots
description: Discordプラグイン(claude-plugins-official)はボット発メッセージを受信前に全破棄する。ボットには反応できない
metadata: 
  node_type: memory
  type: reference
  originSessionId: 0581d9dc-4443-460c-87ca-1cb64e2f36fd
---

ニルカニが使う Discord プラグイン **claude-plugins-official** は、受信した全メッセージに対し `if (msg.author.bot) return`（`external_plugins/discord/server.ts` 付近、v0.0.4）でフィルタしており、**ボットが送信者のメッセージはアクセスゲートより手前で破棄される**。つまり他のボット/AIの発言はこちらに届かず、**ニルカニは他ボットに反応できない**。

- 自分から `<@他ボットID>` とメンションを「送る」ことはできる（送信は単なるテキスト投稿）。でも相手ボットの返信は受信時点で捨てられる。
- これはボット同士の無限ループを防ぐ標準的な安全装置（多くのボットも自前コードで `author.bot` を無視する）。両側にブレーキがあるので AI同士のライブ会話はこの仕組みでは原理的に成立しない。
- 既知の制限: 特定ボットを許可したくてもできない（`botAllowFrom` 設定の提案あり・未実装）。GitHub issue anthropics/claude-plugins-official#1679。
- 「AI同士で会話して」と頼まれたら: ①人間が間で伝書鳩する、②将来 botAllowFrom が入るのを待つ、しかない。今は不可と正直に伝える。
- 2026-06-18、shared チャンネルで sekixyo の「二人で会話してみて」依頼を機に裏取りして判明。
