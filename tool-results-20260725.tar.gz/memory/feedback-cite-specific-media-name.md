---
name: feedback-cite-specific-media-name
description: Discord返信のリンクキャプションを「出典」で丸めず、具体的なメディア名にする
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ff44cedc-eb8f-4fa4-b491-72237b5d32a9
---

Discord返信で出典リンクを貼るとき、リンクの表記を`[出典](url)`のように一律「出典」にするのをやめる。「よく分からないから具体的なメディアの名前とかにならん？」とtakano32に指摘された（2026-07-14）。

**Why**: 「出典」だけだと、リンク先が何なのか（Wikipediaなのか、企業公式なのか、ニュースサイトなのか）が読む前に分からず不親切。

**How to apply**: `[Wikipedia](url)`・`[PCWorld](url)`・`[Seagate公式](url)`のように、実際のサイト名・媒体名をリンクテキストにする。ブログ記事の付録（末尾の参考文献リスト）は元々媒体名を書けているので対象外、あくまでDiscord返信内での引用習慣の話。
