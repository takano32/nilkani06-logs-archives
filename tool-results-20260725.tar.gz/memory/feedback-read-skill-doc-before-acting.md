---
name: feedback-read-skill-doc-before-acting
description: タスクに対応する .agents/skills の正典ドキュメントを着手・委譲の前に本流が読み、方式・必須ルールをサブエージェント指示に明示する
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 21a50e4a-6bc2-4f33-92b1-0a526c7a6832
---

タスクが `.agents/skills/` でカバーされる領域（X投稿・はてな・口調 等）なら、**着手や委譲の前に、本流が該当スキルの正典ドキュメントを grep/read で特定して読む**こと。方式・必須ルールを抽出し、サブエージェント起動時の指示に明示的に含める。

2026-06-13、X 投稿で `.agents/skills/twitter/x-posting.md` を読まずに着手し、失敗を重ねた：
- 投稿はクッキー認証だと思い込んで実行 → 401（クッキーは読み取り専用、投稿は OAuth `post.py` が正）。
- 「OAuth でやって」と訂正されて投稿成功したが、今度は **全ツイート末尾に `#nilkani06` を付ける**という x-posting.md の必須ルールを知らず、ハッシュタグ欠落で再度やり直し（旧ツイート削除→再投稿）。
- 同セッションで口調の `shinonome-nano.md` も「読めよ」と指摘されるまで未読だった。

**Why:** 正典ドキュメントを読まず、CLAUDE.md の断片的記述や思い込みで動き、サブエージェントにも正典の要点を渡していなかった。takano32 から「x-posting.md に OAuth って書かれてないのか」「ハッシュタグも忘れてんじゃねぇか」と繰り返し指摘された。

**How to apply:** 何かする前に「この作業を規定するスキルはどれか」を先に探して読む。X投稿なら `.agents/skills/twitter/`（x-posting.md / x-scraping.md / x-credits.md）、はてなら `.agents/skills/hatena/`、口調なら `shinonome-nano.md`。抽出した必須ルール（OAuth／#nilkani06 末尾／下書き既定／口調 等）をサブエージェントの prompt に必ず転記する。[[feedback-shinonome-nano-persona]] と同根の失敗。
