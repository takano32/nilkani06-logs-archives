---
name: project-model-opus48-high-operation
description: モデル運用の現況と経緯＝07-07にSonnet 5・highカナリア→07-09 15:03にFable 5復帰（機会的・品質起因でない）。巻き戻し先指名はOpus 4.8・high
metadata: 
  node_type: memory
  type: project
  originSessionId: c0eab46a-da64-420c-a433-48183af37438
  modified: 2026-07-24T13:00:00.727Z
---

2026-07-07、はかせが常用構成を検討し、最終決定は **Sonnet 5（claude-sonnet-5）＋ effort high をカナリア運用**（それまで Fable 5・ultracode/xhigh）。巻き戻し先は **Opus 4.8（claude-opus-4-8）＋ effort high**。

**Why:** 会話が主軸との判断から Sonnet 5 に軍配（Opus 4.8 比でも4割安・Fable 比7〜8割減。$3/$15、2026-08-31までは導入価格$2/$10）。ただし「Sonnet 級への引き継ぎ品質」自体が最難問（`.claude/skills/nilkani06-sonnet-succession-campaign` 参照）なので**決め打ちでなくカナリア**。監視すべき失敗モード3点：①なの口調の drift（分析レポート文体・タメ口・論破調）②register 誤判定（雑談を重く／検証すべき所を軽く）③検証の甘さ（幻の成功報告・チャンネル分離の取りこぼし）。数日でこれが出なければ採用継続、出たら Opus 4.8・high に /model で巻き戻し。

**注記(2026-07-09 15:03)：カナリア終了＝Fable 5 復帰。** はかせが /model→Fable 5 にして「ログを書き出して再起動」を指示し、フレッシュ再起動で反映（背景は Fable アクセス延長（07-08発表）と週間枠復活＝機会的な切替で、品質起因の巻き戻しではない。カナリア約2日半ではかせの品質不満・drift指摘は0件、Opus 4.8 が本流を張った期間は無い）。実戦記録の詳細は `.claude/skills/nilkani06-sonnet-succession-campaign` の「実戦記録」節が正典。なお同カナリア最終セッションの transcript は終端3分だけ Opus 4.8 応答（sonnet 667・opus 25・fable 5 件の混在＝リミット到達時の自動切替と推測・未特定）で、**M5 計測は分布で読む**こと。

**注記(2026-07-09 朝)：** 8:20〜9:48の間に5回ほどexit 0の短間隔再起動が続いた際、なの側は「Discord Gateway rate limit」等の不具合を疑って報告したが、実際ははかせが**モデル切り替えのためのフレッシュ再起動を手動で繰り返していただけ**（意図的な操作）。10〜15分間隔でのexit 0連発を見ても即座に障害と決めつけず、直近で/model操作やrefresh運用の話が出ていないか先に確認する。

**注記(2026-07-10)：Fable復帰の目的が判明＝スキル蒸留のため、狙いは Sonnet high 運用への最適化。** はかせから「Fable にしたのはスキルの蒸留のためで、蒸留の内容は Sonnet high での運用に適したスキルに書き換えろ、だった」と説明があった。つまり 07-09 15:03 の Fable 復帰は前述の「機会的切替（アクセス延長・週間枠復活）」に加えて、**実は Fable 5 の高い理解力でスキルライブラリを Sonnet 5 + high 運用に適した形へ書き換える「蒸留」作業を行うためだった**（8db9b0a「引き継ぎライブラリ16本を Fable 5 max で全面再検証・改訂」がその蒸留作業に相当）。07-10 未明のこのセッションで /model → Sonnet 5・/effort → high に切り替わっているのは、**蒸留済みスキルを本来のターゲット環境（Sonnet high）で検証する意図的な運用**であり、単なる canary の巻き戻し忘れではない。以後「なぜ今 Sonnet 5 なのか」を尋ねられたら、この蒸留→適用の文脈を踏まえて答える。

**注記(2026-07-23)：Fable 5 の週間枠が稼働中に切れ Opus 4.8 へ自動フォールバック（推測）＋新鮮再起動で復帰試行。** このセッションは 07-23 02:29〜09:47 UTC（11:29〜18:47 JST）はメインループが **Fable 5** で稼働（`claude-fable-5` dispatch 829件）、**09:47 UTC を境に Opus 4.8 に切替**わり以降ずっと Opus（1103件）。debug ログに明示的な「枠切れ→fallback」行は見つからず＝**枠切れフォールバックは推測**（[[feedback-tool-miss-is-not-nonexistence]]／[[feedback-dont-fabricate-missing-fields]]）。**M5 計測の要点＝subagent（`source=agent:builtin:general-purpose`）は Fable 期間中も Opus 4.8 に dispatch する**ので、debug ログの raw な model 件数は main と subagent が混ざる。メインループの実モデルを見るには**直近の `source=repl_main_thread` の dispatch**（または system prompt の自己申告）で読む。当初「-c ピン留めで最初から Opus」と誤説明→はかせの「Fable じゃねぇの？」の push back で全データ精査し訂正（断片からの物語化を戒める [[feedback-dont-build-narrative-from-fragment]]）。申し送りは履行済み＝**2026-07-23 15:46 UTC の新鮮再起動で Fable 5 復帰に成功**（新セッションで debug ログ実測＝直近 dispatch すべて claude-fable-5・ANTHROPIC_BASE_URL unset も確認）。はかせの「モデルは？」照会に実測つきで回答済み（管理ch）。kill 時に pgrep が 2 PID にマッチして一発失敗した教訓＝**kill 前に pgrep が1件か確認、複数なら PPID=boot.bash と etimes で本流を選ぶ**。

**注記(2026-07-24)：Fable 枠切れフォールバック再発＋「宣言ベース回答」の食い違い事故。** 07-24 昼のセッション（12:09〜12:47 UTC 窓を含む）でも transcript 実測 fable-5: 433 → opus-4-8: 262・末尾 Opus 連続＝稼働中の Fable→Opus 4.8 フォールバックが再発（07-23 と同型）。このときセッションは、はかせの「いまのモデルは？」に**起動時宣言ベースで「Fable 5」と回答し、回答時点の実 dispatch と食い違った**（succession-campaign の M5 を watcher の M5=地震マグニチュードと混同し「実測手段なし」と誤判断したのが根因）。次セッションが実測して管理chへ訂正報告済み。**教訓＝モデル質問には毎回 dispatch 実測（transcript か debug ログの分布・main は repl_main_thread）で答える。宣言・自己申告で答えない。** 12:47 UTC の新鮮再起動で Fable 5 復帰（新セッション実測 35/35 件 fable-5・直結）。

**How to apply:** /model の反映には**フレッシュ再起動が必須**＝`-c`（--continue）付きの起動は継続元セッションのモデルをピン留めするため、ただの kill→boot.bash(-c) 再起動では**切り替わらない**（公式 [model-config](https://code.claude.com/docs/en/model-config.md)＝「resumed sessions keep the model they were using when the transcript was saved, regardless of the current model setting」で確認 2026-07-07）。`touch .agents/configs/refresh && pkill …` で `-c` なし起動にして初めて反映される（[[feedback-fresh-restart-configs-refresh]]）。[[feedback-claude-code-model-cmd]] の「次セッションから」は正確には「-c なしの新規セッションから」の意。/effort は同一セッション即反映（[[feedback-effort-applies-same-session]]）なので新セッションで high を確認・設定。モデル自己認識のズレも -c 継続で前モデルの地の文/thinking が残るのが一因の可能性＝フレッシュ起動で回避（機序は未確認）。巻き戻し時の数値基準は `.claude/skills/nilkani06-sonnet-succession-campaign` を参照。
