---
name: feedback-claude-code-model-cmd
description: Claude Code の /model コマンドは次セッションから有効・現セッションには効かない
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 27582471-7181-4271-b8b4-d44ee88d216c
---

`/model` コマンドは「saved as your default for new sessions」と表示される通り、**次のセッション開始時から有効**。現在のセッションのモデルは変わらない。

**Why:** 2026-06-25 に「再起動なしでモデルを変えられる」と断言して間違え、takano32 に訂正された。確認せずに CLI の仕様を断定した。

**How to apply:** Claude Code の CLI 機能についてはかせから質問されたとき、記憶だけで断定しない。コマンド出力（`local-command-stdout`）やドキュメントで確認してから答える。
