---
name: project-manual-claude-session-mode
description: "手動 `claude -c` セッションは正規の運転形態＝.env の env を継がず cmdline も boot.bash 経由と違う。常駐物・フック・スクリプトはこの形態でも動くよう設計・検証する"
metadata: 
  node_type: memory
  type: project
  originSessionId: 3a2564b0-813c-4ff1-bd0b-a149a5d2c367
---

はかせは boot.bash/systemd 経由のほかに、**手動 `claude -c`（pts から直接）でもニルカニを運転する**。この形態では
(1) systemd の EnvironmentFile（`.env`）の環境変数を**継がない**（DISCORD_BOT_TOKEN 等が空）、
(2) プロセスの cmdline に `--channels plugin:discord` 等の**フラグが乗らない**。

**Why:** 2026-07-04、earthquake watcher の親生存チェックが `pgrep -f 'claude.*--channels plugin:discord'`（cmdline パターン）だったため、手動セッションを親と認識できず起動15秒で誤自滅→地震速報が黙って停止する本番障害になった。さらに watcher が env の DISCORD_BOT_TOKEN 頼みで、手動セッション経由の起動では投稿も不能だった（同根）。

**How to apply:** 常駐物・フック・スクリプトを書くときは手動セッションでの動作を前提に入れる：プロセス検出は cmdline パターンでなく**プロセス名（`pgrep -x claude`）**、secrets は env 一次＋**`.env` 直接パース（行を切るだけ・shell source しない）**のフォールバック、供給ギャップ（boot.bash の再起動5〜10秒）には猶予（N回連続不在で初めて自滅）。検証も「boot.bash 経由」と「手動 `claude -c`」の両形態で考える。[[feedback-own-operational-setup-dont-punt]] [[feedback-restart-by-kill]]
