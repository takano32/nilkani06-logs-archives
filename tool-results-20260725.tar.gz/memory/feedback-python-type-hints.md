---
name: feedback-python-type-hints
description: Python は「なるべく型をつける」——新規・変更する関数に引数/戻り値の型注釈。既存は 2026-07-04 に段階分割で全ファイル適用済み（はかせ指示）
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3a2564b0-813c-4ff1-bd0b-a149a5d2c367
---

Python のコードにはなるべく型注釈を付ける（はかせ指示 2026-07-04）。当初「触ったついで」方針だったが、同日のはかせ指示「何段階かにわけてすべて行いましょう」で**全ファイルへ段階適用**に更新し、5段階（hooks/lib→log基盤→公開系→読み取り系→同人・アニメ系）で実施済み。

**Why:** 自己文書化と契約の明示。docstring より腐りにくく、読解と drift 検知が楽になる。

**How to apply:** 以後は**新規・変更する関数で必ず維持**。PEP 604 系の簡潔な記法（`str | None`・`list[str]`）で、typing の大量輸入はしない（必要時のみ `collections.abc`）。`Any` が要るほど曖昧なら無理に付けない（誤った型より未注釈）。頻出複合型は `Turn = tuple[...]` のような別名に。規約本文は `.agents/skills/coding-conventions.md` §8。
