---
name: feedback-restart-by-kill
description: 再起動は2階層——systemd サービスの再起動(systemctl)は人間が手動、claude プロセスの kill は自動復帰(boot.bash が5秒で再起動)。AI は systemd に触れない。管理チャンネルからの通常の再起動は AI 自身が kill で実行する（人間がやるのは「メンテナンス」等の特別時のみ）
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c96b8d9b-34b2-4452-8faa-87afb0b2d460
---

再起動には2階層あり、混同しないこと（2026-06-13 に takano32 が「サービスの再起動は人間、プロセスのキルは自動」と明確化）：

- **systemd サービス（`nilkani06.service`）の再起動 = takano32（人間）が手動で行う。** `systemctl restart nilkani06` は人間の操作で、**AI は systemd を触らない。**
- **`claude` プロセスの kill = 自動復帰の経路。** claude を kill すれば boot.bash が5秒後に自動で再起動する。これが通常の（軽い）再起動パスで、こちらは自動扱い。

.env への追記など稼働中プロセスへの反映が必要なときは、`systemctl` ではなく claude プロセスの kill（→boot.bash 自動復帰）で行う。systemd サービス側には触れない。

**管理チャンネルからの再起動は AI 自身が実行する（2026-06-20 takano32 明確化）:** 管理チャンネル（chat_id 1509823187293048884）で「再起動して／再起動しておこう」等が出たら、**defer・確認待ちをせず、AI が自分で claude プロセスを kill して自動復帰させる**（必ずセッションログを commit 済みにしてから kill する）。人間が手動でやるのは「メンテナンスする」等の特別なときだけ。systemd には依然として触れない。

**経緯:** 2026-06-12「再起動して」に `systemctl restart` を実行→「プロセスの kill でやって」と方法を訂正された。2026-06-13、いったん AI が「再起動は一切しない（kill も systemctl も）」と過剰に解釈してしまい、takano32 に「違う。サービスの再起動は人間、プロセスのキルは自動」と階層を再訂正された。CLAUDE.md のデプロイ手順からも systemctl restart は除去済み。
