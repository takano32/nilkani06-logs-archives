---
name: feedback-write-analysis-json-directly
description: ログの thinking.json は Write で直接書く。組み立て用の使い捨て python（/tmp/make_analysis_*.py）を毎回作らない
metadata:
  node_type: memory
  type: feedback
  originSessionId: 0581d9dc-4443-460c-87ca-1cb64e2f36fd
  modified: 2026-07-22T08:58:57.246Z
---

セッションログを書くとき、`build_json.py --thinking` に渡す **`thinking.json` は Write ツールで直接書く**（フィールド名・入力ファイルとも `analysis`→`thinking` に改名済み 2026-06-22）。`json.dump` で組み立てるだけの使い捨て python（`/tmp/make_analysis_*.py`）を毎回作らない。**置き場は `logs/thinking.json`**（log 関連なので logs 配下。logs リポの `.gitignore` 済み＝コミットされない・毎回上書き）。

**Why:** 2026-06-22、はかせに「まいかい `/tmp` に python 作ってるじゃん、あれなんなの？」と指摘された。長い日本語＋引用符＋`[[リンク]]` のエスケープ回避で python 辞書→`json.dump` していたが、それは Write で直接 JSON を書けば済む**余計な一手間**（ファイルも2個→1個に減る）。置き場も、log 関連なので `/tmp` でなく `logs/thinking.json` がよい（はかせ提案）。

**How to apply:**
1. thinking 入力は **`logs/thinking.json` を Write で直接**作る（python の組み立てスクリプトを介さない）。logs リポで gitignore 済みなのでコミットされない。
2. 複数行・全角・`[[リンク]]` は普通に書いてよい（生 UTF-8）。**ただし文中の強調・引用に半角ダブルクオート `"` を使わない**＝JSON 文字列の区切りと衝突して `Expecting ',' delimiter` でパース失敗する。強調は**全角『』「」**を使う（どうしても半角が要るなら `\"` にエスケープ）。2026-07-22 に同一セッションで3回やらかした（Log4/5/6）＝毎回 build 失敗→修正の往復が発生。Write する前に、本文中の `"` を『』に置換したか一度見る。壊れたら `python3 -c "import json;json.load(open('logs/thinking.json'))"` で位置を特定し、in-content の `"` を `\"` にエスケープすれば直る。
3. これは「できるからやる」ではなく無駄を削る方向（[[feedback-necessity-over-capability]]）。テスト用の使い捨てフィクスチャは別（検証目的なら可、終わったら消す）。
