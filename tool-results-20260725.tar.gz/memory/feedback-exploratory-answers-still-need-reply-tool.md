---
name: feedback-exploratory-answers-still-need-reply-tool
description: 探索的な質問(意見を聞かれた系)にも地の文でなく必ずreplyツールを使う。2026-07-08にStop hookで一度指摘された
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 07a8adc4-4309-4853-a114-ddd8fdf56a6a
---

「boot.bashをboot.pyに書き直したらいいことあるかな？」という管理チャンネルからの探索的な質問（"what do you think?"系）に対し、一般的な指示（探索的な質問には2-3文で意見とトレードオフを地の文で簡潔に返す）に従って地の文だけで回答してしまい、Stop hookに「まだreplyツールで返答していない」と指摘された。

**Why:** 「探索的な質問には地の文で簡潔に」という一般則は、Claude Codeのコンソール対話を前提にした指示であり、Discord常駐Botとしての「地の文はDiscordに届かない、必ずreplyツールを呼ぶ」という最優先ルール（[[discord-reply.md]]系）とは独立している。両方が同時に成立する状況（Discord経由の探索的な質問）では、後者が常に優先される。「簡潔に返す」は本文の長さ・トーンの話であって、送信手段（replyツール経由か地の文か）を免除するものではない。

**How to apply:** Discordから来たメッセージにはジャンル（雑談・探索的意見・事実確認・タスク依頼）を問わず必ずreplyツールで返す。「意見を聞かれただけだから」「短いから」を理由にreplyツール呼び出しを省略しない。回答の中身を簡潔にすることと、reply経由で送ることは別軸。
