---
name: feedback-json-is-canonical-log
description: セッションログはJSONが原本・MDは派生。JSONを絶対落とさない（欠けたらtranscriptからbackfill）
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 0581d9dc-4443-460c-87ca-1cb64e2f36fd
---

セッションログの2形式は対等でない：**JSON が会話の逐語（一次・原本）、MD はその要約（派生ビュー）**。JSON→MD は再生成できるが、MD→JSON（逐語復元）はできない。

**Why:** 2026-06-19、最近のセッションで MD だけ書いて JSON を省く運用になり、51セッション分の JSON が欠落していた。これは「復元できる方(MD)を残し、復元できない方(JSON)を捨てる」逆運用。takano32 の「MD は JSON から生成できるんだよね？」で気づいた。

**How to apply:** 毎セッション必ず JSON を書く。片方しか書けなくても先に JSON。欠けたら稼働中 transcript（`~/.claude/projects/<proj>/<id>.jsonl`）から backfill：全レコード本文の `<channel …>` ブロックを message_id で重複排除して user 発言に、assistant は text＋reply ツール本文を抽出、harness ラッパー（task-notification / subagent の最終報告 / スラッシュコマンド内部）は user に混ぜない、生成物は必ず検証。transcript が消えると逐語復元は不可なので欠けに気づいたら早めに。詳細は `.agents/skills/log.md`。関連：[[feedback-no-unapproved-commits]]（ログのコミットは事前承認の例外）。
