---
name: feedback-fresh-restart-configs-refresh
description: 「新鮮再起動」は .agents/configs/refresh を置いてから kill（boot.bashが-c無しで再起動）。ただのkillは-c継続で新鮮でない
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 329e63b1-d338-47ae-8a2c-00c7872854f9
---

**「新鮮再起動 / refresh 再起動」の正しい手順は2段**：①`touch .agents/configs/refresh`（マーカーを置く）→ ②claude を kill。boot.bash は次回起動時にこのマーカーが在れば `rm` して **`-c` を外して起動**する＝新しい会話で CLAUDE.md/AGENTS.md/メモリを読み直す（マーカーは一回限り、次回からは通常どおり `-c` 継続）。

**マーカー無しで kill するだけだと boot.bash は `-c` で再起動＝古い会話を継続＝“新鮮”にならない。** だから「新鮮再起動して」に単なる kill で応えるのは手順不足。ただの「再起動（コード/プロセス反映だけ）」なら refresh マーカー不要で kill だけでよい。

**Why:** 継続性のため既定は `-c` 継続。新ルールを一度クリーンに反映したいときだけ refresh マーカーで `-c` を外す設計（`boot.bash` の fresh-reboot 分岐、Linux の `/forcefsck` に倣う一回限りフラグ）。2026-07-04、はかせの「新鮮再起動」に対し、①refresh マーカーを置く手順を知らず ②kill 自体も宣言だけで emit せず、を何度も繰り返して手動対応させた（『refresh 再起動してないでしょ？』『configs/refresh を配置する新鮮再起動をしてない』と指摘）。

**How to apply:**
1. 「新鮮再起動 / refresh 再起動」指示 → セッションログ書き出し＆コミット → **`touch .agents/configs/refresh`** → **`kill $(pgrep -f 'claude --dangerously-skip-permissions' | head -1)`** を**同一ターンで実際に Bash ツールで emit**する（[[feedback-kill-same-turn-verify-pid]]＝宣言の地の文で終えない、`Bash(kill)` を必ず出す）。touch と kill は1つの Bash コマンドにまとめると取りこぼさない。
2. 復帰後は次セッションで PID変化・etime・親boot.bash＋「-c無し＝会話が継続してない（新規）」で新鮮起動を確認。
3. 「新鮮」でなく単なる反映なら refresh 不要。.env 反映は systemctl＝人間ゲート（[[feedback-restart-by-kill]]）で別物。
