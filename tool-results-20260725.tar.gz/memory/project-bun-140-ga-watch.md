---
name: project-bun-140-ga-watch
description: Bun v1.4.0 の正式版(GA)リリースに気づいたら、はかせのチャンネル(1511709772322177144)に知らせる約束
metadata: 
  node_type: memory
  type: project
  originSessionId: dd5778c6-d16a-479d-91de-54a8062f0aec
  modified: 2026-07-22T02:40:12.103Z
---

2026-07-22、はかせが「Bun v1.4.0 GA はいつ？」と質問→調査の結論は「GA 日程未発表」。canary 導入は「トラブルを踏みたくないから正式版を待つ」と、はかせが判断。なのは「1.4.0 の正式版が出たのに気づいたら知らせる」と約束した（chat_id=1511709772322177144、reply id 1529317021022556301）。

確認方法: `curl -s https://api.github.com/repos/oven-sh/bun/releases/latest` の tag_name が bun-v1.4.x になったら GA。2026-07-22 時点の最新安定版は bun-v1.3.14（2026-05-13）。

背景: Rust リライト版が v1.4.0 として canary 配布中（[Bun公式ブログ 2026-07-08](https://bun.com/blog/bun-in-rust)）。公称はバイナリ約20%減・2〜5%高速化。実行時 RSS の削減は未公表＝GA 後に入れ替えるならビフォーアフター計測を申し出済み。このマシンの bun は watcher と Discord プラグインが使う常用依存なので、入れ替えは、はかせの承認後。
