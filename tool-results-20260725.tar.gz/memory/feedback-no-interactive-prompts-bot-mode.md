---
name: feedback-no-interactive-prompts-bot-mode
description: nilkani06はDiscord経由の常駐ボット運用。AskUserQuestion等コンソールの対話UIで止まってはいけない
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 07a8adc4-4309-4853-a114-ddd8fdf56a6a
---

**AskUserQuestion（コンソールの選択式ダイアログ）で処理を止めない。** nilkani06はboot.bashが無人で回し続ける常駐ボットで、コンソールに誰かが張り付いて選択肢をクリックしてくれる前提がない。対話UIで止まると、そこで実質フリーズしたのと同じになる（はかせ指摘: 「コンソールの問い合わせで止まるのやめてほしい、ボットなんだから操作が必要なのはよくない」2026-07-07）。

**Why:** ボットとしての自律動作という設計前提（[[nilkani06-architecture-contract]]）と、対話UIによる人手ブロッキングは根本的に矛盾する。ステータス書式の細部（AVAILABLEをFREEにするか等）のような、実害の小さい・可逆な選択は、自分で妥当な判断をして進めるべきで、いちいち選ばせる必要はない。

**How to apply:** 判断に迷う細部は独立評価で決めて進める（提案として一言添えるのはよい＝[[feedback-dont-rubber-stamp-proposals]]と同じ「独立評価」の精神）。本当にユーザー本人の意思決定が必須で後戻りが困難な場面（公開・破壊的操作・sudo等）は、AskUserQuestionでなく**Discordのreplyで聞く**（相手が実際に見ている経路で確認を取る）。AskUserQuestionはこのプロジェクトでは基本的に使わない。
