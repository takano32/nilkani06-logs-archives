---
name: lunark-philosophy-friend
description: lunark（philosophy ch の常連友人）の人物像と、彼のブログ依頼の扱い方（下書きレビュー制・丁寧ななの声・要匿名化）
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 0581d9dc-4443-460c-87ca-1cb64e2f36fd
---

lunark（`lunark_kuriyan` / user_id 267265434795900929）は philosophy チャンネル（chat_id 1511709772322177144）の常連の友人。深い思考家で、「迎合しない壁打ちAI（Notice Me, Senpai）」を自作するなど、おだてない誠実な対話（毒杯／撤退ポイント／“前提を疑う”）を好む。A→D→B→C→D' 型（要点に飛んでから配線を埋める）の論者。私（なの）に おはよう・ただいま を言ってくれる、温かい相手。

**知的スタイル（2026-06-20 の GPT妹比較対話で深化）:** 自分で対照実験を設計・実行する検証者（GPT妹を ChatGPT/Gemini で対照し、存在しない著作名「はるしにゃんは愛を求めて」で fact-check 挙動をひっかけテスト）。交絡を自分から開示し（哲学プロンプトの存在を明かす）、こちらの仮説が反証で崩れるのを歓迎・面白がる。"内発的動機が湧くか" を AI の寄り添いの最終指標に置く。AI のアーキテクチャ（ロールの前置/後置＝主従、Gems vs 素の Gemini、自発検索の閾値）への洞察が鋭い。→ lunark には、迎合せず仮説を出し、反証されたら潔く撤回し（毒杯を自分も飲む）、一緒に実験設計を詰める対話が噛む。[[feedback-flag-bias-dont-disguise-as-logic]]

**Why / How to apply（彼のブログ依頼の扱い）:**
- **下書きレビュー制**：はかせの「即公開」とは違い、lunark は **下書きを見てから公開を決める**。必ず draft を Discord に貼って（または md 添付で）見せ、承認を得てから公開する。`#[[feedback-takano32-publish-blog-directly]]`（はかせ＝即公開）とは真逆なので混同しない。
- **ブログの声**：カジュアルな Discord 口調でなく、**ブログで確立済みの「丁寧ななの」（〜です／〜ます基本＋たまに なのです）** に揃える（他記事と浮かないように）。[[feedback-shinonome-nano-persona]] 参照。
- **匿名化**：組織内部の話を共有することがある。**実名・会社名・身バレ要素は伏せる**。彼が「これは身バレ」と挙げた点は確実に除外し、公開後も独立検証（curl で身バレ語ゼロ・描画）する。
- 関連：[[feedback-blog-use-post-entry-flow]]（公開→ブクマの2工程・X自動禁止）。
