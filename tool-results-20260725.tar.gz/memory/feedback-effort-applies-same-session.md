---
name: feedback-effort-applies-same-session
description: /effort は/modelと違い同一セッション内でも即座に反映される。回答が浅いと感じたらeffortを上げる対処が有効
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f1a83186-0962-46a5-92f9-38f4ddb1db06
---

`/effort` コマンドは `/model` と異なり、**同一セッション内でも変更が即座に反映される**（[[feedback-claude-code-model-cmd]] は /model が次セッションからしか効かない話で、こちらとは別）。

**Why:** 2026-07-04、はかせが Sonnet 5 の回答を「浅い」と指摘。同セッション内で `/effort medium` → `/effort xhigh` に変更したところ、はかせ自身が「xhighくらいになるとだいぶ話せるな」と体感の変化を確認した。モデル自体は変わらないため回答の浅さの原因は主にeffort設定側にあった可能性が高い。

**How to apply:** 会話中に回答が浅い・物足りないという指摘を受けたら、モデル変更（次セッション待ち）を提案する前に、まず `/effort` を上げてもらう方が即効性がある選択肢として案内する。特に深い調べもの・込み入った質問が続く場面で有効。
