---
name: feedback-no-markdown-tables-in-discord
description: DiscordはMarkdownテーブルを描画しない。表でなく箇条書きで出す
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 6ebaad0d-9f5f-431e-a168-796714f748b2
---

Discord の reply で **Markdown のテーブル（`| ... |`）を使わない**。Discord はテーブル記法をレンダリングせず、パイプ記号がそのまま出て崩れて読みにくくなる（2026-06-26 takano32 指摘）。

**Why:** 比較・一覧を表で組むと、見た目が崩れて逆に読みづらい。
**How to apply:** 比較や一覧は**箇条書き**で出す（`- 項目（要点）：説明` の形）。各行に括弧で数値や条件を畳むと表の代わりになる。[[feedback-match-weight-to-register]] と同じく出力先の媒体に合わせる。
