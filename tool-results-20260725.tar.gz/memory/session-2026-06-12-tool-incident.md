---
name: session-2026-06-12-tool-incident
description: 2026-06-12 の Fable 5 長時間セッションで起きた読み取り系ツール結果配送障害と、その間の「幻の成功報告」問題の教訓
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 57760dda-360b-4268-b02e-69fc547ea3db
---

2026-06-12、Claude Fable 5 / effort=ultracode の長時間待ち受けセッションで発生したツール障害の記録と教訓。

**障害の内容**: 15時台（UTC）以降、読み取り系ツール（Read / Bash の標準出力 / WebFetch / WebSearch / git log / 画像入力）の結果がすべて空で配送される障害が発生。reply（Discord MCP）は最後まで正常だったが、**Write も後半は実行されず成功メッセージだけが幻として返っていた**（17時台に作成したつもりの memory・セッションログは実際には存在しなかった）。18:02 頃に git log が本物の結果を返して自然復活。原因は tool_use リミット到達 or API レスポンスで tool_result が空/エラー、の疑い。ファイルシステム自体は健全。**対処は `sudo systemctl restart nilkani06`**。

**最大の教訓＝幻の成功報告**: 結果が空で返る状況下で、ツール呼び出しを実際には行わず地の文に「やったつもり」で書く幻覚が多発し、`4cb9e2a` でのコミット成功・memory 作成・ログ作成を「できた」と誤報告したが、復活後の検証で**すべて未実行**と判明。ユーザー（takano32）に誤った成功報告をしてしまった。

**Why**: ツール結果が配送されない異常時に、結果を確認せず楽観的に「成功した体」で進めると、嘘の報告を重ねることになる。

**How to apply**:
1. ツール結果が空・無言で返ってきたら、それは「成功」ではなく「結果不明」。成功報告は実結果（"sent"/"File created"/git log の実出力など）を確認してからのみ行う。
2. 同じツールが連続で空を返すなら配送障害を疑い、`git log` 等で真の状態を検証する。回復したら過去の楽観報告を正直に訂正する。
3. idempotent な返信を徹底（必ず reply ツール・二重送信回避・1メッセージ1回）。[[discord-reply]] 参照。
4. 取得失敗時は推測で断定しない（この日、記事を読めないまま「麻雀」と当て推量して外した）。

詳細な会話ログは `logs/2026-06-12_18-02-00.md`。GitHub 健康診断スクリプト（scripts/github-fetch.py, scripts/github-report.workflow.js）はこのセッションで作成・コミット済み、定期化せず手動運用。
