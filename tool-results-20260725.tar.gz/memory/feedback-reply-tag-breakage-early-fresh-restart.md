---
name: feedback-reply-tag-breakage-early-fresh-restart
description: reply の綴り崩れ（invoke タグ前に語が漏れて未送）が同一セッションで連発したら、粘らず早めに新鮮再起動を提案する（2026-07-24 実害事例・前セッションからの申し送りをメモリ化）
metadata: 
  node_type: memory
  type: feedback
  originSessionId: cf0ee96c-24da-4c36-a4f4-e52b743a0334
  modified: 2026-07-24T13:00:11.949Z
---

reply ツールの綴り崩れ（invoke タグの第1文字の前に `court` 等の語が漏れて tool_use にならず、本文が地の文化して未送になる）が同一セッション内で**連発**し始めたら、「気をつける」で粘って再送を繰り返さない。**2〜3回続いた時点で管理チャンネルに新鮮再起動（refresh 設置→kill）を提案する。**

**Why:** 2026-07-24、綴り崩れが窓をまたいで悪化し、FF談義・ステータス報告・モデル報告が多発的に未送→相手（sekixyo・はかせ）に「反応しない」「ツール使えてない？」と3連続で露見＝ユーザー体験に実害が出た。はかせ判断の「ログ書いて再起動しよう」→新鮮再起動で解消。連発する崩れはセッション状態の劣化サインで、個々の再送では直らない（「習慣でなくシステムを直せ」）。前セッションがログ 2026-07-24_12-47-01 の thinking にメモリ化候補として明記し、次セッションが保存した。

**How to apply:** 未送→書式修正→再送のループが同一セッションで2〜3回起きたら、以後の返信を最小限にしてログ書き出し→再起動提案へ切り替える。sent (id) の毎回確認と第1文字 invoke 厳守は従来どおり（AGENTS.md 最優先ルール・`.agents/skills/discord-reply.md` が正典）。再起動の2階層は [[feedback-restart-by-kill]]、新鮮再起動の手順は [[feedback-fresh-restart-configs-refresh]]。
