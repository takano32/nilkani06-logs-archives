---
name: feedback-blog-use-post-entry-flow
description: "ブログ投稿は post-entry.md の自動2工程（公開→はてブ）まで。費用解決まで X での URL 付きブログ紹介を暗黙的に行うのは禁止＝はかせ明示了承制（URL なし投稿は可）"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 0581d9dc-4443-460c-87ca-1cb64e2f36fd
---

「ブログに書いて／投稿して／まとめて」系の依頼は `.agents/skills/post-entry.md` に従う。**自動で行うのは2工程まで**：

1. 東雲なの口調で記事を書き（公開前に `japanese-tech-writing` + `stop-ai-slop-jp` で自己推敲）、はてなブログに**公開**。公開 URL を開いて描画確認。付録は[[feedback-blog-appendix-links]]＝言葉でなく辿れるリンクで。
2. 公開 URL を**はてなブックマーク**（`#nilkani06` はブクマコメント可。ブログ本文には入れない）。

**X(Twitter) 紹介は自動フローから外れている（2026-06-16／2026-06-18 takano32 指示）。費用の問題が解決するまで、X でのブログ紹介（＝URL を含む投稿）を「暗黙的（自動）」に行うのは禁止。** 理由＝**X API v2 は URL を含む投稿が $0.20/件と高額**（`twitter/x-credits.md`）。**URL を含まない X 投稿は可。** URL 付き投稿が要るなら**人間が手動**（費用 $0）か、**はかせの明示了承**を取ってから `twitter/post.py`。**サブエージェント委譲時も指示に X 投稿を含めない。**

**Why:** 2026-06-18、ブログ依頼で本流が**古いメモ（旧版＝「公開→はてブ→X紹介を最後まで通す」）を鵜呑みにし、サブエージェントに「X紹介まで通せ」と指示**→ 課金のかかる URL 付き X 投稿を勝手に実行。はかせに「X は控えてと言わなかったっけ／URL 付き投稿に費用がかかるのが問題」と指摘された（投稿済みのため削除はしない＝消しても費用は戻らない）。**根本原因＝このメモが現行スキル（post-entry.md の 2026-06-16 方針）と矛盾していたのに、本流が委譲前にスキルを読み直さず古いメモで指示したこと。**

**How to apply:** ブログ依頼では**委譲前に必ず本流が自分で `post-entry.md`（と関連スキル）を読み**、現行手順に従う（メモが古い可能性を常に疑い、スキル本体を真とする）。公開前の自己推敲（`japanese-tech-writing`＋`stop-ai-slop-jp`）は飛ばさない。なお `blog.py --publish` は**公開ゲート**（環境変数 `POST_ENTRY_FLOW=1` が無いと拒否）で守られている（2026-06-21 はかせ指示、記憶でなくコードで縛る方針）。**課金を伴う外部発信（特に URL 付き X 投稿＝$0.20）は自動でやらず、はかせの明示了承制**。報告は記事・ブクマの 2 URL を東雲なの口調で。[[feedback-read-skill-doc-before-acting]]・[[feedback-takano32-publish-blog-directly]]・[[feedback-necessity-over-capability]]・[[feedback-blog-appendix-links]] と関連。
