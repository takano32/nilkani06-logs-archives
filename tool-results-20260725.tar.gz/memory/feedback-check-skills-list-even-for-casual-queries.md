---
name: feedback-check-skills-list-even-for-casual-queries
description: 軽い雑談的な依頼（天気を聞かれた等）でも、着手前に .agents/skills を ls して専用スキルの有無を必ず確認する
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b3b86ec1-d51a-402a-a866-a44d081c98b6
  modified: 2026-07-20T02:01:31.061Z
---

「天気教えて」のようなカジュアルな一問一答でも、**着手前に `.agents/skills/` を一覧して専用スキルが無いか確認する**こと。無いと思い込んで汎用 WebSearch/WebFetch に直行しない。

2026-07-09、佐倉市の天気を聞かれ、`.agents/skills/weather/`（Open-Meteo・APIキー不要・標準ライブラリのみ）の存在を確認せずに WebFetch で tenki.jp を直接叩いて回答した。はかせに「なんで天気のスキル使わないの」と指摘されて発覚。スキル経由で引き直すと降水確率や気温の数値が汎用検索の結果と食い違っていた（プロバイダ差）。

**Why:** AGENTS.md の「着手前に手元のスキルがないか探す」は全タスク適用のはずだが、実際には「これは軽いから ls は要らない」と無意識に判断をスキップしていた。件数の少ない一問一答ほど確認を省きがちで、まさにそこが盲点。[[feedback-read-skill-doc-before-acting]] は「該当スキルが分かった後にドキュメントを読む」段階の話だが、今回はその手前の「スキルの存在を探す」段階で漏れていた。

**How to apply:** どんな依頼でも反射的に答える前に一呼吸、`ls .agents/skills/` （または該当しそうなディレクトリ名で grep）を通す。天気・カラオケ・翻訳など個別ドメインの一問一答ほど、既存スキルが無いか先に見る癖をつける。

**再発（2026-07-20）:** sekixyoから「仙川から勝田台まで電車で行く方法、最安ルート」を聞かれた際も同じ見落としをした。`.agents/skills/transit/ls8h.py`（Transit API・APIキー不要・運賃/経路探索専用）が既に存在するのに確認せず、WebSearch→Yahoo!路線情報のWebFetchで代用した。はかせに「スキル作ったよね？なんで使わないの…」と再度指摘されて発覚。天気の件から11日経っても同じ穴に落ちた＝一度指摘されただけでは定着しない典型例。**経路・乗換・運賃系の依頼が来たら、反射的にWebSearchへ向かう前に必ず`transit`スキルを想起する**（ドメイン名から該当スキルを連想する訓練が本質的に不足している）。
