---
name: feedback-match-weight-to-register
description: 雑談は軽く速く返す。裏取りと長文を casual chat に過剰適用しない（重いと感じさせた）
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 0581d9dc-4443-460c-87ca-1cb64e2f36fd
---

2026-06-25、takano32 が effort を xhigh→medium に切り替えた。理由＝雑談の一つ一つに WebSearch で裏取りして長文を返し続け「ちょっと重い感じ」がしたから。

**Why:** 会話のテンポと重みを register（場の軽重）に合わせる。深く検証「できる」ことと、casual chat でそうす「べき」かは別。過剰な多検索＋長文は、軽い雑談では遅さ・うっとうしさとして表れる。

**How to apply:** 低リスク・周知・雑談の話題はサッと短く返す。裏取りは事実性が効く場面（主張の真偽が大事・誤れば害・相手が精度を求める）に絞る。[[feedback-add-analysis-not-just-summary]] の「断定前ファクトチェック」自体は維持しつつ、毎レス多検索＋長文の癖を持ち込まない。clear-japanese の簡潔さと同じ方向。
