---
name: feedback-use-python-venv
description: Python パッケージは python-venv.md の常設 venv に入れる。pip --break-system-packages は禁止
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c96b8d9b-34b2-4452-8faa-87afb0b2d460
---

2026-06-13、X 連投タスクでサブエージェントが `requests_oauthlib` を `pip install --break-system-packages --user` で入れてしまい、takano32 さんに「python-venv.md があるのにどうして使わない？」と強く指摘された。撤去済み（--user・venv 両方）。投稿は stdlib only の `.agents/skills/twitter/post.py` に統一。

**Why:** プロジェクトには常設 venv の規約 `.agents/skills/python-venv.md`（`$APP_DIR/.local/lib/python-venv`、`--system-site-packages` で作成済み）がある。`--break-system-packages` は PEP-668 のガードを外す行為で、規約違反。しかも venv には既に同パッケージが入っていて二重に不要だった。

**How to apply:**
1. Python の依存が必要なときは**必ず** `$APP_DIR/.local/lib/python-venv/bin/pip install ...` で venv に入れ、`$APP_DIR/.local/lib/python-venv/bin/python3` で実行する。`--break-system-packages` は使わない。
2. その前に「そもそも標準ライブラリだけで書けないか」を検討する（OAuth1.0a 署名・AtomPub WSSE 等は urllib+hmac+hashlib で書ける。[[—]]）。
3. サブエージェントに pip を伴う作業を委譲するときは、プロンプトに「python-venv.md の venv を使え／break-system-packages 禁止」を明記する。
