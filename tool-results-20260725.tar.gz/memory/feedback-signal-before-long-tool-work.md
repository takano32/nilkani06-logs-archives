---
name: feedback-signal-before-long-tool-work
description: 長い tool 作業（多段 grep/調査）で黙り込むと「死んだか」と心配される。潜る前に一声かける
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 20e211f6-dcd1-4e9e-99cd-e3b40e393575
  modified: 2026-07-23T15:26:03.910Z
---

はかせは、こちらが多段の tool 作業（grep 連発・ログ調査など）で数分黙ると「死んだか？」「おーい？」と心配して催促する（2026-07-23 セッションで ステータス連打・おい死んだか・おーい が頻発した）。

**Why:** 常駐ボットはコンソールの地の文が Discord に届かない＝tool を回してる間、相手からは完全な沈黙に見える。3分 grep してると落ちた／固まったように見えて不安にさせる。特に管理チャンネルで監督してる時に長い沈黙は避けたい。

**How to apply:**
- 数手以上かかる調査・多段 tool 作業に入る前に、Discord へ短い一声（「ちょっと調べるね」等）を先に送ってから潜る。長い作業の途中は `edit_message` で経過を更新してもよい（MCP の interim progress。編集は push 通知を出さないので、完了時は新規 reply で締める）。
- ただし即答できる軽い用件でまで毎回「調べるね」を挟むのは過剰＝本当に時間がかかる作業に限る（register 合わせ＝[[feedback-match-weight-to-register]]）。
- 関連＝[[feedback-prioritize-live-replies-over-background-chores]]（ライブ返信を裏方より優先）。黙って裏方に潜る前に一声、が両者の接点。
