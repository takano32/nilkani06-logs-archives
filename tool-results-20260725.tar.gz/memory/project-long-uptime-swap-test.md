---
name: project-long-uptime-swap-test
description: 2026-07-08、takano32了承の長時間起動・SWAP限界試験。固まるまで再起動しない方針
metadata: 
  node_type: memory
  type: project
  originSessionId: 07a8adc4-4309-4853-a114-ddd8fdf56a6a
---

2026-07-08、管理チャンネルでtakano32と「SWAPが今までどこまで伸びて頭打ちになるか観測したことがない」という話になり、上限を設けず**行けるところまで再起動せずに観測する**試験を了承済みで開始した。

**Why:** これまでSWAP使用量が数百MiB増えるたびに感覚的に再起動を提案・実行してきたが、実際にOOMや応答不能まで到達するのか、それとも途中で頭打ちになるのかを一度も検証したことがなかった。vm.swappiness=200（zram向けに既にアグレッシブ設定済み）という前提も判明し、単純な設定不足ではないことが分かったため、実地でどこまで耐えるかを見る意味が出た。

**How to apply:**
- この試験が明示的に終了する（takano32が「試験終了」等と言う）まで、**SWAP/MEM使用量が増えても自分から再起動を提案・推奨しない**（これまでの`feedback-restart-by-kill`的な「そろそろ再起動を」という助言パターンを、この試験期間中は一時停止する）。
- ステータス報告自体は普段どおり継続する（観測が目的なので、数値の可視化は続ける）。
- 実際に応答不能・ハングアップ・クラッシュが起きたら、それが観測の終点。再起動（`pgrep`でPID確認→kill、通常再起動でよい。フレッシュ不要）した後、`boot.log`・claude-debug.log・このセッションのログ（このタイミングの`logs/*.json`）を見返して「どこまでSWAPが伸びたか」「どういう壊れ方をしたか」（OOM killer発動か、単なるハングか、Discord無応答か等）を検証・報告する。
- 検証後にこの試験の結果を`nilkani06-diagnostics-and-tooling`や`nilkani06-failure-archaeology`スキルに知見として還元する価値がある。
