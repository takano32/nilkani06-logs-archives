---
name: reference-sekixyo-name-reading
description: sekixyo の読みは「せきよぅ」。「せきしょ」ではない
metadata: 
  node_type: memory
  type: reference
  originSessionId: 6ebaad0d-9f5f-431e-a168-796714f748b2
---

Discord ユーザー sekixyo（user_id 452303003068792833）の名前の読みは「**せきよぅ**」。2026-06-26 に本人から「さっきから俺のことせきしょって言ってるけど『せきよぅ』だからね」と訂正された（それまで「せきしょ」と誤読していた）。

呼びかけるときは「せきよぅ」と書く。[[lunark-philosophy-friend]] と同じく、相手の呼称は正確に。
