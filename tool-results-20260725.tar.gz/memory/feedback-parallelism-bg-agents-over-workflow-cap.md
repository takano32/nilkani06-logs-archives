---
name: feedback-parallelism-bg-agents-over-workflow-cap
description: 大量サブエージェントの並列実行は、Workflow の cap(コア数依存)より独立バックグラウンド Agent を複数立てる方が稼げる
metadata:
  node_type: memory
  type: feedback
  originSessionId: 0581d9dc-4443-460c-87ca-1cb64e2f36fd
---

Workflow の `parallel()`/`pipeline()` の同時実行数は **CPU コア数（min(16, cores−2)）に縛られる**。デプロイ先の **e2-micro は2コア**なので、13本投げても実質ほぼ直列になる。

**Why:** 2026-06-22、268件のログ見出し短縮を Workflow（13チャンク `parallel()`）で流したら遅く、はかせに「2コアならふつう4ジョブで走らせない？」と指摘された。サブエージェント作業は **API 待ち（I/O バウンド）**で CPU をほぼ使わないから、コア数で絞るのは過剰に保守的＝オーバーサブスクライブして良い。

**How to apply:**
1. 大量の独立サブエージェント作業（バッチ・調査・一括変換など）で**速度が要る**なら、単一 Workflow の内部 cap に縛られない **`Agent`（`run_in_background: true`）を複数本まとめて起動**する（このとき残作業を冪等にシャード分割し、二重処理を避ける）。今回は残り124件を6シャードで6並列にして一気に終わった。
2. Workflow は「決定的な制御フロー・schema 収集・段階パイプライン」が要るときに使う。純粋な水平ファンアウトで速度優先なら background Agent 群の方が並列を稼げる。
3. 適用は**決定的スクリプトに寄せ、判断だけサブエージェント**にすると一貫性と検証が楽（例：`shorten_headline.py` に適用を集約し、短い見出しの生成だけエージェント）。[[feedback-check-channel-before-respawn]] と同じ「外向き副作用は実状態を見てから」。
