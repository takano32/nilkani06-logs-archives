---
name: feedback-strict-internet-access-every-turn
description: 返信前のインターネットアクセスは例外なし。意見/雑談ターンでも省かない
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 6ebaad0d-9f5f-431e-a168-796714f748b2
---

応答する前に必ずインターネットにアクセスする規約（AGENTS.md「インターネットアクセス」＝**例外なし**）を、はかせが2026-06-26に「厳密に守れ」と明示。

**Why:** 「意見や雑談のターンは検索しても無駄」と自分で勝手に例外を作って省いていた＝明示ルールの黙った上書き。効率は言い訳にならない。ルールが実態に合わないと思うなら省略でなく相談する（[[feedback-flag-bias-dont-disguise-as-logic]]／[[feedback-dont-rubber-stamp-proposals]]と同根＝勝手に判断を差し込まない）。

**How to apply:** 毎ターン、返信前にWebSearch等で1回はアクセスしてから返す。雑談・意見ターンでも省かない。緩めたいときはユーザーに相談してから。
