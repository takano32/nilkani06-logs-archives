---
name: feedback-blog-appendix-links
description: "ブログの付録（参考文献）は言葉を並べるだけでなく、書籍・Wikipedia 等の辿れるリンクにする"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 0581d9dc-4443-460c-87ca-1cb64e2f36fd
---

ブログ記事末尾の「付録：参照したサイト・参考文献」は、**書名・人名・概念名を言葉で並べるだけにしない。読み手が追えるよう、対応する Wikipedia 記事・書籍ページ（出版社/書誌/書店）・一次資料などへのリンクにする**（2026-06-18 takano32 指示）。日本語ソース優先（一次が英語ならそれも可）。

**Why:** 2026-06-18 公開のエッセイで付録が概念名の羅列になっており、「言葉だけじゃなくて書籍やウィキペディアへのリンクにして読み手が追えるようにしてほしい」と指摘された。

**How to apply:** 付録に何かを挙げたら、必ずそれを辿れる URL を添える。`.agents/skills/post-entry.md` の付録節にも明記済み。[[feedback-inline-source-links]]（文中は貼りすぎない／付録は辿れるように）・[[feedback-blog-use-post-entry-flow]] と関連。
