---
name: feedback-own-operational-setup-dont-punt
description: 自分が使う道具の前提設定（env・パス等）は毎回自分できちんと通す。人に「設定しておいて」と振らない
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 329e63b1-d338-47ae-8a2c-00c7872854f9
---

自分（AI／サブエージェント）が使うツールの前提設定は、**呼ぶ側の責務として毎回自分できちんと通す**。返信に「◯◯を通してから叩いてね」と書いて人（はかせ）に振るのは間違い。使うのは自分なのだから、設定の正しさを人に肩代わりさせない。

**Why:** 2026-07-04、rustup を .local に入れた運用で「rust を使う時は env（RUSTUP_HOME/CARGO_HOME/PATH）を通してから叩いてね」と はかせに振る言い方をして、「通してから叩いてね、じゃなくてお前がきちんとするんだぞ」と指摘された。env 無しだと apt rustup が既定 `~/.rustup` を見て `no default toolchain` で落ちる＝設定は省略不可。それを人手に委ねるのでなく、呼ぶ側が毎回インラインで通すのが正しい。

**How to apply:**
1. rust/cargo/rustup は**同じコマンド行で env をインラインに通す**：`env RUSTUP_HOME=$APP_DIR/.local/rust-packages/rustup CARGO_HOME=$APP_DIR/.local/rust-packages PATH=$APP_DIR/.local/rust-packages/bin:$PATH <cmd>`（`packages/rust-packages.md`）。
2. 一般化：`.local/<lang>-*` 系の依存・ツールを使うときは、必要な env/PATH を自分のコマンドで整えてから実行する。手順書を人に読ませて「先に設定して」と振らない。
3. サブエージェントに委譲するときも、この env プレフィックス／設定手順を指示に**転記**する（サブエージェントも呼ぶ側の責務を負う）。
4. 「人に振る言い方」をしていないか、返信を出す前に一拍見る。運用の正しさは自分で担保する。
