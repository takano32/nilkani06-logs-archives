---
name: reference-known-host-processes
description: e2-micro 上の正規プロセス台帳（ステータス報告で「見知らぬCOMMAND」と誤警報しないため）
metadata: 
  node_type: memory
  type: reference
  originSessionId: dd5778c6-d16a-479d-91de-54a8062f0aec
  modified: 2026-07-22T06:07:31.662Z
---

ステータス報告（status.py のプロセス表）で claude / bun（watcher＋Discordプラグイン）以外に見えても**正規**のプロセス（はかせ確認済み 2026-07-22、管理ch）:

- `caddy` — HTTPS のプロキシ（はかせが導入）
- `cxx_chatwork` — Slack の webhook（はかせが導入）

どちらも 2026-07-22 朝〜昼に出現。以後のステータスで「見知らぬプロセス」として警告しない。新顔のプロセスを見つけたときの手順は従来どおり＝勝手に止めず管理チャンネルで一度だけ確認（[[feedback-pushback-once-not-repeat]]）。
