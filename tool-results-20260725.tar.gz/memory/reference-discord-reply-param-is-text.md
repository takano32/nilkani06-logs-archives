---
name: reference-discord-reply-param-is-text
description: discord reply ツールの本文引数は content でなく text。間違えると text.length エラー
metadata: 
  node_type: memory
  type: reference
  originSessionId: b7d4db53-1c66-4b2e-a4d6-a097efb19dad
---

`mcp__plugin_discord_discord__reply` の本文パラメータは **`text`**（`content` ではない）。

`content` で送ると `reply failed: undefined is not an object (evaluating 'text.length')` が返り、Discord には届かない。MCP の説明文は「pass chat_id back」としか書かず本文パラメータ名を明示しないので間違えやすい。fetch_messages の channel 引数も `channel`（`chat_id` ではない）。スキーマを ToolSearch で確認すれば確実。

required: `chat_id`, `text`。任意: `reply_to`, `files`。

関連: [[reference-my-discord-bot-user-id]]
