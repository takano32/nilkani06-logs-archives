---
name: feedback-process-memory-output-format
description: 「プロセスごとのメモリとスワップ」を聞かれたときの出力書式。はかせが固定指定した COMMAND/RSS/SWAP の1ブロック表
metadata:
  node_type: memory
  type: feedback
  originSessionId: b7d4db53-1c66-4b2e-a4d6-a097efb19dad
---

「プロセスごとのメモリとスワップ」を聞かれたら、**次の書式で固定して出す**（はかせが 2026-06-27 に「次からこの書式にしてよ」と明示指定、2026-07-06 に Available 行を追加指定、2026-07-07 に末尾3行をMEM/ZRAM/SWAPのTOTAL/USE/AVAILABLE形式に変更＋LOAD行を追加、さらに全体の並びを「LOAD→空行→MEM/ZRAM/SWAP→空行→プロセス表」の順に指定）。この定型手順は `.agents/skills/status.md` としてスキル化済みで、管理チャンネルで「ステータス」「状態」と言うだけで発火する。Discord で崩れないよう**コードブロック内**に置き、**サマリ（LOAD・MEM・ZRAM・SWAP）を先に、プロセス表（COMMAND / RSS(MiB) / SWAP(MiB)、RSS降順・上位20件）を後に**。

```
LOAD 1min=0.22 5min=0.33 15min=0.27

MEM  TOTAL=952.7MB  USE=748.6MB  AVAILABLE=204.1MB
ZRAM TOTAL=476.3MB  USE=230.5MB  AVAILABLE=245.9MB
SWAP TOTAL=1500.3MB USE=285.8MB  AVAILABLE=1214.6MB

COMMAND             RSS(MiB)  SWAP(MiB)
claude                 344.2      135.9
bun                     50.8       19.4
...（RSS降順で上位20件）...
sshd                     4.4        0.8
```
LOADは単独ブロック（前後に空行）。

**LOAD** は `/proc/loadavg` の1分/5分/15分平均（サマリの先頭、e2-microは2vCPUなので1.0超で飽和の目安）。**MEM** は `free -b` の Total/Used/Available（Availableは`/proc/meminfo`の`MemAvailable`＝buff/cache込みの実質使える空き）。**ZRAM** は `swapon --bytes --show` または `/sys/block/zram0/{disksize,mm_stat}` から、TOTAL=disksize・USE=圧縮後使用量・AVAILABLE=disksize-USE。**SWAP** はzram＋/swapfile等の全swapデバイス合計（`free -b`のSwap行と一致）。単位はMB。

**Why:** はかせはこの話題に書式の好みが強く、複数案を出して絞り込んだ末にこの形に確定した。試した他案（RSS上位/Swap上位の2ブロック分割、COMMAND を後ろに置く版）は却下。決め手は「COMMAND が先頭・RSS/SWAP が右に揃う・1ブロックで一覧でき、最後に system 全体の Mem/Swap 合計が付く」こと。**COMMAND 列は半角英数だけにする**（日本語注釈を混ぜると全角幅でカラムがずれて見にくくなる＝却下された原因）。Markdown テーブルは Discord で崩れるので使わない（[[feedback-no-markdown-tables-in-discord]]）。

**How to apply:** データは `/proc/[0-9]*/status` の `VmRSS` / `VmSwap` を集計（`smem` 等の追加依存は不要）、`free -m` で合計。RSS 降順で上位を出す。COMMAND は cmdline の basename を半角で（`bun (discord plugin)` のように何のプロセスか短い半角注記は可、ただし桁ずれしない範囲）。数値は M 単位・右寄せ。読み（なの口調の一言＝claude が断トツか・スワップに乗り始めてないか・利用可能メモリの余裕）は表の**外（コードブロックの後）**に添えると、表自体は崩れず読みも付く。1GB 機（e2-micro・Mem 952M / Swap 1.0G）なので、claude がスワップに乗り始めたら再起動でリフレッシュする判断材料になる。[[feedback-restart-by-kill]]
