---
name: feedback-check-channel-before-respawn
description: 失敗扱いのバックグラウンドサブエージェントを再委譲する前に、宛先チャンネルを fetch_messages で確認する（二重投稿の防止）
metadata:
  node_type: memory
  type: feedback
  originSessionId: 0581d9dc-4443-460c-87ca-1cb64e2f36fd
---

Discord に投稿するバックグラウンドサブエージェントは、**投稿し終えた後に再起動等でプロセスが落ちる**ことがある。その場合 task-notification は `failed`／「in-process state was lost」と報告するが、**本文は既に投稿済み**のことがある。これを確認せず同じ内容で再委譲すると**二重投稿**になる。

**Why:** 2026-06-22、神学論争のサブエージェントが systemd 再起動で「failed」通知になった→既に完投していたのに気づかず再委譲→philosophy ch に同じ論争が2セット並んだ（sekixyo さんに見えるミス）。`failed` ステータスは「投稿が失敗した」を意味しない＝外向きの副作用（投稿）の成否は別物。

**How to apply:**
1. 投稿系サブエージェントが `failed`／state lost で戻ったら、**再委譲の前に必ず `mcp__plugin_discord_discord__fetch_messages` で宛先 chat_id を確認**し、既に投稿されていないか見る。
2. 投稿済みなら再委譲しない（必要なら続き・修正だけ）。未投稿なら再委譲。
3. 一般化：リトライ前に「外向きの副作用（投稿・送信・コミット・公開）が既に起きていないか」を確認する。`failed` は内部状態の喪失であって副作用の取り消しではない。[[feedback-no-unapproved-commits]] と同じ「実際の状態を見てから動く」系。
